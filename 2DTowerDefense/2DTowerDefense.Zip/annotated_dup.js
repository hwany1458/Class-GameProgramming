var annotated_dup =
[
    [ "Enemy", "classEnemy.html", "classEnemy" ],
    [ "EnemyMove", "classEnemyMove.html", "classEnemyMove" ],
    [ "EnemyWaveData", "classEnemyWaveData.html", "classEnemyWaveData" ],
    [ "GameMgr", "classGameMgr.html", "classGameMgr" ],
    [ "Projectile", "classProjectile.html", "classProjectile" ],
    [ "Tower", "classTower.html", "classTower" ],
    [ "TowerMgr", "classTowerMgr.html", "classTowerMgr" ]
];