var classEnemyWaveData =
[
    [ "enemyCount", "classEnemyWaveData.html#a9cade1c5bd90c4595dcbcf68817fe06b", null ],
    [ "spawnInterval", "classEnemyWaveData.html#a6fa37dda3006ba9e14a35f554d76b13f", null ],
    [ "delayBeforeNextWave", "classEnemyWaveData.html#ae92518b6ba5baa5139805a80e4ce9dd6", null ]
];