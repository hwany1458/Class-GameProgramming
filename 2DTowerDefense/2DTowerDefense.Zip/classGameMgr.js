var classGameMgr =
[
    [ "curGold", "classGameMgr.html#a9dd76f02252acb7a520d89fca4d1a922", null ],
    [ "curHP", "classGameMgr.html#aedb7140fc91475ce5bd78e1d6c48e77b", null ],
    [ "isGameOver", "classGameMgr.html#a1917f26b20db85d989f358c9a0ef1dd8", null ]
];