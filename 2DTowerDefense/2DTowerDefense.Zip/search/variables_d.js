var searchData=
[
  ['spawnedenemynuminwave_0',['spawnedEnemyNumInWave',['../EnemyMgr_8cs.html#a2e79c35f41762ad337ad3b7a29acbf4b',1,'EnemyMgr.cs']]],
  ['spawninterval_1',['spawninterval',['../classEnemyWaveData.html#a6fa37dda3006ba9e14a35f554d76b13f',1,'EnemyWaveData::spawnInterval'],['../EnemyMgr_8cs.html#ab5fa181699c274c8032da357cb711636',1,'spawnInterval:&#160;EnemyMgr.cs']]],
  ['sqrvelocitythreshold_2',['sqrVelocityThreshold',['../classEnemyMove.html#a6f2292d8fea88c1655cb2dd6c500d2f9',1,'EnemyMove']]]
];
