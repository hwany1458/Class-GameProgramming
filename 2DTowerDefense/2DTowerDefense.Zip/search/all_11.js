var searchData=
[
  ['l_20—_20enemymgr_20의_20로직_20결함_0',['L — EnemyMgr 의 로직 결함',['../index.html#L_defects',1,'']]],
  ['lifetime_1',['lifeTime',['../classProjectile.html#a204629e8a8dd92858ad144f6eccb23b8',1,'Projectile']]]
];
