var searchData=
[
  ['dieenemy_0',['DieEnemy',['../EnemyMgr_8cs.html#a3c539c6cd8973229c644fda3994eb99a',1,'EnemyMgr.cs']]],
  ['dieenemyatdestination_1',['DieEnemyAtDestination',['../EnemyMgr_8cs.html#a578d748b886a6a28e525593ec5ca30d9',1,'EnemyMgr.cs']]]
];
