var searchData=
[
  ['코드가_20아니라_20설정_0',['N — 교재가 빠뜨린 작업 단계 (코드가 아니라 설정)',['../index.html#N_defects',1,'']]],
  ['코드_2014_205_20·_20ppt_2054_2055쪽_1',['T — Tower.cs (교재 코드 14-5 · PPT 54~55쪽)',['../index.html#T_defects',1,'']]],
  ['코드_2014_206_20·_20ppt_2058_2059쪽_2',['P — Projectile.cs (교재 코드 14-6 · PPT 58~59쪽)',['../index.html#P_defects',1,'']]],
  ['코드_2014_207_20·_20ppt_2060_2062쪽_3',['B — TowerMgr.cs (교재 코드 14-7 · PPT 60~62쪽)',['../index.html#B_defects',1,'']]],
  ['코드_2014_208_20·_20ppt_2063_2064쪽_4',['G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)',['../index.html#G_defects',1,'']]],
  ['코어_20—_20재화와_20hp_5',['코어 — 재화와 HP',['../group__Core.html',1,'']]]
];
