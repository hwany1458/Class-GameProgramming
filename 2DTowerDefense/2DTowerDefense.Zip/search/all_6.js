var searchData=
[
  ['8_20·_20ppt_2063_2064쪽_0',['G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)',['../index.html#G_defects',1,'']]]
];
