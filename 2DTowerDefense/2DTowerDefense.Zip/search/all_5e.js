var searchData=
[
  ['함수_0',['수정본에서 새로 만든 함수',['../index.html#s_class',1,'']]]
];
