var searchData=
[
  ['6_20·_20ppt_2058_2059쪽_0',['P — Projectile.cs (교재 코드 14-6 · PPT 58~59쪽)',['../index.html#P_defects',1,'']]],
  ['60_2062쪽_1',['B — TowerMgr.cs (교재 코드 14-7 · PPT 60~62쪽)',['../index.html#B_defects',1,'']]],
  ['62쪽_2',['B — TowerMgr.cs (교재 코드 14-7 · PPT 60~62쪽)',['../index.html#B_defects',1,'']]],
  ['63_2064쪽_3',['G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)',['../index.html#G_defects',1,'']]],
  ['64쪽_4',['G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)',['../index.html#G_defects',1,'']]]
];
