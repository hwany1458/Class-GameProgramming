var searchData=
[
  ['단계_20코드가_20아니라_20설정_0',['N — 교재가 빠뜨린 작업 단계 (코드가 아니라 설정)',['../index.html#N_defects',1,'']]]
];
