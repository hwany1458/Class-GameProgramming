var indexSectionsWithContent =
{
  0: "1245678abcdefghiklmnoprstuw·—『가개거건검것게결과교구기넣단되디로막만매목무문발버부분빠사새생서설세수스실쓰아않어없요웨의이일입자작재적전제좋줄증진찾출컴코타한함확활",
  1: "egpt",
  2: "egmpt",
  3: "abcdfghorsu",
  4: "abcdefghiklmpstw",
  5: "h—건발사생웨이재적전코타",
  6: "12—『게디목문버분수입한"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수",
  5: "그룹들",
  6: "페이지들"
};

