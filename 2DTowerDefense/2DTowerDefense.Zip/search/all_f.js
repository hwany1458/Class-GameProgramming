var searchData=
[
  ['isdead_0',['isDead',['../classEnemy.html#a6e55221aa524f0f826feadfd0c567b70',1,'Enemy']]],
  ['isgameover_1',['isGameOver',['../classGameMgr.html#a1917f26b20db85d989f358c9a0ef1dd8',1,'GameMgr']]],
  ['ishit_2',['isHit',['../classProjectile.html#a40c279e9573b1299562518207b6ddf30',1,'Projectile']]],
  ['isspawningwave_3',['isSpawningWave',['../EnemyMgr_8cs.html#aa8aa4150240ee320b333b2bc473e251f',1,'EnemyMgr.cs']]],
  ['isstartgame_4',['isStartGame',['../EnemyMgr_8cs.html#a688e27eed2efaa01f2506e4bfd4d003e',1,'EnemyMgr.cs']]],
  ['iswaitnextwave_5',['isWaitNextWave',['../EnemyMgr_8cs.html#a055969d3d20514fde7a73b0274a0ec85',1,'EnemyMgr.cs']]]
];
