var searchData=
[
  ['removeenemy_0',['RemoveEnemy',['../EnemyMgr_8cs.html#a0e116bd0f652a52dba7775939bbdb43e',1,'EnemyMgr.cs']]]
];
