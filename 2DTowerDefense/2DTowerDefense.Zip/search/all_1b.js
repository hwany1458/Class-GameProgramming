var searchData=
[
  ['·_20ppt_2054_2055쪽_0',['T — Tower.cs (교재 코드 14-5 · PPT 54~55쪽)',['../index.html#T_defects',1,'']]],
  ['·_20ppt_2058_2059쪽_1',['P — Projectile.cs (교재 코드 14-6 · PPT 58~59쪽)',['../index.html#P_defects',1,'']]],
  ['·_20ppt_2060_2062쪽_2',['B — TowerMgr.cs (교재 코드 14-7 · PPT 60~62쪽)',['../index.html#B_defects',1,'']]],
  ['·_20ppt_2063_2064쪽_3',['G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)',['../index.html#G_defects',1,'']]]
];
