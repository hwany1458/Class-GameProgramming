var searchData=
[
  ['waitattacktime_0',['waitAttackTime',['../classTower.html#ad8f3025e220c549defd64a3ce24ce6e7',1,'Tower']]],
  ['waves_1',['waves',['../EnemyMgr_8cs.html#abd7976f322ded373a86532b8320e6fad',1,'EnemyMgr.cs']]]
];
