var searchData=
[
  ['checkwaveclear_0',['CheckWaveClear',['../EnemyMgr_8cs.html#a73d30be313b92331e65d7efea0a3884f',1,'EnemyMgr.cs']]],
  ['completegame_1',['CompleteGame',['../EnemyMgr_8cs.html#a883f92b361fa16c819133317e7d2ae23',1,'EnemyMgr.cs']]]
];
