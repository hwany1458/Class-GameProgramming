var group__Core =
[
    [ "GameMgr.cs", "GameMgr_8cs.html", null ]
];