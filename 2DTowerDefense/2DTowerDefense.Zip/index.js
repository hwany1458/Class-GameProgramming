var index =
[
    [ "이 문서는 무엇인가", "index.html#s_intro", null ],
    [ "제작 7단계와 막히는 자리", "index.html#s_pipe", null ],
    [ "교재 어디에도 없던 세 줄", "index.html#s_three", null ],
    [ "증상에서 거꾸로 찾아가는 진단표", "index.html#s_symptom", null ],
    [ "스크립트 7개의 구조", "index.html#s_arch", [
      [ "매니저와 자식이 서로를 부른다", "index.html#s_a1", null ],
      [ "스크립트별 요약", "index.html#s_a2", null ]
    ] ],
    [ "확인된 결함 45건", "index.html#s_defects", [
      [ "C — 컴파일 자체가 되지 않는다 (출판사 스크립트)", "index.html#C_defects", null ],
      [ "L — EnemyMgr 의 로직 결함", "index.html#L_defects", null ],
      [ "M — EnemyMove 의 로직 결함", "index.html#M_defects", null ],
      [ "E — Enemy 의 로직 결함", "index.html#E_defects", null ],
      [ "T — Tower.cs (교재 코드 14-5 · PPT 54~55쪽)", "index.html#T_defects", null ],
      [ "P — Projectile.cs (교재 코드 14-6 · PPT 58~59쪽)", "index.html#P_defects", null ],
      [ "B — TowerMgr.cs (교재 코드 14-7 · PPT 60~62쪽)", "index.html#B_defects", null ],
      [ "G — GameMgr.cs (교재 코드 14-8 · PPT 63~64쪽)", "index.html#G_defects", null ],
      [ "N — 교재가 빠뜨린 작업 단계 (코드가 아니라 설정)", "index.html#N_defects", null ]
    ] ],
    [ "수정본에서 새로 만든 함수", "index.html#s_class", null ],
    [ "진단용으로 일부러 넣은 것", "index.html#s_diag", null ],
    [ "수업 활용", "index.html#s_use", [
      [ "실습 과제로 쓰기 좋은 결함", "index.html#s_u1", null ],
      [ "개념을 가르치기 좋은 자리", "index.html#s_u2", null ]
    ] ],
    [ "검증 기록", "index.html#s_verify", null ]
];