var classEnemy =
[
    [ "SetEnemeyMgr", "classEnemy.html#aafb636e9fc882e1dffb6162f5280fa20", null ],
    [ "OnDamage", "classEnemy.html#a25df3805355d9b5788806a8765385a47", null ],
    [ "hpValue", "classEnemy.html#a12af2bb67ca04d293d3f6fc1bbdd12d7", null ],
    [ "enemyMgr", "classEnemy.html#a812671fa8bd60c95e0111e537a8ac230", null ],
    [ "isDead", "classEnemy.html#a6e55221aa524f0f826feadfd0c567b70", null ]
];