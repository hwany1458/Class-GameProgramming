using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class TowerMgr : MonoBehaviour
{
    public Tilemap    buildTileMap;
    public GameObject buildTower;
    public EnemyMgr   enemyMgr;
    public GameMgr    gameMgr;
    public float      towerPrice = 100.0f;

    // 타일 위에 배치된 타워의 정보 관리
    private Dictionary<Vector3Int, GameObject> CanBuildTower =
            new Dictionary<Vector3Int, GameObject>();
    private Camera mainCamera;
    private int towerCounter = 0; // 타워 번호 카운팅

    // ★ 복원 — 교재 19행 "…생략…" 자리. 이게 없어서 NullReference 가 났다.
    private void Start()
    {
        mainCamera = Camera.main;

        if (mainCamera == null)
            Debug.LogError("TowerMgr : Main Camera 태그가 붙은 카메라가 없습니다.");
        if (buildTileMap == null)
            Debug.LogError("TowerMgr : Build Tile Map 에 Building 타일맵을 지정하세요.");
        if (buildTower == null)
            Debug.LogError("TowerMgr : Build Tower 에 TowerObj 프리팹을 지정하세요.");
        if (gameMgr == null)
            Debug.LogError("TowerMgr : Game Mgr 에 CurGameMgr 오브젝트를 지정하세요.");
        if (enemyMgr == null)
            Debug.LogError("TowerMgr : Enemy Mgr 에 CurEnemyMgr 오브젝트를 지정하세요.");
    }

    // ★ 복원 — 마우스 클릭을 받아 BuildTower() 를 부른다.
    //    이게 없어서 BuildTower() 를 아무도 호출하지 않았다.
    private void Update()
    {
        if (Mouse.current == null) return;          // Input System 미설치 방어

        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            BuildTower();
        }
    }

    void BuildTower()
    {
        if (mainCamera == null || buildTileMap == null || gameMgr == null) return;

        Vector2 mousePos = Mouse.current.position.ReadValue();
        Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(
                new Vector3(mousePos.x, mousePos.y,
                            mainCamera.nearClipPlane // 적절한 Z 거리
                )
        );

        // ★ 2D 이므로 z 를 0 으로 맞춘다.
        //    이걸 안 하면 Grid 의 Cell Size Z 설정에 따라 셀 z 가 어긋나
        //    GetTile() 이 엉뚱하게 null 을 돌려준다.
        mouseWorldPos.z = 0f;

        Vector3Int cellPosition = buildTileMap.WorldToCell(mouseWorldPos);

        // 이미 타워가 서 있는 칸이면 그만둔다
        if (CanBuildTower.ContainsKey(cellPosition))
            return;

        // 해당 위치에 타일이 있는지 확인
        TileBase subTile = buildTileMap.GetTile(cellPosition);
        if (subTile == null)
            return;                                  // ★ 타일이 없으면 조용히 끝낸다

        // ★ gameMgr. 을 붙였다. 교재 31행에 이 한 마디가 빠져 CS0103 이 났다.
        if (!gameMgr.checkGold(towerPrice))
        {
            Debug.Log($"골드가 부족해 타워를 세울 수 없다.  필요 {towerPrice}");
            return;
        }

        Vector3 worldPosition = buildTileMap.CellToWorld(cellPosition);
        Vector3 centerPosition = worldPosition + buildTileMap.cellSize * 0.5f;

        GameObject createdTower = Instantiate(buildTower, centerPosition,
                                              Quaternion.identity);

        createdTower.name = "BasicTower_Pos(" + cellPosition.x + "," + cellPosition.y +
                            ")_ID" + towerCounter;
        towerCounter++;                              // ★ 번호를 올린다. 이름이 겹치지 않는다

        CanBuildTower[cellPosition] = createdTower;

        Tower tower = createdTower.GetComponent<Tower>();
        if (tower != null)                           // ★ 컴포넌트 누락 방어
        {
            tower.SetEnemeyMgr(enemyMgr);
        }
        else
        {
            Debug.LogError($"{buildTower.name} 에 Tower 컴포넌트가 없습니다.");
        }

        // 생성된 타워를 TowerMgr의 자식 노드로 설정
        createdTower.transform.SetParent(transform);  // ★ GetComponent<Transform>() → transform

        // ★ 골드를 실제로 깎는다. 교재에는 이 호출이 아예 없어 타워가 공짜였다.
        gameMgr.consumeGold(towerPrice);
    }
}
