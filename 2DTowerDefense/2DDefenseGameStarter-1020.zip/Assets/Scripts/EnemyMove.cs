using UnityEngine;
using UnityEngine.AI;

public class EnemyMove : MonoBehaviour
{
    //--- variables
    public Transform endObject;
    public float arrivalDistance = 0.1f;

    private NavMeshAgent enemyAgent;
    private EnemyMgr enemyMgr;
    private float sqrVelocityThreshold = 0.01f;   // 0.1 m/s 의 제곱

    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemyAgent = GetComponent<NavMeshAgent>();
        if (enemyAgent == null)
        {
            Debug.LogError("enemy Agent is None !");
            enabled = false;    // ★ Update 가 매 프레임 예외를 내지 않도록 끈다
            return;
        }

        // 2D NavMesh 에서 반드시 필요한 두 줄
        enemyAgent.updateRotation = false;
        enemyAgent.updateUpAxis = false;

        if (endObject == null)
        {
            Debug.LogError("endObject is None !");
            enabled = false;
            return;
        }

        enemyAgent.SetDestination(endObject.position);
    }

    // Update is called once per frame
    void Update()
    {
        if (!enemyAgent.pathPending &&
            enemyAgent.remainingDistance <= arrivalDistance &&
            (!enemyAgent.hasPath || enemyAgent.velocity.sqrMagnitude < sqrVelocityThreshold))
        {
            // 도착 시의 처리
            if (enemyMgr != null)
            {
                enemyMgr.DieEnemyAtDestination(gameObject);
            }
            Destroy(gameObject);
        }
    }

    //--- user-defined methods
    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        this.enemyMgr = enemyMgr;
    }

    public void SetTarget(Transform target)
    {
        if (target == null)
        {
            Debug.LogError("target is null!");
            return;
        }
        endObject = target;     // ★ 원본에 이 줄이 빠져 있었다
    }
}
