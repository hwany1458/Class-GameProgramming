using UnityEngine;

public class Projectile : MonoBehaviour
{
    [Header("발사체 설정")]
    public float moveSpeed = 5.0f;
    public float attackVal = 100.0f;
    public float lifeTime = 5f;      // 생존 시간(초)

    private Vector3 moveDirection = Vector3.zero;
    private Vector3 targetPosition;  // 목표 위치 저장
    private Transform targetObj;
    private float errorDistance = 0.1f;
    private EnemyMgr enemyMgr;

    private bool isHit = false;      // ★ 같은 프레임 중복 명중 방지

    // ★ 추가 — lifeTime 을 실제로 쓴다. 빗나간 발사체가 영원히 남지 않는다.
    private void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    // ★ 복원 — Tower 가 호출하는 세 함수
    public void SetDirection(Vector3 direction)
    {
        moveDirection = direction.normalized;
    }

    public void SetTarget(Transform target)
    {
        targetObj = target;
        if (target != null)
        {
            targetPosition = target.position;   // 목표가 죽어도 마지막 위치로 날아간다
        }
    }

    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        this.enemyMgr = enemyMgr;
    }

    // ★ 복원 — 이동 로직. 교재에 아예 없어서 발사체가 제자리에 있었다.
    private void Update()
    {
        if (targetObj != null)
        {
            // 목표가 살아 있으면 따라간다 (유도탄)
            targetPosition = targetObj.position;
        }
        else if (enemyMgr != null)
        {
            // ★ 목표가 죽었으면 근처의 다른 적으로 갈아탄다.
            //    교재가 넘겨 준 enemyMgr 을 여기서 쓴다.
            GameObject nextEnemy = enemyMgr.GetClosestEnemy(transform.position, 3.0f);
            if (nextEnemy != null)
            {
                targetObj = nextEnemy.transform;
                targetPosition = targetObj.position;
            }
        }

        Vector3 toTarget = targetPosition - transform.position;

        // 목표에 거의 닿았으면 방향을 다시 계산하지 않는다 (떨림 방지)
        if (toTarget.sqrMagnitude > errorDistance * errorDistance)
        {
            moveDirection = toTarget.normalized;
        }
        else if (targetObj == null)
        {
            // 목표가 사라진 자리에 도착했는데 맞힐 것이 없다 → 소멸
            Destroy(gameObject);
            return;
        }

        transform.Translate(moveDirection * moveSpeed * Time.deltaTime, Space.World);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isHit) return;                      // ★ 두 번 때리지 않는다

        // 충돌한 오브젝트 확인
        if (collision.CompareTag("Enemy"))
        {
            Enemy enemy = collision.gameObject.GetComponent<Enemy>();
            if (enemy != null)
            {
                isHit = true;                   // ★
                enemy.OnDamage(attackVal);
                Destroy(gameObject);
            }
        }
    }
}
