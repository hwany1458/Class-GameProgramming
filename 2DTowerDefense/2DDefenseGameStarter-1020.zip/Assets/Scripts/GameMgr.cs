using UnityEngine;

public class GameMgr : MonoBehaviour
{
    [Header("게임 설정")]
    public float curGold = 300;
    public float curHP = 100;

    private bool isGameOver = false;    // ★ 게임 오버가 두 번 울리는 것을 막는다

    public bool IsGameOver { get { return isGameOver; } }

    /// 가진 골드가 price 이상인지만 확인한다. 깎지는 않는다.
    public bool checkGold(float price)
    {
        return curGold >= price;        // ★ ? true : false 제거 — 비교식이 이미 bool
    }

    /// 골드를 깎는다. 모자라면 깎지 않고 false 를 돌려준다.
    public bool consumeGold(float price)    // ★ void → bool. 성공 여부를 알려 준다
    {
        if (!checkGold(price))              // ★ 잔액 검사 추가 — 음수 방지
        {
            Debug.Log($"골드가 부족하다. 필요 {price} / 보유 {curGold}");
            return false;
        }
        curGold -= price;
        Debug.Log($"골드 {price} 소모.  남은 골드 {curGold}");
        return true;
    }

    /// 적을 처치했을 때 등 골드를 얻는 통로.
    public void addGold(float amount)       // ★ 추가 — 경제가 한쪽으로만 흐르지 않게
    {
        curGold += amount;
        Debug.Log($"골드 {amount} 획득.  보유 골드 {curGold}");
    }

    /// 적이 목적지에 도달했을 때 EnemyMgr 이 호출한다.
    public void damageHP(float damage)
    {
        if (isGameOver) return;             // ★ 이미 끝났으면 더 깎지 않는다

        curHP -= damage;
        if (curHP <= 0)
        {
            curHP = 0;                      // ★ 음수로 내려가지 않게 고정
            GameOver();
        }
        Debug.Log($"HP {damage} 감소.  남은 HP {curHP}");
    }

    private void GameOver()
    {
        isGameOver = true;                  // ★ 플래그를 세운다
        Debug.Log("Game Over");

        // 적 생성을 멈춘다. UI 를 붙일 자리이기도 하다.
        EnemyMgr enemyMgr = FindFirstObjectByType<EnemyMgr>();   // ★ 추가
        if (enemyMgr != null)
        {
            enemyMgr.StopGame();
        }
    }
}
