using UnityEngine;
using UnityEngine.AI;

public class ForceNavMoveOriginal : MonoBehaviour
{
    //--- variables
    public Transform endObject;
    private NavMeshAgent enemyAgent;

    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemyAgent = GetComponent<NavMeshAgent>();
        enemyAgent.updateRotation = false;
        enemyAgent.updateUpAxis = false;
        enemyAgent.SetDestination(endObject.transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
