using UnityEngine;

public class EnemyOriginal : MonoBehaviour
{
    //--- variables
    [Header("적에 대한 속성 설정")]
    public float hpValue = 100.0f; // 적의 체력 설정

    private EnemyMgr enemyMgr;

    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //--- user-defined methods
    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        this.enemyMgr = enemyMgr;
    }
    public void OnDamage(float damageValue)
    {
        hpValue -= damageValue;
        if (hpValue <= 0)
        {
            hpValue = 0;
            enemyMgr.DieEnemy(gameObject);
            Destroy(gameObject);
        }
    }
}
