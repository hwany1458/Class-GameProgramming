using UnityEngine;
using UnityEngine.AI;

public class EnemyMoveOriginal : MonoBehaviour
{
    //--- variables
    public Transform endObject;
    public float arrivalDistance = 0.1f;
    private NavMeshAgent enemyAgent;
    private EnemyMgr enemyMgr;
    private float velocityThreshold = 0.1f;

    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemyAgent = GetComponent<NavMeshAgent>();
        if (enemyAgent == null)
        {
            Debug.LogError("emeny Agent is None !");
            return;
        }
        enemyAgent.updateRotation = false;
        enemyAgent.updateUpAxis = false;
        if (endObject == null)
        {
            Debug.LogError("endObject is None !");
            return;
        }
        enemyAgent.SetDestination(endObject.transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        if (!enemyAgent.pathPending && enemyAgent.remainingDistance <=
                                                    arrivalDistance &&
           (!enemyAgent.hasPath || enemyAgent.velocity.sqrMagnitude <
                                                    velocityThreshold))
        {
            // 도착 시의 처리
            enemyMgr.DieEnemyAtDestination(gameObject);
            Destroy(gameObject);
        }
    }

    //--- user-defined methods
    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        this.enemyMgr = enemyMgr;
    }

    public void SetTarget(Transform target)
    {
        if (target == null)
        {
            Debug.LogError("target is null!");
            return;
        }
    }
}
