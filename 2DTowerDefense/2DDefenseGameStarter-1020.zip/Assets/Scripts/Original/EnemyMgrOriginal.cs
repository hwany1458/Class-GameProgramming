using UnityEngine;
using System.Collections.Generic;

/*
[System.Serializable]
public class EnemyWaveData
{
    public int enemyCount; // 이 웨이브에서 생성할 적의 수
    public float spawnInterval; // 적 생성 간격(초)
    public float delayBeforeNextWave; // 다음 웨이브까지의 대기 시간
}
*/

public class EnemyMgrOriginal : MonoBehaviour
{
    //--- variables
    [Header("적 생성을 위한 속성 설정")]
    public Transform startPoint;
    public Transform endPoint;
    public GameObject enemyPrefab; // 생성할 적 프리팹
    public List<EnemyWaveData> waves = new List<EnemyWaveData>(); // 웨이브 설정

    private bool isStartGame = false;
    private bool isSpawningWave = false;
    private bool isWaitNextWave = false;
    private int spawnedEnemyNumInWave = 0;
    private int curWaveIdx;
    private List<GameObject> enemyListinCurWave = new List<GameObject>();

    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //--- user-defined methods
    private void SpawnEnemyRoutine()
    {
        EnemyWaveData currentWave = waves[curWaveIdx];
        if (curWaveIdx >= waves.Count)
        {
            //CompleteGame();
            return;
        }
        SpawnEnemy();
        // 현재 Wave의 최대 적 수만큼 생성되지 않았으면 반복 생성
        if (spawnedEnemyNumInWave + 1 < currentWave.enemyCount)
        {
            InvokeRepeating("SpawnEnemy", currentWave.spawnInterval, currentWave.spawnInterval);
        }
    }
    private void SpawnEnemy()
    {
        EnemyWaveData currentWave = waves[curWaveIdx];
        GameObject enemyObject = Instantiate(enemyPrefab, startPoint.position, Quaternion.identity);
        EnemyMove enemyMove = enemyObject.GetComponent<EnemyMove>();
        Enemy enemy = enemyObject.GetComponent<Enemy>();
        if (enemyMove != null)
        {
            enemyMove.SetTarget(endPoint);
            //enemy.SetEnemeyMgr(this);
            //enemyMove.SetEnemeyMgr(this);
            enemyListinCurWave.Add(enemyObject);
            Debug.Log($"웨이브 {curWaveIdx} 시작! " + $"({spawnedEnemyNumInWave} 적)");
            spawnedEnemyNumInWave++;
            if (spawnedEnemyNumInWave >= currentWave.enemyCount)
            {
                isSpawningWave = false;
                CancelInvoke("SpawnEnemy");
            }
        }
    }
}
