using UnityEngine;

public class ProjectileOriginal : MonoBehaviour
{
    [Header("발사체 설정")]
    public float moveSpeed = 5.0f;
    public float attackVal = 100.0f;
    public float lifeTime = 5f;      // 생존 시간(초)

    private Vector3 moveDirection = Vector3.zero;
    private Vector3 targetPosition;  // 목표 위치 저장
    private Transform targetObj;
    private float errorDistance = 0.1f;
    private EnemyMgr enemyMgr;

    // …생략…   

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // 충돌한 오브젝트 확인
        if (collision.CompareTag("Enemy"))
        {
            Enemy enemy = collision.gameObject.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.OnDamage(attackVal); // 함수명 수정
                Destroy(gameObject); // 오브젝트 삭제로 수정
            }
        }
    }

    // …생략…   
}
