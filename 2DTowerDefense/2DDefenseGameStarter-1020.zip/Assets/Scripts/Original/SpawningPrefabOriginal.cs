using UnityEngine;

public class SpawningPrefabOriginal : MonoBehaviour
{
    //--- variables
    public GameObject prefab;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Instantiate(prefab, new Vector3(3, 3, -3), Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
