using UnityEngine;

public class TowerOriginal : MonoBehaviour
{

    void FixedUpdate()
    {
        /*
        curAttackTime += Time.fixedDeltaTime;

        // 사정거리 안의 적을 탐색하여 가장 가까운 적을 확인
        if (curAttackTime > waitAttackTime)
        {
            if (this.enemyMgr)
            {
                findEnemy = this.enemyMgr.GetClosestEnemy(transform.position, attackRange);
                if (findEnemy)
                {
                    GameObject projectileObject = Instantiate(
                                        projectTile,
                                        this.transform.position,
                                        Quaternion.identity
                    );
                    Projectile createdProjectile = projectileObject.GetComponent<Projectile>();
                    createdProjectile.SetDirection(targetDir);
                    createdProjectile.SetTarget(findEnemy.transform);
                    createdProjectile.SetEnemeyMgr(this.enemyMgr);
                }
            }
            curAttackTime = 0.0f;
        }
        */
    }

    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        //this.enemyMgr = enemyMgr;
    }
}
