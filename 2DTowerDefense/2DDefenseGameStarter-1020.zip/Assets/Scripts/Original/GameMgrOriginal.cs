using UnityEngine;
public class GameMgrOriginal : MonoBehaviour
{
    [Header("게임 설정")]
    public float curGold = 300;
    public float curHP = 100;

    public bool checkGold(float price)
    {
        return this.curGold >= price ? true : false;
    }
    public void consumeGold(float price)
    {
        this.curGold -= price;
    }
    public void damageHP(float damage)
    {
        this.curHP -= damage;
        if (this.curHP <= 0)
        {
            this.GameOver();
        }
    }
    private void GameOver()
    {
        // GameOver 처리
        Debug.Log("Game Over");
    }
}
