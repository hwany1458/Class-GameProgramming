using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class TowerMgrOriginal : MonoBehaviour
{
    public Tilemap    buildTileMap;
    public GameObject buildTower;
    public EnemyMgr   enemyMgr;
    public GameMgr    gameMgr;
    public float      towerPrice = 100.0f;

    // 타일 위에 배치된 타워의 정보 관리
    private Dictionary<Vector3Int, GameObject> CanBuildTower =
            new Dictionary<Vector3Int, GameObject>();
    private Camera mainCamera;
    private int towerCounter = 0; // 타워 번호 카운팅

    // …생략…   

    void BuildTower()
    {
        Vector2 mousePos = Mouse.current.position.ReadValue();
        Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(
                new Vector3(mousePos.x, mousePos.y,
                            mainCamera.nearClipPlane // 적절한 Z 거리
                )
        );
        Vector3Int cellPosition = buildTileMap.WorldToCell(mouseWorldPos);
        // 해당 위치에 타일이 있는지 확인
        if (CanBuildTower.ContainsKey(cellPosition))
            return;
        TileBase subTile = buildTileMap.GetTile(cellPosition);

        /*
        if (subTile && checkGold(towerPrice))
        {
            Vector3 worldPosition = buildTileMap.CellToWorld(cellPosition);
            Vector3 centerPosition = worldPosition + buildTileMap.cellSize * 0.5f;
            GameObject createdTower = Instantiate(buildTower, centerPosition,
                                    Quaternion.identity
            );
            createdTower.name = "BasicTower_Pos(" + cellPosition.x + "," + cellPosition.y +
                                ")_ID" + towerCounter;
            CanBuildTower[cellPosition] = createdTower;
            createdTower.GetComponent<Tower>().SetEnemeyMgr(enemyMgr);
            // 생성된 타워를 TowerMgr의 자식 노드로 설정
            createdTower.transform.SetParent(GetComponent<Transform>());
        }
        */
    }

    // …생략…   
}
