using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EnemyWaveData
{
    public int enemyCount;              // 이 웨이브에서 생성할 적의 수
    public float spawnInterval;         // 적 생성 간격(초)
    public float delayBeforeNextWave;   // 다음 웨이브까지의 대기 시간
}

public class EnemyMgr : MonoBehaviour
{
    [Header("적 생성을 위한 속성 설정")]
    public Transform startPoint;
    public Transform endPoint;
    public GameObject enemyPrefab;                                  // 생성할 적 프리팹
    public List<EnemyWaveData> waves = new List<EnemyWaveData>();   // 웨이브 설정

    [Header("게임 관리")]
    public GameMgr gameMgr;                 // CurGameMgr 오브젝트를 지정
    public float enemyDamage = 10.0f;       // 적 1마리가 목적지에 닿을 때 깎이는 HP
    public float killReward = 20.0f;        // 적 1마리를 처치했을 때 얻는 골드

    private bool isStartGame = false;
    private bool isSpawningWave = false;
    private bool isWaitNextWave = false;
    private int spawnedEnemyNumInWave = 0;
    private int curWaveIdx = 0;
    private List<GameObject> enemyListinCurWave = new List<GameObject>();

    // ---------------------------------------------------------------- 시작

    private void Awake()
    {
        // 이 줄이 Console 에 안 보이면 이 스크립트 자체가 실행되지 않는 것이다
        Debug.Log("[EnemyMgr] Awake — 스크립트가 살아 있다");
    }

    private void Start()
    {
        Debug.Log("[EnemyMgr] Start 진입");

        if (gameMgr == null)
        {
            gameMgr = FindFirstObjectByType<GameMgr>();  // 지정을 깜빡해도 찾아 본다
        }
        StartGame();
    }

    /// Inspector 의 컴포넌트 헤더(⋮)에서 직접 실행할 수도 있다
    [ContextMenu("웨이브 지금 시작")]
    public void StartGame()
    {
        Debug.Log($"[EnemyMgr] StartGame 호출 — waves {waves.Count}개, "
                + $"startPoint {(startPoint == null ? "없음" : startPoint.name)}, "
                + $"enemyPrefab {(enemyPrefab == null ? "없음" : enemyPrefab.name)}");

        if (startPoint == null || endPoint == null || enemyPrefab == null)
        {
            Debug.LogError("EnemyMgr : startPoint / endPoint / enemyPrefab 을 Inspector 에 지정하세요.");
            return;
        }
        if (waves.Count == 0)
        {
            Debug.LogError("EnemyMgr : waves 리스트가 비어 있습니다.");
            return;
        }

        CancelInvoke();
        isStartGame = true;
        isSpawningWave = false;
        isWaitNextWave = false;
        curWaveIdx = 0;
        enemyListinCurWave.Clear();
        SpawnEnemyRoutine();
    }

    /// GameMgr 이 게임 오버일 때 호출한다. 더 이상 적을 만들지 않는다.
    public void StopGame()
    {
        isStartGame = false;
        CancelInvoke();
        Debug.Log("[EnemyMgr] 적 생성을 중단했다");
    }

    // ---------------------------------------------------------------- 웨이브

    private void SpawnEnemyRoutine()
    {
        if (!isStartGame) return;

        // 범위 검사를 리스트 접근보다 먼저 한다
        if (curWaveIdx >= waves.Count)
        {
            CompleteGame();
            return;
        }

        EnemyWaveData currentWave = waves[curWaveIdx];

        // 적 수가 0 이하면 이 웨이브는 건너뛴다
        if (currentWave.enemyCount <= 0)
        {
            Debug.LogWarning($"웨이브 {curWaveIdx} 의 Enemy Count 가 {currentWave.enemyCount} 이라 건너뛴다");
            curWaveIdx++;
            SpawnEnemyRoutine();
            return;
        }

        Debug.Log($"웨이브 {curWaveIdx} 시작!  (적 {currentWave.enemyCount}마리)");

        isSpawningWave = true;
        isWaitNextWave = false;
        spawnedEnemyNumInWave = 0;
        enemyListinCurWave.Clear();

        SpawnEnemy();   // 첫 마리는 바로 생성

        // SpawnEnemy() 안에서 이미 1 증가했으므로 + 1 을 더하면 안 된다
        if (spawnedEnemyNumInWave < currentWave.enemyCount)
        {
            float interval = Mathf.Max(0.1f, currentWave.spawnInterval);
            InvokeRepeating("SpawnEnemy", interval, interval);
        }
    }

    private void SpawnEnemy()
    {
        EnemyWaveData currentWave = waves[curWaveIdx];
        GameObject enemyObject = Instantiate(enemyPrefab, startPoint.position, Quaternion.identity);

        EnemyMove enemyMove = enemyObject.GetComponent<EnemyMove>();
        Enemy enemy = enemyObject.GetComponent<Enemy>();

        // 둘 중 하나라도 없으면 더 만들어 봐야 소용없다
        if (enemyMove == null || enemy == null)
        {
            Debug.LogError($"적 프리팹 '{enemyPrefab.name}' 에 EnemyMove 또는 Enemy 컴포넌트가 없습니다.");
            Destroy(enemyObject);
            isSpawningWave = false;
            CancelInvoke("SpawnEnemy");
            return;
        }

        enemyMove.SetTarget(endPoint);
        enemy.SetEnemeyMgr(this);
        enemyMove.SetEnemeyMgr(this);
        enemyListinCurWave.Add(enemyObject);

        spawnedEnemyNumInWave++;
        Debug.Log($"적 생성  {spawnedEnemyNumInWave} / {currentWave.enemyCount}");

        if (spawnedEnemyNumInWave >= currentWave.enemyCount)
        {
            isSpawningWave = false;
            CancelInvoke("SpawnEnemy");
        }
    }

    // ---------------------------------------------------------------- 타워가 쓰는 함수

    /// position 에서 range 안에 있는 적 중 가장 가까운 것을 돌려준다. 없으면 null.
    /// Tower 와 Projectile 이 호출한다. 교재에는 정의가 빠져 있다.
    public GameObject GetClosestEnemy(Vector3 position, float range)
    {
        GameObject closest = null;
        float closestSqr = range * range;   // 제곱끼리 비교해 제곱근 연산을 피한다

        for (int i = 0; i < enemyListinCurWave.Count; i++)
        {
            GameObject enemyObject = enemyListinCurWave[i];
            if (enemyObject == null) continue;          // 이미 파괴된 적은 건너뛴다

            float sqr = (enemyObject.transform.position - position).sqrMagnitude;
            if (sqr <= closestSqr)
            {
                closestSqr = sqr;
                closest = enemyObject;
            }
        }
        return closest;
    }

    // ---------------------------------------------------------------- 적의 퇴장

    /// 적이 체력을 다 잃고 죽었을 때 — Enemy.OnDamage() 가 호출한다
    public void DieEnemy(GameObject enemyObject)
    {
        if (gameMgr != null)
        {
            gameMgr.addGold(killReward);    // 처치 보상
        }
        RemoveEnemy(enemyObject);
    }

    /// 적이 목적지에 도달했을 때 — EnemyMove.Update() 가 호출한다
    public void DieEnemyAtDestination(GameObject enemyObject)
    {
        if (gameMgr != null)
        {
            gameMgr.damageHP(enemyDamage);  // 교재에 없던 연결. HP 가 여기서 깎인다.
        }
        else
        {
            Debug.LogWarning("적이 목적지에 도달했지만 GameMgr 이 연결되지 않아 HP 가 깎이지 않는다");
        }
        RemoveEnemy(enemyObject);
    }

    private void RemoveEnemy(GameObject enemyObject)
    {
        enemyListinCurWave.Remove(enemyObject);
        CheckWaveClear();
    }

    // ---------------------------------------------------------------- 웨이브 전환

    private void CheckWaveClear()
    {
        if (!isStartGame) return;
        if (isWaitNextWave) return;                 // 이미 다음 웨이브를 기다리는 중
        if (isSpawningWave) return;                 // 아직 생성이 끝나지 않음
        if (enemyListinCurWave.Count > 0) return;   // 아직 살아 있는 적이 있음

        isWaitNextWave = true;
        float delay = waves[curWaveIdx].delayBeforeNextWave;
        curWaveIdx++;

        Debug.Log($"웨이브 클리어.  {delay}초 뒤 다음 웨이브");
        Invoke("SpawnEnemyRoutine", delay);
    }

    // ---------------------------------------------------------------- 끝

    private void CompleteGame()
    {
        isStartGame = false;
        CancelInvoke();
        Debug.Log("모든 웨이브를 막아 냈다 — 게임 완료!");
    }
}