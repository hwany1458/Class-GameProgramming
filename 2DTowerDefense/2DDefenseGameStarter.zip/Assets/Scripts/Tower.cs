// ============================================================================
//  Tower.cs  —  수정본  (교재 코드 14-5 / PPT 54~55쪽)
// ----------------------------------------------------------------------------
//  ★ 표시가 교재 원본에서 고치거나 채워 넣은 자리다.
//  교재 05~13행(필드 선언)이 슬라이드에서 빠져 있어 복원했다.
//  FixedUpdate 의 구조와 변수 이름은 교재 그대로 두었다.
//
//  필요 조건
//   · EnemyMgr 에 GetClosestEnemy(Vector3, float) 가 있어야 한다
//     (수정본 EnemyMgr.cs 참고)
//   · projectTile 에 Projectile 프리팹을 Inspector 에서 할당해야 한다
// ============================================================================

using UnityEngine;

public class Tower : MonoBehaviour
{
    // ★ 교재 05~13행 복원 — 슬라이드에 실려 있지 않던 필드 선언
    [Header("타워 설정")]
    public GameObject projectTile;          // 발사체 프리팹 (교재 표기 그대로)
    public float attackRange = 3.0f;        // 사정거리
    public float waitAttackTime = 1.0f;     // 공격 간격(초)

    private float curAttackTime = 0.0f;
    private EnemyMgr enemyMgr;
    private GameObject findEnemy;
    private Vector3 targetDir = Vector3.zero;

    void FixedUpdate()
    {
        curAttackTime += Time.fixedDeltaTime;

        // 사정거리 안의 적을 탐색하여 가장 가까운 적을 확인
        if (curAttackTime > waitAttackTime)
        {
            if (enemyMgr != null)
            {
                findEnemy = enemyMgr.GetClosestEnemy(transform.position, attackRange);

                if (findEnemy != null)
                {
                    if (projectTile == null)        // ★ 프리팹 미할당 방어
                    {
                        Debug.LogError($"{name} : Project Tile 에 발사체 프리팹을 지정하세요.");
                        curAttackTime = 0.0f;
                        return;
                    }

                    // ★ 교재에 없던 핵심 한 줄.
                    //    targetDir 을 계산하지 않으면 발사체가 제자리에 머문다.
                    targetDir = (findEnemy.transform.position - transform.position).normalized;

                    GameObject projectileObject = Instantiate(
                                        projectTile,
                                        transform.position,
                                        Quaternion.identity);

                    Projectile createdProjectile =
                            projectileObject.GetComponent<Projectile>();

                    if (createdProjectile == null)  // ★ 컴포넌트 누락 방어
                    {
                        Debug.LogError($"{projectTile.name} 에 Projectile 컴포넌트가 없습니다.");
                        Destroy(projectileObject);
                        curAttackTime = 0.0f;
                        return;
                    }

                    createdProjectile.SetDirection(targetDir);
                    createdProjectile.SetTarget(findEnemy.transform);
                    createdProjectile.SetEnemeyMgr(enemyMgr);
                }
            }
            curAttackTime = 0.0f;
        }
    }

    public void SetEnemeyMgr(EnemyMgr enemyMgr)
    {
        this.enemyMgr = enemyMgr;
    }

    // ★ 추가 — Scene 뷰에서 사정거리를 눈으로 확인한다.
    //    타워를 선택하면 노란 원이 그려진다. 값 조정할 때 아주 편하다.
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}
