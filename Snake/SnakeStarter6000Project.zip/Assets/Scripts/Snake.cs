using UnityEngine;
using UnityEngine.UI;

public class Snake : MonoBehaviour
{
    //--- variables
    // 이동속도, 회전속도 등 필요한 변수 선언

    // 사망 여부 체크

    // Coin 객체 참조

    // 오브젝트의 Transform을 저장할 List 생성

    // UI



    //--- methods
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Awake()
    {
        // 초기화 로직 구현
        InitializeGame();
    }
    // 충돌 판정과 처리
    void OnCollisionEnter(Collision collision)
    {
        // 충돌 처리 로직 구현
    }

    void OnTriggerEnter(Collider other)
    {
        // 트리거 처리 로직 구현
    }

    // Button Click Event
    public void OnButtonClick(Button button)
    {
        // 버튼 클릭 이벤트 처리 로직 구현
    }

    //--- user-defined methods
    // 게임 초기화
    void InitializeGame()
    {
        // 게임 초기화 로직 구현
    }

    // 머리 이동 및 회전
    void MoveHead()
    {
        // 머리 이동 및 회전 로직 구현
    }

    // Coin 이동 (OR Coin 객체 파괴, 랜덤위치로 새로 생성)
    void MoveCoin()
    {
        // Coin 이동 로직 구현
    }

    // 꼬리 추가
    void AddTail()
    {
        // 꼬리 추가 로직 구현
    }

    // 꼬리 이동 및 회전
    void MoveTail()
    {
        // 꼬리 이동 및 회전 로직 구현
    }

    // UI Time
    void SetTime()
    {
        // UI Time 설정 로직 구현
    }
}
