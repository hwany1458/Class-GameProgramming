var group__save =
[
    [ "HappyHarvest.PlayerSaveData", "structHappyHarvest_1_1PlayerSaveData.html", [
      [ "Position", "structHappyHarvest_1_1PlayerSaveData.html#aa1208c512f63563ae6ecc32a9ca060c5", null ],
      [ "Coins", "structHappyHarvest_1_1PlayerSaveData.html#a8491ca4d43218f76ec9ee9f2ef8234d9", null ],
      [ "Inventory", "structHappyHarvest_1_1PlayerSaveData.html#af038521c26071f70f6fba70e808fa866", null ]
    ] ],
    [ "HappyHarvest.TerrainDataSave", "structHappyHarvest_1_1TerrainDataSave.html", [
      [ "GroundDataPositions", "structHappyHarvest_1_1TerrainDataSave.html#ab5525032c00f9492825f13f9b8a2c466", null ],
      [ "GroundDatas", "structHappyHarvest_1_1TerrainDataSave.html#ab95787b820a031281d1737f2ab981d6f", null ],
      [ "CropDataPositions", "structHappyHarvest_1_1TerrainDataSave.html#a4e95e483bf3a841fe859a059dd495f40", null ],
      [ "CropDatas", "structHappyHarvest_1_1TerrainDataSave.html#a3d0efa417af2ab9ed6a9ae4a37759d5b", null ]
    ] ],
    [ "HappyHarvest.InventorySaveData", "classHappyHarvest_1_1InventorySaveData.html", [
      [ "Amount", "classHappyHarvest_1_1InventorySaveData.html#ad0f0e02c4d3cb7d0092ef5d309cab03f", null ],
      [ "ItemID", "classHappyHarvest_1_1InventorySaveData.html#a90543790fe47b8785be47fedf3d8183a", null ]
    ] ],
    [ "HappyHarvest.DayCycleHandlerSaveData", "structHappyHarvest_1_1DayCycleHandlerSaveData.html", [
      [ "TimeOfTheDay", "structHappyHarvest_1_1DayCycleHandlerSaveData.html#a2700d82df38b458ed93e83a9af1831a8", null ]
    ] ],
    [ "HappyHarvest.SaveSystem", "classHappyHarvest_1_1SaveSystem.html", [
      [ "SaveData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html", [
        [ "PlayerData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#a31888fa88fa51b5bdfbc7655668a621e", null ],
        [ "TimeSaveData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#aebdb7c9e7a957314058d8414e39f8083", null ],
        [ "ScenesData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#a7ed11dd86210070aa8ac8fb43d9810e3", null ]
      ] ],
      [ "SceneData", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html", [
        [ "SceneName", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html#ad0f6e19f1a66d25f4a76650648f6e640", null ],
        [ "TerrainData", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html#affde79aac61935c04c3b9e40d72985c5", null ]
      ] ],
      [ "Save", "classHappyHarvest_1_1SaveSystem.html#a57d2f0c369d7588bf5a5bd867e956b52", null ],
      [ "Load", "classHappyHarvest_1_1SaveSystem.html#a82cd919e35815e9acaf4fff5fa946bba", null ],
      [ "SceneLoaded", "classHappyHarvest_1_1SaveSystem.html#a61d3b7e418668898bde52063d2a0cd86", null ],
      [ "SaveSceneData", "classHappyHarvest_1_1SaveSystem.html#aa36d8b033f2fc59ddd7428919076a4c7", null ],
      [ "LoadSceneData", "classHappyHarvest_1_1SaveSystem.html#a5b54492c2c08a9c57e5b4b8b777c4dda", null ],
      [ "s_CurrentData", "classHappyHarvest_1_1SaveSystem.html#ac4388ec5da56935607654ae4062faa92", null ],
      [ "s_ScenesDataLookup", "classHappyHarvest_1_1SaveSystem.html#a2d7f1b806bde21f2d833e8b56d8eb412", null ]
    ] ]
];