var structHappyHarvest_1_1DayCycleHandlerSaveData =
[
    [ "TimeOfTheDay", "structHappyHarvest_1_1DayCycleHandlerSaveData.html#a2700d82df38b458ed93e83a9af1831a8", null ]
];