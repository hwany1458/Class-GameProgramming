var classTemplate2DCommon_1_1SoundManager_1_1SoundData =
[
    [ "MainVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#a983c3b9a4eaa89924ce50e03e8851430", null ],
    [ "BGMVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#ae75f03c5a413812e30ea5f01e9519703", null ],
    [ "SFXVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#a95d1f3399fa5db00511a12ec49365784", null ]
];