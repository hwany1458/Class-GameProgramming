var SaveSystem_8cs =
[
    [ "HappyHarvest.SaveSystem.SaveData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html", "structHappyHarvest_1_1SaveSystem_1_1SaveData" ],
    [ "HappyHarvest.SaveSystem.SceneData", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html", "structHappyHarvest_1_1SaveSystem_1_1SceneData" ]
];