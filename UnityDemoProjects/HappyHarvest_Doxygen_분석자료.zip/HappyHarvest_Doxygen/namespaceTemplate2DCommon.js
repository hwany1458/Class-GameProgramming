var namespaceTemplate2DCommon =
[
    [ "SettingMenu", "classTemplate2DCommon_1_1SettingMenu.html", "classTemplate2DCommon_1_1SettingMenu" ],
    [ "SoundManager", "classTemplate2DCommon_1_1SoundManager.html", "classTemplate2DCommon_1_1SoundManager" ]
];