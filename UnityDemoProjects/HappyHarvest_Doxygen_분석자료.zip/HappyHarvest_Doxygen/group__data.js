var group__data =
[
    [ "HappyHarvest.IDatabaseEntry", "interfaceHappyHarvest_1_1IDatabaseEntry.html", [
      [ "Key", "interfaceHappyHarvest_1_1IDatabaseEntry.html#ace76616f945b53241885a231db903d62", null ]
    ] ],
    [ "HappyHarvest.BaseDatabase< T >", "classHappyHarvest_1_1BaseDatabase.html", [
      [ "GetFromID", "classHappyHarvest_1_1BaseDatabase.html#ac8772b588bf088d816f53a9323e253e0", null ],
      [ "Init", "classHappyHarvest_1_1BaseDatabase.html#a955bd5ac087429433c2641e727d0dd2d", null ],
      [ "Entries", "classHappyHarvest_1_1BaseDatabase.html#a0882f44afae4523a13ff3df59279834f", null ],
      [ "m_LookupDictionnary", "classHappyHarvest_1_1BaseDatabase.html#add82014f205aacae1a4f0089f43deef8", null ]
    ] ],
    [ "HappyHarvest.ItemDatabase", "classHappyHarvest_1_1ItemDatabase.html", null ],
    [ "HappyHarvest.CropDatabase", "classHappyHarvest_1_1CropDatabase.html", null ]
];