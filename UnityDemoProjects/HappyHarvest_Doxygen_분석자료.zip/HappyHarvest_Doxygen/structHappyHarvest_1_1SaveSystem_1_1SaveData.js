var structHappyHarvest_1_1SaveSystem_1_1SaveData =
[
    [ "PlayerData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#a31888fa88fa51b5bdfbc7655668a621e", null ],
    [ "TimeSaveData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#aebdb7c9e7a957314058d8414e39f8083", null ],
    [ "ScenesData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html#a7ed11dd86210070aa8ac8fb43d9810e3", null ]
];