var group__timeweather =
[
    [ "HappyHarvest.DayCycleHandler", "classHappyHarvest_1_1DayCycleHandler.html", [
      [ "Awake", "classHappyHarvest_1_1DayCycleHandler.html#afd76ee441a31bffe4d6db2789354d24f", null ],
      [ "Tick", "classHappyHarvest_1_1DayCycleHandler.html#a9a9a7a2f13adc1b84f63903f07054c49", null ],
      [ "UpdateLight", "classHappyHarvest_1_1DayCycleHandler.html#af302a3be6f9368d5f5b3012476f4b595", null ],
      [ "UpdateShadow", "classHappyHarvest_1_1DayCycleHandler.html#aca68bb5592623fed8d5f575fb06da3b9", null ],
      [ "Save", "classHappyHarvest_1_1DayCycleHandler.html#a8594c3d45d578c2c3925cfff0baa9171", null ],
      [ "Load", "classHappyHarvest_1_1DayCycleHandler.html#a657a24676104bc8a9f9fa4ffb19afcf2", null ],
      [ "RegisterShadow", "classHappyHarvest_1_1DayCycleHandler.html#aaa11dc4ed8f756512b6104ac9e749482", null ],
      [ "UnregisterShadow", "classHappyHarvest_1_1DayCycleHandler.html#aaf3ca0827fd5c006724d1bb6b8adb44e", null ],
      [ "RegisterLightBlender", "classHappyHarvest_1_1DayCycleHandler.html#a797e4050cc286ac18e7ed1f0491acf75", null ],
      [ "UnregisterLightBlender", "classHappyHarvest_1_1DayCycleHandler.html#a9770d2fb23fe05025c09d46ed67a7d95", null ],
      [ "LightsRoot", "classHappyHarvest_1_1DayCycleHandler.html#a98c7dfbc3cd645701850577cb186aea3", null ],
      [ "DayLight", "classHappyHarvest_1_1DayCycleHandler.html#a04b7650602a20d5971a38c2c5f782521", null ],
      [ "DayLightGradient", "classHappyHarvest_1_1DayCycleHandler.html#a24319070d25cdcfc1d309f1dd8d7c5d2", null ],
      [ "NightLight", "classHappyHarvest_1_1DayCycleHandler.html#ae15b8950c019c473275ee54c690a810b", null ],
      [ "NightLightGradient", "classHappyHarvest_1_1DayCycleHandler.html#a58bed928b81e01db7de46b7fc113733d", null ],
      [ "AmbientLight", "classHappyHarvest_1_1DayCycleHandler.html#a0b6725d7e17865be924466a726b6fe9d", null ],
      [ "AmbientLightGradient", "classHappyHarvest_1_1DayCycleHandler.html#a9ebf0a82e8803d7ea70cce9adb44a23b", null ],
      [ "SunRimLight", "classHappyHarvest_1_1DayCycleHandler.html#a75eba168bd93bea9a81ca29adb497cb8", null ],
      [ "SunRimLightGradient", "classHappyHarvest_1_1DayCycleHandler.html#a1eaafc51cce500322343d5ca6b9a3e22", null ],
      [ "MoonRimLight", "classHappyHarvest_1_1DayCycleHandler.html#a41aba0b2b75d6eff2f07fb15d98343df", null ],
      [ "MoonRimLightGradient", "classHappyHarvest_1_1DayCycleHandler.html#a741a0c67e51c5e50f40b84d1f5cb0fab", null ],
      [ "ShadowAngle", "classHappyHarvest_1_1DayCycleHandler.html#a8010f1e526755a80d65f33524c21284c", null ],
      [ "ShadowLength", "classHappyHarvest_1_1DayCycleHandler.html#af657d14c9d0957352b93b726705e2679", null ],
      [ "m_Shadows", "classHappyHarvest_1_1DayCycleHandler.html#aa98cc4265e062f9862717ff6725eedc0", null ],
      [ "m_LightBlenders", "classHappyHarvest_1_1DayCycleHandler.html#aa309de02e19a7a25eeb7fd684d19cf8f", null ]
    ] ],
    [ "HappyHarvest.DayEventHandler", "classHappyHarvest_1_1DayEventHandler.html", [
      [ "Start", "classHappyHarvest_1_1DayEventHandler.html#aa27cefecce7baa1031eb51896976c8dd", null ],
      [ "OnDisable", "classHappyHarvest_1_1DayEventHandler.html#a72b9fbcf289be07576635999d1a6abd3", null ],
      [ "Events", "classHappyHarvest_1_1DayEventHandler.html#a194aaf66e29c6fa1c38adccd3afba09b", null ]
    ] ],
    [ "HappyHarvest.DayEventHandler.DayEvent", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html", [
      [ "IsInRange", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html#a80b8b272dfe77024c7dda91786ac47af", null ],
      [ "StartTime", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html#ae3382054e0baa992fb75bfe96ff4ae7c", null ],
      [ "EndTime", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html#a011ddd84818caa49b56175165d6d5224", null ],
      [ "OnEvents", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html#aff265b87be9b36a0314c2a600b0da995", null ],
      [ "OffEvent", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html#aa6fdec0b137dc2e523f91e877ec682cd", null ]
    ] ],
    [ "HappyHarvest.WeatherSystem", "classHappyHarvest_1_1WeatherSystem.html", [
      [ "WeatherType", "classHappyHarvest_1_1WeatherSystem.html#a98ab340be5442e59f2aa2a3955f70ead", [
        [ "Sun", "classHappyHarvest_1_1WeatherSystem.html#a98ab340be5442e59f2aa2a3955f70eadaef6572e4cd58bb39a3f4e82fc64fe9f0", null ],
        [ "Rain", "classHappyHarvest_1_1WeatherSystem.html#a98ab340be5442e59f2aa2a3955f70eadade4eda51f409f7799a728d8725b340cd", null ],
        [ "Thunder", "classHappyHarvest_1_1WeatherSystem.html#a98ab340be5442e59f2aa2a3955f70eada7db228551936f49a61c6b965886ad840", null ]
      ] ],
      [ "Awake", "classHappyHarvest_1_1WeatherSystem.html#a1685619b257565c26ad5fad104ad11a4", null ],
      [ "Start", "classHappyHarvest_1_1WeatherSystem.html#a1c814df6b89deb294de3fa13e4472a4b", null ],
      [ "UnregisterElement", "classHappyHarvest_1_1WeatherSystem.html#abd88daad9919e6436fe83441bb4acc44", null ],
      [ "ChangeWeather", "classHappyHarvest_1_1WeatherSystem.html#a79d9e92c626ca1acdafda7a4aca7dbe8", null ],
      [ "FindAllElements", "classHappyHarvest_1_1WeatherSystem.html#a55240a01e52237018bdb8462331a4b8d", null ],
      [ "SwitchAllElementsToCurrentWeather", "classHappyHarvest_1_1WeatherSystem.html#a953eaf27e4b79d9033a1fa3b26c3cab9", null ],
      [ "EditorWeatherUpdate", "classHappyHarvest_1_1WeatherSystem.html#adbfc257718495e66baba8989091f9b69", null ],
      [ "StartingWeather", "classHappyHarvest_1_1WeatherSystem.html#a332e637e486d879883f9f46009ba8267", null ],
      [ "m_CurrentWeatherType", "classHappyHarvest_1_1WeatherSystem.html#a82ab13d81418b9df33db5dce7c3a8d75", null ],
      [ "m_Elements", "classHappyHarvest_1_1WeatherSystem.html#a4b2b0be60c4babf138fe2de4bf2ba70e", null ]
    ] ],
    [ "HappyHarvest.WeatherSystemElement", "classHappyHarvest_1_1WeatherSystemElement.html", [
      [ "OnDestroy", "classHappyHarvest_1_1WeatherSystemElement.html#a792ef528ff8c9ec4d552aa8a561acd8f", null ],
      [ "WeatherType", "classHappyHarvest_1_1WeatherSystemElement.html#a0b55dba61c3a0d7797c4b3884c8156da", null ]
    ] ],
    [ "HappyHarvest.LightInterpolator", "classHappyHarvest_1_1LightInterpolator.html", [
      [ "LightFrame", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html", [
        [ "ReferenceLight", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html#a568303fff792f796cb00926c4977530e", null ],
        [ "NormalizedTime", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html#ad7baa905fd766e233a1edbad050c6888", null ]
      ] ],
      [ "OnEnable", "classHappyHarvest_1_1LightInterpolator.html#a46647291cc15f0b981343a713553d981", null ],
      [ "OnDisable", "classHappyHarvest_1_1LightInterpolator.html#aa7050ececb9e3a50b14a5e93527235a8", null ],
      [ "SetRatio", "classHappyHarvest_1_1LightInterpolator.html#ac23cd9b62d2124d9bf23730ceb6b6f34", null ],
      [ "Interpolate", "classHappyHarvest_1_1LightInterpolator.html#aa395657e6d0e85848b2587c450ab7926", null ],
      [ "DisableAllLights", "classHappyHarvest_1_1LightInterpolator.html#aa17ab71ad7b968704d6b53467cdcdf04", null ],
      [ "TargetLight", "classHappyHarvest_1_1LightInterpolator.html#ac6549a9853f4f24fd7a02756ba9cfcfe", null ],
      [ "LightFrames", "classHappyHarvest_1_1LightInterpolator.html#a82cc60a13633588cfac15ebe923e1271", null ]
    ] ],
    [ "HappyHarvest.LightFlicker", "classHappyHarvest_1_1LightFlicker.html", [
      [ "Start", "classHappyHarvest_1_1LightFlicker.html#a0a8a6b91375ac787e4fce6ed19971b43", null ],
      [ "Update", "classHappyHarvest_1_1LightFlicker.html#aa8fcf5379b5ffc4d82c655ddba1d3ec0", null ],
      [ "PerlinNoise3D", "classHappyHarvest_1_1LightFlicker.html#afb42cef496f07bacdc682dfc2f7aa3cc", null ],
      [ "m_PositionJitterScale", "classHappyHarvest_1_1LightFlicker.html#a72621897d2220984c0830982cf2364ff", null ],
      [ "m_RotationJitterScale", "classHappyHarvest_1_1LightFlicker.html#ac837c7e9c68ee8eea423c8907a243e33", null ],
      [ "m_IntensityJitterScale", "classHappyHarvest_1_1LightFlicker.html#a1b0594eeb8133165f1b1d69504bfb527", null ],
      [ "m_Timescale", "classHappyHarvest_1_1LightFlicker.html#a3070df9132989d424b6c3c36f89560ce", null ],
      [ "m_InitialPosition", "classHappyHarvest_1_1LightFlicker.html#afcd9089aeb123aabefda1a72b50045b6", null ],
      [ "m_InitialIntensity", "classHappyHarvest_1_1LightFlicker.html#a185ad8668b46808eb375ae78dcc53abb", null ],
      [ "m_InitialRotation", "classHappyHarvest_1_1LightFlicker.html#a5a79013e6f3fffee981739bc26f329a7", null ],
      [ "m_XSeed", "classHappyHarvest_1_1LightFlicker.html#ae5906d3d39252be623386a1701895ecf", null ],
      [ "m_YSeed", "classHappyHarvest_1_1LightFlicker.html#a8979e5430e943c89fb86c8af04fb15b7", null ],
      [ "m_ZSeed", "classHappyHarvest_1_1LightFlicker.html#abc4f569c9917fa7415bb9c7bf60122d7", null ],
      [ "m_Light", "classHappyHarvest_1_1LightFlicker.html#a0035ab3fab086f8c0930be71cf7577ac", null ],
      [ "m_flickerIntensityOffset", "classHappyHarvest_1_1LightFlicker.html#a51dd6a8f31007ef4c058d8ce08f95750", null ],
      [ "flickerIntensityOffset", "classHappyHarvest_1_1LightFlicker.html#afe4c6c86aae5020061548f3cd8f3cb84", null ],
      [ "modifiedIntensity", "classHappyHarvest_1_1LightFlicker.html#a2cb38b86d961aa8c0f583228303a4337", null ]
    ] ],
    [ "HappyHarvest.ShadowInstance", "classHappyHarvest_1_1ShadowInstance.html", [
      [ "OnEnable", "classHappyHarvest_1_1ShadowInstance.html#ac5e5efce7010f9adfe1530145a6781be", null ],
      [ "OnDisable", "classHappyHarvest_1_1ShadowInstance.html#a72121cf21bbf930c4a4b5370371194c9", null ],
      [ "BaseLength", "classHappyHarvest_1_1ShadowInstance.html#a25d0333a9dd7ae380b051099a259d86c", null ]
    ] ]
];