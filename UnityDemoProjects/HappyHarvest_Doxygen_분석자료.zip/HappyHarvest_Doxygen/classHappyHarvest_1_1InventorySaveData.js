var classHappyHarvest_1_1InventorySaveData =
[
    [ "Amount", "classHappyHarvest_1_1InventorySaveData.html#ad0f0e02c4d3cb7d0092ef5d309cab03f", null ],
    [ "ItemID", "classHappyHarvest_1_1InventorySaveData.html#a90543790fe47b8785be47fedf3d8183a", null ]
];