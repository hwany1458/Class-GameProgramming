var classHappyHarvest_1_1LightInterpolator_1_1LightFrame =
[
    [ "ReferenceLight", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html#a568303fff792f796cb00926c4977530e", null ],
    [ "NormalizedTime", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html#ad7baa905fd766e233a1edbad050c6888", null ]
];