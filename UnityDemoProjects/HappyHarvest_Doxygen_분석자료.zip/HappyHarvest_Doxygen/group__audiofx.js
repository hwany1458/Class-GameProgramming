var group__audiofx =
[
    [ "Template2DCommon.SoundManager", "classTemplate2DCommon_1_1SoundManager.html", [
      [ "SoundData", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html", [
        [ "MainVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#a983c3b9a4eaa89924ce50e03e8851430", null ],
        [ "BGMVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#ae75f03c5a413812e30ea5f01e9519703", null ],
        [ "SFXVolume", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html#a95d1f3399fa5db00511a12ec49365784", null ]
      ] ],
      [ "Awake", "classTemplate2DCommon_1_1SoundManager.html#aed5c0e4db14abf6fab8049b14d7933ef", null ],
      [ "Start", "classTemplate2DCommon_1_1SoundManager.html#affc37c70e1ba6ee2bf5b392a55a83708", null ],
      [ "UpdateVolume", "classTemplate2DCommon_1_1SoundManager.html#a640426da28c3ab6cf074e811bfadbd86", null ],
      [ "PlaySFXAt", "classTemplate2DCommon_1_1SoundManager.html#a0f887cc4178b69a6b4b6905225a162d8", null ],
      [ "PlayUISound", "classTemplate2DCommon_1_1SoundManager.html#a6a1cadb295a458d59ed774d4becb1765", null ],
      [ "Save", "classTemplate2DCommon_1_1SoundManager.html#a4d951cd82efdbccfdf34d30154a41271", null ],
      [ "Load", "classTemplate2DCommon_1_1SoundManager.html#a7c20d149b9b48cc65c79cc05f82cb8a9", null ],
      [ "Mixer", "classTemplate2DCommon_1_1SoundManager.html#addf9443a09fb54a2e81c8bc3e2c753ce", null ],
      [ "UISource", "classTemplate2DCommon_1_1SoundManager.html#a81b77a525cf7ac0b6744a3c471debca5", null ],
      [ "SFXReferenceSource", "classTemplate2DCommon_1_1SoundManager.html#a1c154a49d9f2a31aca5bd2d212e1820e", null ],
      [ "m_SFXPool", "classTemplate2DCommon_1_1SoundManager.html#a3c77111822ee9efab5092e7b1046c20a", null ],
      [ "Instance", "classTemplate2DCommon_1_1SoundManager.html#ad5c91b3bacb64dacd4f4922a26d29901", null ],
      [ "Sound", "classTemplate2DCommon_1_1SoundManager.html#a8af9772fe2d68fdf0e94999c281b1477", null ]
    ] ],
    [ "HappyHarvest.AmbienceBlender", "classHappyHarvest_1_1AmbienceBlender.html", [
      [ "State", "classHappyHarvest_1_1AmbienceBlender.html#af63b489683b121864fa327fd557ce0c1", [
        [ "BlendToNight", "classHappyHarvest_1_1AmbienceBlender.html#af63b489683b121864fa327fd557ce0c1afc5022e1deb996a6b208e0894b6742e3", null ],
        [ "BlendToDay", "classHappyHarvest_1_1AmbienceBlender.html#af63b489683b121864fa327fd557ce0c1af0ac5917ba3f20102e128c1d4c6117f7", null ],
        [ "Playing", "classHappyHarvest_1_1AmbienceBlender.html#af63b489683b121864fa327fd557ce0c1ac9dbb2b7c84159b632d71e512eba8428", null ]
      ] ],
      [ "Start", "classHappyHarvest_1_1AmbienceBlender.html#accc425b4622b6a8116d27832fd94846a", null ],
      [ "Update", "classHappyHarvest_1_1AmbienceBlender.html#aaf7a13bfae07d6a550a00b38287a9b36", null ],
      [ "AdvanceBlending", "classHappyHarvest_1_1AmbienceBlender.html#a7ed7c4eae2383ec1b7978089f9883913", null ],
      [ "BlendToDay", "classHappyHarvest_1_1AmbienceBlender.html#adc49f984527b76cf3c5b5afd71943092", null ],
      [ "BlendToNight", "classHappyHarvest_1_1AmbienceBlender.html#ac712bc33e9948b5035a4d0855bb6b4af", null ],
      [ "DayAmbienceSource", "classHappyHarvest_1_1AmbienceBlender.html#a17c6a1ec1985bed811e42980ab5c1a95", null ],
      [ "NightAmbienceSource", "classHappyHarvest_1_1AmbienceBlender.html#aaa0f5856d87d9b88283c3ba2daec611f", null ],
      [ "m_CurrentState", "classHappyHarvest_1_1AmbienceBlender.html#ad685cfb1aa3f421d40cbd4734d9e9190", null ],
      [ "m_CurrentBlendRatio", "classHappyHarvest_1_1AmbienceBlender.html#a27dced44ffb710cde2068303c2888db3", null ]
    ] ],
    [ "HappyHarvest.StepSoundHandler", "classHappyHarvest_1_1StepSoundHandler.html", [
      [ "TileSoundMapping", "classHappyHarvest_1_1StepSoundHandler_1_1TileSoundMapping.html", [
        [ "Tiles", "classHappyHarvest_1_1StepSoundHandler_1_1TileSoundMapping.html#a1c6acdcffdc00e44ab2ae318d4b19bcd", null ],
        [ "StepSounds", "classHappyHarvest_1_1StepSoundHandler_1_1TileSoundMapping.html#afd04c01ae65d28b98ffd75fbe2be6c18", null ]
      ] ],
      [ "Start", "classHappyHarvest_1_1StepSoundHandler.html#ad67c624ce31b051aa35c94f3910fc11e", null ],
      [ "PlayStepSound", "classHappyHarvest_1_1StepSoundHandler.html#a22a397ed50f9ec392f14b0436254d2f8", null ],
      [ "GetRandomEntry", "classHappyHarvest_1_1StepSoundHandler.html#a508e5fdb30dcfbcdfbc1de7b18ac01ee", null ],
      [ "DefaultStepSounds", "classHappyHarvest_1_1StepSoundHandler.html#a20712bf10e293ae5629bde3b505a30e0", null ],
      [ "SoundMappings", "classHappyHarvest_1_1StepSoundHandler.html#aa331e8ef9a13d92e54ca3cef7a6cda49", null ],
      [ "m_Mapping", "classHappyHarvest_1_1StepSoundHandler.html#ad66eaa3c40972690477db878ca6f40a1", null ]
    ] ],
    [ "HappyHarvest.EmitParticles", "classHappyHarvest_1_1EmitParticles.html", [
      [ "Emit", "classHappyHarvest_1_1EmitParticles.html#a07d81467647eedad7642168ea9f73acc", null ],
      [ "particles", "classHappyHarvest_1_1EmitParticles.html#ac6135a846c933e124762829fa7b5eb15", null ],
      [ "particleCount", "classHappyHarvest_1_1EmitParticles.html#a06bf220b25f19c160f14b7125c51917c", null ]
    ] ],
    [ "HappyHarvest.ToolAnimationEventHandler", "classHappyHarvest_1_1ToolAnimationEventHandler.html", [
      [ "TriggerFrontVFX", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a55fd9f603d2b06d69bfb5b6008764569", null ],
      [ "TriggerSideVFX", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a1d1dbb99dd70d7462260f10c8440cbe0", null ],
      [ "TriggerUpVFX", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a3a6ad0a42825d764a6af230ac245604f", null ],
      [ "FrontEffect", "classHappyHarvest_1_1ToolAnimationEventHandler.html#af2afd2f439135143bdc346b62ff8c9a3", null ],
      [ "FrontEffectId", "classHappyHarvest_1_1ToolAnimationEventHandler.html#afb6d579779b74c951e6d461613b7041e", null ],
      [ "UpEffect", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a371b9d614852c3cb02ec77c8810777d7", null ],
      [ "UpEffectId", "classHappyHarvest_1_1ToolAnimationEventHandler.html#aeb867a751abf18734613f3733eaefcd1", null ],
      [ "SideEffect", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a42dc09b46eb4ca8eb30a0c355b513f42", null ],
      [ "SideEffectId", "classHappyHarvest_1_1ToolAnimationEventHandler.html#a18ea5249fcad38d9e6e9964364e4cc96", null ]
    ] ],
    [ "HappyHarvest.RendererFader", "classHappyHarvest_1_1RendererFader.html", [
      [ "Start", "classHappyHarvest_1_1RendererFader.html#a7c52269163b4ebe83181c91ef39dd099", null ],
      [ "OnTriggerEnter2D", "classHappyHarvest_1_1RendererFader.html#a750fa11f3ad493c4073a3f421d4c4130", null ],
      [ "OnTriggerExit2D", "classHappyHarvest_1_1RendererFader.html#a1cf456a5b24f2061b7bd62ab9a54cf6d", null ],
      [ "AnimCurve", "classHappyHarvest_1_1RendererFader.html#a4163f7b76591b2b30d2f5aecd60b660d", null ],
      [ "curve", "classHappyHarvest_1_1RendererFader.html#a896e9a8da681e12051f04d32988b6636", null ],
      [ "time", "classHappyHarvest_1_1RendererFader.html#a5d1c01e676a83ee623a38286520bad2a", null ],
      [ "RendererToHide", "classHappyHarvest_1_1RendererFader.html#ae75f14b3b7b249e125ec3025b8cf2c08", null ],
      [ "finalAlpha", "classHappyHarvest_1_1RendererFader.html#ade69638f0cf08e0285e8c951d6c9ab8e", null ],
      [ "tilemap", "classHappyHarvest_1_1RendererFader.html#a61e506da6b452b901ec2a350ac10fa9a", null ],
      [ "_initialColor", "classHappyHarvest_1_1RendererFader.html#accec6c9369a11b89dd0b8e206b29acd2", null ],
      [ "col", "classHappyHarvest_1_1RendererFader.html#a85536e85460ea6ce396dc6d43a66f3e6", null ]
    ] ],
    [ "HappyHarvest.StartAnimation", "classHappyHarvest_1_1StartAnimation.html", [
      [ "Trigger", "classHappyHarvest_1_1StartAnimation.html#ad1ddb63e23df5d8c1e7ca42140b09797", null ],
      [ "Animation", "classHappyHarvest_1_1StartAnimation.html#a4ad58f1829755fad55aa996cb598a45a", null ]
    ] ],
    [ "HappyHarvest.BasicAnimalMovement", "classHappyHarvest_1_1BasicAnimalMovement.html", [
      [ "Start", "classHappyHarvest_1_1BasicAnimalMovement.html#abf3c8d66e7f8ab933a76b8412f40a454", null ],
      [ "Update", "classHappyHarvest_1_1BasicAnimalMovement.html#a9433441404c44bcd79be7a42e9cf5d60", null ],
      [ "PickNewIdleTime", "classHappyHarvest_1_1BasicAnimalMovement.html#ab7ca1a8f0f723e5d01183271f9065db2", null ],
      [ "PickNewTarget", "classHappyHarvest_1_1BasicAnimalMovement.html#a0161655489ed188d3f79abbb66ecc61f", null ],
      [ "Area", "classHappyHarvest_1_1BasicAnimalMovement.html#a9534e94f1a77d09e3e62c246b09573cf", null ],
      [ "MinIdleTime", "classHappyHarvest_1_1BasicAnimalMovement.html#a4358d81fb9a97e19efcd0670e8f03faa", null ],
      [ "MaxIdleTime", "classHappyHarvest_1_1BasicAnimalMovement.html#a259576b9e8379997b31bca5b3b2f8e14", null ],
      [ "Speed", "classHappyHarvest_1_1BasicAnimalMovement.html#aff5493218cef6755a395ba6953729b78", null ],
      [ "AnimalSound", "classHappyHarvest_1_1BasicAnimalMovement.html#a87724f2d67139f053c97b27a3f4f1f46", null ],
      [ "MinRandomSoundTime", "classHappyHarvest_1_1BasicAnimalMovement.html#ac85ed9672cd7af6936612c2fc1e4f9c0", null ],
      [ "MaxRandomSoundTime", "classHappyHarvest_1_1BasicAnimalMovement.html#a915b3572f0d18bc811c6325ec6977260", null ],
      [ "m_IdleTimer", "classHappyHarvest_1_1BasicAnimalMovement.html#aa35918695504ed2f55c6ed7535297875", null ],
      [ "m_CurrentIdleTarget", "classHappyHarvest_1_1BasicAnimalMovement.html#a9b8193bc2638aafb29fbdf0b7cd39b8f", null ],
      [ "m_SoundTimer", "classHappyHarvest_1_1BasicAnimalMovement.html#a576c1967222512b5d2e4833bbf22100d", null ],
      [ "m_CurrentTarget", "classHappyHarvest_1_1BasicAnimalMovement.html#a37d1bfaeed8e7f32fbcc9c1a35f8e1a5", null ],
      [ "m_IsIdle", "classHappyHarvest_1_1BasicAnimalMovement.html#a559166d41bffa84f438c8a752b6e3ca4", null ],
      [ "m_Animator", "classHappyHarvest_1_1BasicAnimalMovement.html#a362c90ef162ff1c3b034d6f5c1d0424d", null ],
      [ "SpeedHash", "classHappyHarvest_1_1BasicAnimalMovement.html#a00abf6f1a30bc9778739c8affc839c30", null ]
    ] ]
];