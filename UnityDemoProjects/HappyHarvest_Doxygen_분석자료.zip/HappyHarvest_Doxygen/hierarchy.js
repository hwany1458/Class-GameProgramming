var hierarchy =
[
    [ "AdjacentRuleTile", "classUnityEngine_1_1Tilemaps_1_1AdjacentRuleTile.html", null ],
    [ "AssetPostprocessor", null, [
      [ "SpritePostprocessor", "classSpritePostprocessor.html", null ]
    ] ],
    [ "HappyHarvest.BaseDatabase< Crop >", "classHappyHarvest_1_1BaseDatabase.html", [
      [ "HappyHarvest.CropDatabase", "classHappyHarvest_1_1CropDatabase.html", null ]
    ] ],
    [ "HappyHarvest.BaseDatabase< Item >", "classHappyHarvest_1_1BaseDatabase.html", [
      [ "HappyHarvest.ItemDatabase", "classHappyHarvest_1_1ItemDatabase.html", null ]
    ] ],
    [ "HappyHarvest.TerrainManager.CropData", "classHappyHarvest_1_1TerrainManager_1_1CropData.html", null ],
    [ "HappyHarvest.CropInitializer.CropInitData", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html", null ],
    [ "HappyHarvest.DayCycleHandlerSaveData", "structHappyHarvest_1_1DayCycleHandlerSaveData.html", null ],
    [ "HappyHarvest.DayEventHandler.DayEvent", "classHappyHarvest_1_1DayEventHandler_1_1DayEvent.html", null ],
    [ "Editor", null, [
      [ "HappyHarvest.DayCycleEditor", "classHappyHarvest_1_1DayCycleEditor.html", null ],
      [ "HappyHarvest.LightInterpolatorEditor", "classHappyHarvest_1_1LightInterpolatorEditor.html", null ],
      [ "HappyHarvest.SpawnPointEditor", "classHappyHarvest_1_1SpawnPointEditor.html", null ],
      [ "HappyHarvest.WeatherSystemEditor", "classHappyHarvest_1_1WeatherSystemEditor.html", null ]
    ] ],
    [ "HappyHarvest.TerrainManager.GroundData", "classHappyHarvest_1_1TerrainManager_1_1GroundData.html", null ],
    [ "HappyHarvest.IDatabaseEntry", "interfaceHappyHarvest_1_1IDatabaseEntry.html", [
      [ "HappyHarvest.Crop", "classHappyHarvest_1_1Crop.html", null ],
      [ "HappyHarvest.Item", "classHappyHarvest_1_1Item.html", [
        [ "HappyHarvest.Basket", "classHappyHarvest_1_1Basket.html", null ],
        [ "HappyHarvest.Hoe", "classHappyHarvest_1_1Hoe.html", null ],
        [ "HappyHarvest.Product", "classHappyHarvest_1_1Product.html", null ],
        [ "HappyHarvest.SeedBag", "classHappyHarvest_1_1SeedBag.html", null ],
        [ "HappyHarvest.WaterCan", "classHappyHarvest_1_1WaterCan.html", null ]
      ] ]
    ] ],
    [ "HappyHarvest.InventorySystem.InventoryEntry", "classHappyHarvest_1_1InventorySystem_1_1InventoryEntry.html", null ],
    [ "HappyHarvest.InventorySaveData", "classHappyHarvest_1_1InventorySaveData.html", null ],
    [ "HappyHarvest.InventorySystem", "classHappyHarvest_1_1InventorySystem.html", null ],
    [ "HappyHarvest.ItemInstance", "classHappyHarvest_1_1ItemInstance.html", null ],
    [ "HappyHarvest.LightInterpolator.LightFrame", "classHappyHarvest_1_1LightInterpolator_1_1LightFrame.html", null ],
    [ "MonoBehaviour", null, [
      [ "HappyHarvest.AmbienceBlender", "classHappyHarvest_1_1AmbienceBlender.html", null ],
      [ "HappyHarvest.BasicAnimalMovement", "classHappyHarvest_1_1BasicAnimalMovement.html", null ],
      [ "HappyHarvest.CameraSetter", "classHappyHarvest_1_1CameraSetter.html", null ],
      [ "HappyHarvest.CharacterAnimationEventHandler", "classHappyHarvest_1_1CharacterAnimationEventHandler.html", null ],
      [ "HappyHarvest.CropInitializer", "classHappyHarvest_1_1CropInitializer.html", null ],
      [ "HappyHarvest.DayCycleHandler", "classHappyHarvest_1_1DayCycleHandler.html", null ],
      [ "HappyHarvest.DayEventHandler", "classHappyHarvest_1_1DayEventHandler.html", null ],
      [ "HappyHarvest.EmitParticles", "classHappyHarvest_1_1EmitParticles.html", null ],
      [ "HappyHarvest.GameManager", "classHappyHarvest_1_1GameManager.html", null ],
      [ "HappyHarvest.InteractiveObject", "classHappyHarvest_1_1InteractiveObject.html", [
        [ "HappyHarvest.MarketStall", "classHappyHarvest_1_1MarketStall.html", null ],
        [ "HappyHarvest.Warehouse", "classHappyHarvest_1_1Warehouse.html", null ]
      ] ],
      [ "HappyHarvest.LightFlicker", "classHappyHarvest_1_1LightFlicker.html", null ],
      [ "HappyHarvest.LightInterpolator", "classHappyHarvest_1_1LightInterpolator.html", null ],
      [ "HappyHarvest.Loader", "classHappyHarvest_1_1Loader.html", null ],
      [ "HappyHarvest.MainMenuHandler", "classHappyHarvest_1_1MainMenuHandler.html", null ],
      [ "HappyHarvest.PlayerController", "classHappyHarvest_1_1PlayerController.html", null ],
      [ "HappyHarvest.RendererFader", "classHappyHarvest_1_1RendererFader.html", null ],
      [ "HappyHarvest.SceneData", "classHappyHarvest_1_1SceneData.html", null ],
      [ "HappyHarvest.SceneTransition", "classHappyHarvest_1_1SceneTransition.html", null ],
      [ "HappyHarvest.ShadowInstance", "classHappyHarvest_1_1ShadowInstance.html", null ],
      [ "HappyHarvest.SpawnPoint", "classHappyHarvest_1_1SpawnPoint.html", null ],
      [ "HappyHarvest.StartAnimation", "classHappyHarvest_1_1StartAnimation.html", null ],
      [ "HappyHarvest.StepSoundHandler", "classHappyHarvest_1_1StepSoundHandler.html", null ],
      [ "HappyHarvest.TargetMarker", "classHappyHarvest_1_1TargetMarker.html", null ],
      [ "HappyHarvest.TerrainManager", "classHappyHarvest_1_1TerrainManager.html", null ],
      [ "HappyHarvest.ToolAnimationEventHandler", "classHappyHarvest_1_1ToolAnimationEventHandler.html", null ],
      [ "HappyHarvest.TriggerEvent", "classHappyHarvest_1_1TriggerEvent.html", null ],
      [ "HappyHarvest.UIHandler", "classHappyHarvest_1_1UIHandler.html", null ],
      [ "HappyHarvest.WalkableSurface", "classHappyHarvest_1_1WalkableSurface.html", null ],
      [ "HappyHarvest.WeatherSystem", "classHappyHarvest_1_1WeatherSystem.html", null ],
      [ "HappyHarvest.WeatherSystemElement", "classHappyHarvest_1_1WeatherSystemElement.html", null ],
      [ "Template2DCommon.SoundManager", "classTemplate2DCommon_1_1SoundManager.html", null ],
      [ "UnityEngine.Tilemaps.TilePaletteHelper", "classUnityEngine_1_1Tilemaps_1_1TilePaletteHelper.html", null ]
    ] ],
    [ "RuleTile.TilingRule.Neighbor", null, [
      [ "HappyHarvest.AdjacentRuleTile.Neighbor", "classHappyHarvest_1_1AdjacentRuleTile_1_1Neighbor.html", null ]
    ] ],
    [ "HappyHarvest.PlayerSaveData", "structHappyHarvest_1_1PlayerSaveData.html", null ],
    [ "PropertyDrawer", null, [
      [ "HappyHarvest.DayEvent", "classHappyHarvest_1_1DayEvent.html", null ],
      [ "HappyHarvest.InventoryDrawer", "classHappyHarvest_1_1InventoryDrawer.html", null ],
      [ "HappyHarvest.InventoryEntryDrawer", "classHappyHarvest_1_1InventoryEntryDrawer.html", null ]
    ] ],
    [ "RuleTile", null, [
      [ "HappyHarvest.AdjacentRuleTile", "classHappyHarvest_1_1AdjacentRuleTile.html", null ]
    ] ],
    [ "HappyHarvest.SaveSystem.SaveData", "structHappyHarvest_1_1SaveSystem_1_1SaveData.html", null ],
    [ "HappyHarvest.TerrainManager.CropData.SaveData", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html", null ],
    [ "HappyHarvest.SaveSystem", "classHappyHarvest_1_1SaveSystem.html", null ],
    [ "HappyHarvest.SaveSystem.SceneData", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html", null ],
    [ "ScriptableObject", null, [
      [ "HappyHarvest.BaseDatabase< T >", "classHappyHarvest_1_1BaseDatabase.html", null ],
      [ "HappyHarvest.Crop", "classHappyHarvest_1_1Crop.html", null ],
      [ "HappyHarvest.Item", "classHappyHarvest_1_1Item.html", null ]
    ] ],
    [ "Template2DCommon.SettingMenu", "classTemplate2DCommon_1_1SettingMenu.html", null ],
    [ "Template2DCommon.SoundManager.SoundData", "classTemplate2DCommon_1_1SoundManager_1_1SoundData.html", null ],
    [ "SpritePostprocessor", "classHappyHarvest_1_1SpritePostprocessor.html", null ],
    [ "HappyHarvest.Storage", "classHappyHarvest_1_1Storage.html", null ],
    [ "HappyHarvest.TerrainDataSave", "structHappyHarvest_1_1TerrainDataSave.html", null ],
    [ "TilePaletteHelper", "classHappyHarvest_1_1TilePaletteHelper.html", null ],
    [ "HappyHarvest.StepSoundHandler.TileSoundMapping", "classHappyHarvest_1_1StepSoundHandler_1_1TileSoundMapping.html", null ],
    [ "HappyHarvest.WarehouseUI", "classHappyHarvest_1_1WarehouseUI.html", null ]
];