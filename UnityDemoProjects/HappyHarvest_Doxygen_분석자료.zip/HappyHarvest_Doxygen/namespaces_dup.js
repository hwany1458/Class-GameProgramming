var namespaces_dup =
[
    [ "HappyHarvest", "namespaceHappyHarvest.html", "namespaceHappyHarvest" ],
    [ "Template2DCommon", "namespaceTemplate2DCommon.html", "namespaceTemplate2DCommon" ],
    [ "UnityEngine", "namespaceUnityEngine.html", "namespaceUnityEngine" ]
];