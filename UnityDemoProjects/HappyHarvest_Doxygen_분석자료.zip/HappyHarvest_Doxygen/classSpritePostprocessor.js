var classSpritePostprocessor =
[
    [ "OnPostprocessPrefab", "classSpritePostprocessor.html#a62b9bc475097e94d1b998371049e6c34", null ],
    [ "SpritesDefaultMaterialName", "classSpritePostprocessor.html#add2c76aab4d29ccc6fbcc28fcda64e97", null ],
    [ "CustomMaterialPath", "classSpritePostprocessor.html#ae3af550a419ae90107cd842f6137bd32", null ]
];