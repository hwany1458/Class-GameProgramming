/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Happy Harvest 소스 분석", "index.html", [
    [ "한눈에 보는 구조", "index.html#sec_overview", null ],
    [ "핵심 루프 1회: 클릭이 타일을 바꾸기까지", "index.html#sec_loop", null ],
    [ "데이터와 로직의 분리", "index.html#sec_data", null ],
    [ "현황 판정 요약 (강의용)", "index.html#sec_status", null ],
    [ "확장 포인트 (2단계 입력)", "index.html#sec_extension", null ],
    [ "모듈 안내", "index.html#sec_modules", null ],
    [ "새 작물 만들기", "manual_crops.html", [
      [ "Creating new Crops", "manual_crops.html#autotoc_md0", [
        [ "Creating the Product", "manual_crops.html#autotoc_md1", null ],
        [ "Creating the Crop", "manual_crops.html#autotoc_md2", null ],
        [ "Creating the Seed bag", "manual_crops.html#autotoc_md3", null ]
      ] ]
    ] ],
    [ "새 아이템 만들기", "manual_items.html", [
      [ "Writing new Items", "manual_items.html#autotoc_md4", null ]
    ] ],
    [ "Topics", "topics.html", "topics" ],
    [ "패키지", "namespaces.html", [
      [ "Package List", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "클래스", "annotated.html", [
      [ "클래스 목록", "annotated.html", "annotated_dup" ],
      [ "클래스 색인", "classes.html", null ],
      [ "클래스 계통도", "hierarchy.html", "hierarchy" ],
      [ "클래스 멤버", "functions.html", [
        [ "모두", "functions.html", "functions_dup" ],
        [ "함수", "functions_func.html", "functions_func" ],
        [ "변수", "functions_vars.html", "functions_vars" ],
        [ "열거형 타입", "functions_enum.html", null ],
        [ "속성", "functions_prop.html", null ]
      ] ]
    ] ],
    [ "파일들", "files.html", [
      [ "파일 목록", "files.html", "files_dup" ],
      [ "파일 멤버", "globals.html", [
        [ "모두", "globals.html", null ],
        [ "타입정의", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AdjacentRuleTile_8cs.html",
"classHappyHarvest_1_1GameManager.html#a88f056e8ab1aaf1711367bf62eb071f9",
"classHappyHarvest_1_1TerrainManager.html#a3c796446bce5a26f53b27d3ce1f8ffe7",
"functions_vars_f.html"
];

var SYNCONMSG = '패널 동기화를 비활성화하기 위해 클릭하십시오';
var SYNCOFFMSG = '패널 동기화를 활성화하기 위해 클릭하십시오';