var structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData =
[
    [ "CropId", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a46408eddff0425b8b158955b90b2bdbd", null ],
    [ "Stage", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a0ffbf3164948ac30807ecf18386bc946", null ],
    [ "GrowthRatio", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#ae167030d0b572cfab22b8fee7976bd63", null ],
    [ "GrowthTimer", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a504797a1a55b5e397d508d4a971cdcdc", null ],
    [ "HarvestCount", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a14aa5be53c31e5bab82d305132f6005f", null ],
    [ "DyingTimer", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#af305131f937a4b1e39d1aacabef59725", null ]
];