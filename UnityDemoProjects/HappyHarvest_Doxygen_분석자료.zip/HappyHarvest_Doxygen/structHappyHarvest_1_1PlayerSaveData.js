var structHappyHarvest_1_1PlayerSaveData =
[
    [ "Position", "structHappyHarvest_1_1PlayerSaveData.html#aa1208c512f63563ae6ecc32a9ca060c5", null ],
    [ "Coins", "structHappyHarvest_1_1PlayerSaveData.html#a8491ca4d43218f76ec9ee9f2ef8234d9", null ],
    [ "Inventory", "structHappyHarvest_1_1PlayerSaveData.html#af038521c26071f70f6fba70e808fa866", null ]
];