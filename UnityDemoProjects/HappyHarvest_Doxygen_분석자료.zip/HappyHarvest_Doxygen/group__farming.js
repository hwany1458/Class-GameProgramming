var group__farming =
[
    [ "HappyHarvest.TerrainManager", "classHappyHarvest_1_1TerrainManager.html", [
      [ "IsTillable", "classHappyHarvest_1_1TerrainManager.html#aba9905165e23d0833d88dceece4872e8", null ],
      [ "IsPlantable", "classHappyHarvest_1_1TerrainManager.html#a4a2cadc2fcbf2fdfcdc5ea9781a813c6", null ],
      [ "IsTilled", "classHappyHarvest_1_1TerrainManager.html#ac653cacfd4bcaee36151055c1ef9762e", null ],
      [ "TillAt", "classHappyHarvest_1_1TerrainManager.html#aee213475ac6ad757df0b2364158eb846", null ],
      [ "PlantAt", "classHappyHarvest_1_1TerrainManager.html#a3c796446bce5a26f53b27d3ce1f8ffe7", null ],
      [ "InitHarvestEffect", "classHappyHarvest_1_1TerrainManager.html#ad46372b8b94aa188d75ad185650b4d73", null ],
      [ "WaterAt", "classHappyHarvest_1_1TerrainManager.html#a0e62b91157635ab83cdba592060ead6c", null ],
      [ "HarvestAt", "classHappyHarvest_1_1TerrainManager.html#a3b4c12ce960236ef28b24889ec2a1016", null ],
      [ "GetCropDataAt", "classHappyHarvest_1_1TerrainManager.html#a2af414f4f4ad052b3765d2c7f4021d12", null ],
      [ "OverrideGrowthStage", "classHappyHarvest_1_1TerrainManager.html#a0a2704a4e9282950b0a4d9aaa4595edc", null ],
      [ "Awake", "classHappyHarvest_1_1TerrainManager.html#aee832fe40fbad2fd8091d1690b62442b", null ],
      [ "Update", "classHappyHarvest_1_1TerrainManager.html#a27d30f6ff464d1c7c99499dd24bab05e", null ],
      [ "UpdateCropVisual", "classHappyHarvest_1_1TerrainManager.html#a6e4cd486d32f61eee0e2fff535fb305a", null ],
      [ "Save", "classHappyHarvest_1_1TerrainManager.html#a551c5f4fa766c0d3ce6a0d0dd8128904", null ],
      [ "Load", "classHappyHarvest_1_1TerrainManager.html#ae6e48f5e7f104efb434167d4fc88bcf3", null ],
      [ "Grid", "classHappyHarvest_1_1TerrainManager.html#a6e48a1eabb0c2fd3a5513215c98572fe", null ],
      [ "GroundTilemap", "classHappyHarvest_1_1TerrainManager.html#a308c4e2508035599a5e7f2576664fafa", null ],
      [ "CropTilemap", "classHappyHarvest_1_1TerrainManager.html#af57db324173fd9d9111edf1450893444", null ],
      [ "WaterTilemap", "classHappyHarvest_1_1TerrainManager.html#a40d9cfaf1161117bcfe2c76332647d6e", null ],
      [ "WateredTile", "classHappyHarvest_1_1TerrainManager.html#affdd41f30d54a0437b6dbedbb13bc5c4", null ],
      [ "TilleableTile", "classHappyHarvest_1_1TerrainManager.html#a25fb10bcb512b834a47be955977e1d37", null ],
      [ "TilledTile", "classHappyHarvest_1_1TerrainManager.html#a8e80a80f6493c3e70fa25a40646cb9eb", null ],
      [ "TillingEffectPrefab", "classHappyHarvest_1_1TerrainManager.html#ab33e9c8e0fc65be921203b13f245a1ea", null ],
      [ "m_GroundData", "classHappyHarvest_1_1TerrainManager.html#aeae55e97548eb9860c5bad9b74538a6d", null ],
      [ "m_CropData", "classHappyHarvest_1_1TerrainManager.html#a843c648385970e052559c30e6c9e57f3", null ],
      [ "m_HarvestEffectPool", "classHappyHarvest_1_1TerrainManager.html#adef88847a669df4b7d15a816a5c87f6c", null ],
      [ "m_TillingEffectPool", "classHappyHarvest_1_1TerrainManager.html#a3e3e35bb31ea9813a83dfb8c71fc8c3d", null ]
    ] ],
    [ "HappyHarvest.TerrainManager.GroundData", "classHappyHarvest_1_1TerrainManager_1_1GroundData.html", [
      [ "WaterDuration", "classHappyHarvest_1_1TerrainManager_1_1GroundData.html#ac6d5d3a6a1aa61a3a20b97883656980f", null ],
      [ "WaterTimer", "classHappyHarvest_1_1TerrainManager_1_1GroundData.html#a8b671d164d844c218f6d5b7d79cdb6e3", null ]
    ] ],
    [ "HappyHarvest.TerrainManager.CropData", "classHappyHarvest_1_1TerrainManager_1_1CropData.html", [
      [ "SaveData", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html", [
        [ "CropId", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a46408eddff0425b8b158955b90b2bdbd", null ],
        [ "Stage", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a0ffbf3164948ac30807ecf18386bc946", null ],
        [ "GrowthRatio", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#ae167030d0b572cfab22b8fee7976bd63", null ],
        [ "GrowthTimer", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a504797a1a55b5e397d508d4a971cdcdc", null ],
        [ "HarvestCount", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#a14aa5be53c31e5bab82d305132f6005f", null ],
        [ "DyingTimer", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html#af305131f937a4b1e39d1aacabef59725", null ]
      ] ],
      [ "Init", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a2f66ccbab3071671c9a5a6f1a25154ea", null ],
      [ "Harvest", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a4de30fe5baa2e69dc465486ecce5c803", null ],
      [ "Save", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a1265d0effa660cc2e377f2d1c603d862", null ],
      [ "Load", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a1e85dbe5861038de3770c22f69b2c56a", null ],
      [ "GrowingCrop", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a294d810d052fdd60fce3ab59c1dc318d", null ],
      [ "CurrentGrowthStage", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a39a333123131dacc94b27b0b0157a31d", null ],
      [ "GrowthRatio", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#af4497331795cb1e27bf5941f5ca3dc7b", null ],
      [ "GrowthTimer", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a0c5ba29e9703a949849d4a38e88f40b6", null ],
      [ "HarvestCount", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a29732f3c981e904e5e668606904198e8", null ],
      [ "DyingTimer", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a78296b38f4afaa4b19a4fd6b7cd3c613", null ],
      [ "HarvestDone", "classHappyHarvest_1_1TerrainManager_1_1CropData.html#a1a842adefa65652aeceb51d31a940d35", null ]
    ] ],
    [ "HappyHarvest.Crop", "classHappyHarvest_1_1Crop.html", [
      [ "GetGrowthStage", "classHappyHarvest_1_1Crop.html#a5fafc4c8ea0ca54a1af629223355be5f", null ],
      [ "UniqueID", "classHappyHarvest_1_1Crop.html#ad73e619ece528e29397317b506382daa", null ],
      [ "GrowthStagesTiles", "classHappyHarvest_1_1Crop.html#af0913ee257805ea96814f3711a137121", null ],
      [ "Produce", "classHappyHarvest_1_1Crop.html#acd1c0b09dfabf43e2a8f66a96d64cf4c", null ],
      [ "GrowthTime", "classHappyHarvest_1_1Crop.html#a980edb57c65986a055a406572ed11165", null ],
      [ "NumberOfHarvest", "classHappyHarvest_1_1Crop.html#aff34bcf402d1f623268b6d5ac022ef94", null ],
      [ "StageAfterHarvest", "classHappyHarvest_1_1Crop.html#ab6f544ee281a9f939e865a38cb23eb27", null ],
      [ "ProductPerHarvest", "classHappyHarvest_1_1Crop.html#ace769ac602bc6522269eb0b5850f9977", null ],
      [ "DryDeathTimer", "classHappyHarvest_1_1Crop.html#a83bc16591c078b3c49c354b456a5e63a", null ],
      [ "HarvestEffect", "classHappyHarvest_1_1Crop.html#a4a86e94d73d442dffe8ed4066eed8e99", null ],
      [ "Key", "classHappyHarvest_1_1Crop.html#a9a1f8b2a7e59ef73fc3b24aea690aa10", null ]
    ] ],
    [ "HappyHarvest.CropInitializer", "classHappyHarvest_1_1CropInitializer.html", [
      [ "CropInitData", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html", [
        [ "Cell", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a995a9dfae6e496f6c5b4aa248c440b01", null ],
        [ "CropToPlant", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a714f1f60c12742683533b8d3e6415647", null ],
        [ "StartingStage", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a9eb818ae9015172cf4c830155832a177", null ]
      ] ],
      [ "Start", "classHappyHarvest_1_1CropInitializer.html#a76bb8a78e66a0d65fff4618c38ae87e4", null ],
      [ "InitList", "classHappyHarvest_1_1CropInitializer.html#a8c10ced26df9548a13dc44db979fe873", null ]
    ] ],
    [ "TilePaletteHelper", "classHappyHarvest_1_1TilePaletteHelper.html", null ],
    [ "AdjacentRuleTile", "classUnityEngine_1_1Tilemaps_1_1AdjacentRuleTile.html", null ]
];