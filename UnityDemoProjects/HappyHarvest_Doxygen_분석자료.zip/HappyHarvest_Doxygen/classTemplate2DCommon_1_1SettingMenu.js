var classTemplate2DCommon_1_1SettingMenu =
[
    [ "SettingMenu", "classTemplate2DCommon_1_1SettingMenu.html#a49872a1ca81cd9f0f56009337c05d96b", null ],
    [ "CompareResolution", "classTemplate2DCommon_1_1SettingMenu.html#afe58a703561ea51daa9d8e5f6a0f3a0d", null ],
    [ "Open", "classTemplate2DCommon_1_1SettingMenu.html#a31e88977626461e29e82cae877d5bfcb", null ],
    [ "Close", "classTemplate2DCommon_1_1SettingMenu.html#af2748123123a5924f9d9cc0b7721aa2b", null ],
    [ "OnClose", "classTemplate2DCommon_1_1SettingMenu.html#ad4df8a68a49ec24b5d6905aee6974050", null ],
    [ "OnOpen", "classTemplate2DCommon_1_1SettingMenu.html#a3346e630e14af4cca21a61df193a5e3d", null ],
    [ "m_Root", "classTemplate2DCommon_1_1SettingMenu.html#a9c63729ebd110d4dacb05fc7de0e7fed", null ],
    [ "m_OpenMenu", "classTemplate2DCommon_1_1SettingMenu.html#abdce4cc1e579b84de98566d1e7ff8461", null ],
    [ "m_CloseButton", "classTemplate2DCommon_1_1SettingMenu.html#a76cbc2cc099f2d8336419ffab2be0863", null ],
    [ "m_QuitButton", "classTemplate2DCommon_1_1SettingMenu.html#adf55af5799529db0679c59c13fac2006", null ],
    [ "m_ResolutionDropdown", "classTemplate2DCommon_1_1SettingMenu.html#ab5510c436d0cccdd26596a58b6152357", null ],
    [ "m_FullscreenToggle", "classTemplate2DCommon_1_1SettingMenu.html#a90952673de317a4e3b6773f9f2d46b12", null ],
    [ "m_MainVolumeSlider", "classTemplate2DCommon_1_1SettingMenu.html#aeea39f014525abafa02ce9b58e5bdbff", null ],
    [ "m_BGMVolumeSlider", "classTemplate2DCommon_1_1SettingMenu.html#a402240f86022488af8aaf0e815b88fbd", null ],
    [ "m_SFXVolumeSlider", "classTemplate2DCommon_1_1SettingMenu.html#a8792c66e36961fc0f80bf5c6d57ff3eb", null ],
    [ "m_AvailableResolutions", "classTemplate2DCommon_1_1SettingMenu.html#a63bd233b2bd5929a6f5e63412a6405f1", null ]
];