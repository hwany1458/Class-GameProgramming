var dir_6a8c219acdf7c434f558c7df0a96cc10 =
[
    [ "BaseDatabase.cs", "BaseDatabase_8cs.html", null ],
    [ "CropDatabase.cs", "CropDatabase_8cs.html", null ],
    [ "ItemDatabase.cs", "ItemDatabase_8cs.html", null ]
];