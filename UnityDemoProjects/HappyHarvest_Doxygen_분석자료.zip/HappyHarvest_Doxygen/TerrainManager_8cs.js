var TerrainManager_8cs =
[
    [ "HappyHarvest.TerrainManager.CropData.SaveData", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData.html", "structHappyHarvest_1_1TerrainManager_1_1CropData_1_1SaveData" ]
];