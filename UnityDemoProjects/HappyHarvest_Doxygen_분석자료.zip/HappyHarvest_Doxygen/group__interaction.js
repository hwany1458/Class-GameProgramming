var group__interaction =
[
    [ "HappyHarvest.InteractiveObject", "classHappyHarvest_1_1InteractiveObject.html", [
      [ "InteractedWith", "classHappyHarvest_1_1InteractiveObject.html#a77568435c655cfe8d4137d67057e6cff", null ],
      [ "Awake", "classHappyHarvest_1_1InteractiveObject.html#afaa86de6fb13c6c1edecc1880d6c2e51", null ]
    ] ],
    [ "HappyHarvest.MarketStall", "classHappyHarvest_1_1MarketStall.html", [
      [ "InteractedWith", "classHappyHarvest_1_1MarketStall.html#ace52a011fb78b9a3ce203bdab341b969", null ]
    ] ],
    [ "HappyHarvest.Warehouse", "classHappyHarvest_1_1Warehouse.html", [
      [ "InteractedWith", "classHappyHarvest_1_1Warehouse.html#a399e142fc8f14e68d66e7795c053a723", null ]
    ] ],
    [ "HappyHarvest.TriggerEvent", "classHappyHarvest_1_1TriggerEvent.html", [
      [ "OnTriggerEnter2D", "classHappyHarvest_1_1TriggerEvent.html#a7f5ae0299beacea47642a409fa0a5416", null ],
      [ "OnTriggerExit2D", "classHappyHarvest_1_1TriggerEvent.html#a7bad5c2aa52832701362405c74a94270", null ],
      [ "OnEnter", "classHappyHarvest_1_1TriggerEvent.html#affe443f129500df1bbe4f909aaa37da2", null ],
      [ "OnExit", "classHappyHarvest_1_1TriggerEvent.html#a3922759a6a20703175e23d4b0f033e13", null ]
    ] ],
    [ "HappyHarvest.WalkableSurface", "classHappyHarvest_1_1WalkableSurface.html", [
      [ "Awake", "classHappyHarvest_1_1WalkableSurface.html#acdf582dcb8581c862ae2fa16db1ee5d6", null ]
    ] ]
];