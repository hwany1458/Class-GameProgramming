var classHappyHarvest_1_1SceneTransition =
[
    [ "OnTriggerEnter2D", "classHappyHarvest_1_1SceneTransition.html#a85802f757412da3d430103c772b7efef", null ],
    [ "TargetSceneBuildIndex", "classHappyHarvest_1_1SceneTransition.html#af7d0ac919335c72aed0c182b67cf3458", null ],
    [ "TargetSpawnIndex", "classHappyHarvest_1_1SceneTransition.html#ab1fd28503cbc5777cacddd39b8dfc5fa", null ]
];