var topics =
[
    [ "1. 코어 — 진입점·씬 전환·전역 참조", "group__core.html", "group__core" ],
    [ "2. 플레이어 — 입력·이동·타깃·소지금", "group__player.html", "group__player" ],
    [ "3. 경작 — 타일맵이 곧 게임 상태", "group__farming.html", "group__farming" ],
    [ "4. 아이템·인벤토리·보관", "group__items.html", "group__items" ],
    [ "5. 데이터베이스 — ID로 에셋 찾기", "group__data.html", "group__data" ],
    [ "6. 상호작용 오브젝트 — 상점·창고·트리거", "group__interaction.html", "group__interaction" ],
    [ "7. 시간·날씨·조명", "group__timeweather.html", "group__timeweather" ],
    [ "8. 저장/불러오기", "group__save.html", "group__save" ],
    [ "9. UI — HUD·상점·창고·페이드", "group__ui.html", "group__ui" ],
    [ "10. 오디오·연출 보조", "group__audiofx.html", "group__audiofx" ],
    [ "11. 에디터 전용", "group__editor.html", "group__editor" ]
];