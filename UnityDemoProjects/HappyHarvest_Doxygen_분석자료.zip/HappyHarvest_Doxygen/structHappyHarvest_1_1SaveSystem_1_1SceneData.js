var structHappyHarvest_1_1SaveSystem_1_1SceneData =
[
    [ "SceneName", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html#ad0f6e19f1a66d25f4a76650648f6e640", null ],
    [ "TerrainData", "structHappyHarvest_1_1SaveSystem_1_1SceneData.html#affde79aac61935c04c3b9e40d72985c5", null ]
];