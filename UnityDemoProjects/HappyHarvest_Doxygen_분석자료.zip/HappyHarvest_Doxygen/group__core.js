var group__core =
[
    [ "HappyHarvest.GameManager", "classHappyHarvest_1_1GameManager.html", [
      [ "Awake", "classHappyHarvest_1_1GameManager.html#a01c9f4cf4e628431af1cf2e39e01acc9", null ],
      [ "Start", "classHappyHarvest_1_1GameManager.html#a64d756db97ec7f4fa78d2ce1596f8ae9", null ],
      [ "OnDestroy", "classHappyHarvest_1_1GameManager.html#af694d8cf61e1fec6e36d2ffb3830c504", null ],
      [ "Update", "classHappyHarvest_1_1GameManager.html#ac2adc103178685a99c805a06723cbd41", null ],
      [ "Pause", "classHappyHarvest_1_1GameManager.html#a043be6bb8e1ea0ee22446e5e237bd100", null ],
      [ "Resume", "classHappyHarvest_1_1GameManager.html#aaa4dd2f1868fb91c093d70b70761b414", null ],
      [ "RegisterSpawn", "classHappyHarvest_1_1GameManager.html#acc740f2cb8119f5ac9ad769a431b2715", null ],
      [ "UnregisterSpawn", "classHappyHarvest_1_1GameManager.html#a6b47fbe0c2f170a3a290a427635138c9", null ],
      [ "MoveTo", "classHappyHarvest_1_1GameManager.html#a1db18b7a4982cfefabec1a9049281e76", null ],
      [ "CurrentTimeAsString", "classHappyHarvest_1_1GameManager.html#a81ec6b6a53bebea65f10b231b6dcf7c3", null ],
      [ "GetTimeAsString", "classHappyHarvest_1_1GameManager.html#ad91132af2e7b9d905fbc3e74aa0e203c", null ],
      [ "GetHourFromRatio", "classHappyHarvest_1_1GameManager.html#a88f056e8ab1aaf1711367bf62eb071f9", null ],
      [ "GetMinuteFromRatio", "classHappyHarvest_1_1GameManager.html#a7e1f126ad3a3a5326f780439129de4d2", null ],
      [ "RegisterEventHandler", "classHappyHarvest_1_1GameManager.html#a2642db13e4af19f26000329205536e6f", null ],
      [ "RemoveEventHandler", "classHappyHarvest_1_1GameManager.html#aacfd24025255dfb850a48b1700bbfbad", null ],
      [ "s_Instance", "classHappyHarvest_1_1GameManager.html#af86fd345862aff80e6f1f142cf921b9b", null ],
      [ "s_IsQuitting", "classHappyHarvest_1_1GameManager.html#a6de25f38e9de972c930340d0c5da1a29", null ],
      [ "MarketEntries", "classHappyHarvest_1_1GameManager.html#a0f3526d05749e907d8b76dcbadad2866", null ],
      [ "DayDurationInSeconds", "classHappyHarvest_1_1GameManager.html#a483fec62939a8a882a60fb28cd7ca565", null ],
      [ "StartingTime", "classHappyHarvest_1_1GameManager.html#abbe59123d56e1934e5a8e2c909aaab2c", null ],
      [ "ItemDatabase", "classHappyHarvest_1_1GameManager.html#a63aba97d36a025c7648f1b9f59f7e906", null ],
      [ "CropDatabase", "classHappyHarvest_1_1GameManager.html#aebc611526d51390bafad15325b51ff1d", null ],
      [ "Storage", "classHappyHarvest_1_1GameManager.html#ade31fa845647305200c57fe8bde3ef97", null ],
      [ "m_IsTicking", "classHappyHarvest_1_1GameManager.html#a2976e7de047954357142084ee2c2ffc7", null ],
      [ "m_EventHandlers", "classHappyHarvest_1_1GameManager.html#a27c7af952edd8e9bafbb56bda73917fb", null ],
      [ "m_ActiveTransitions", "classHappyHarvest_1_1GameManager.html#aecd1e544f41fca8722e6083575c2df7d", null ],
      [ "m_CurrentTimeOfTheDay", "classHappyHarvest_1_1GameManager.html#a21b04042c4613a7741c3c530bb4ca4f6", null ],
      [ "Instance", "classHappyHarvest_1_1GameManager.html#aff7a38a3624509078562c03dd6c5fd0f", null ],
      [ "Terrain", "classHappyHarvest_1_1GameManager.html#a2405b59c188de7173d61eb2b5b5c49a5", null ],
      [ "Player", "classHappyHarvest_1_1GameManager.html#ad6642d7e4bf86a33f589cab6e9088c39", null ],
      [ "DayCycleHandler", "classHappyHarvest_1_1GameManager.html#a53fdf6934c24e3ac9bc241dc9283703f", null ],
      [ "WeatherSystem", "classHappyHarvest_1_1GameManager.html#a5a20c681c7d4b862b2b8acc0291a5404", null ],
      [ "MainCamera", "classHappyHarvest_1_1GameManager.html#a82fe78976d2e173ae0e643b42e7f7f6f", null ],
      [ "WalkSurfaceTilemap", "classHappyHarvest_1_1GameManager.html#ac269bee508f473a09c00cc76dbdd3e73", null ],
      [ "LoadedSceneData", "classHappyHarvest_1_1GameManager.html#a9a0bdfb25613b7b439a77719ec7a4409", null ],
      [ "CurrentDayRatio", "classHappyHarvest_1_1GameManager.html#a381d9bfec714b4d3c780376f75eb8459", null ]
    ] ],
    [ "HappyHarvest.Loader", "classHappyHarvest_1_1Loader.html", [
      [ "Start", "classHappyHarvest_1_1Loader.html#a0f37f2eb3a542f74629cc8bed42d78a1", null ],
      [ "TargetScene", "classHappyHarvest_1_1Loader.html#ae7b4adde047d33db9fb8b0565e314b35", null ]
    ] ],
    [ "HappyHarvest.SceneData", "classHappyHarvest_1_1SceneData.html", [
      [ "OnEnable", "classHappyHarvest_1_1SceneData.html#a8c7b137dc31fc48e3f476b85a47ac428", null ],
      [ "OnDisable", "classHappyHarvest_1_1SceneData.html#a04941a6c2210a9b9f05f70af017eeb65", null ],
      [ "UniqueSceneName", "classHappyHarvest_1_1SceneData.html#a447dede29c40765ef80dde7f4cbf43f4", null ]
    ] ],
    [ "HappyHarvest.SceneTransition", "classHappyHarvest_1_1SceneTransition.html", [
      [ "OnTriggerEnter2D", "classHappyHarvest_1_1SceneTransition.html#a85802f757412da3d430103c772b7efef", null ],
      [ "TargetSceneBuildIndex", "classHappyHarvest_1_1SceneTransition.html#af7d0ac919335c72aed0c182b67cf3458", null ],
      [ "TargetSpawnIndex", "classHappyHarvest_1_1SceneTransition.html#ab1fd28503cbc5777cacddd39b8dfc5fa", null ]
    ] ],
    [ "HappyHarvest.SpawnPoint", "classHappyHarvest_1_1SpawnPoint.html", [
      [ "OnEnable", "classHappyHarvest_1_1SpawnPoint.html#ac0e8baf03a2a8aae0ef65e21fd7a92bc", null ],
      [ "OnDisable", "classHappyHarvest_1_1SpawnPoint.html#a343e53e3007a1fe7bcf9aa28b58ea3a8", null ],
      [ "SpawnHere", "classHappyHarvest_1_1SpawnPoint.html#ac73b865374502af018e1cd7e28db7cab", null ],
      [ "SpawnIndex", "classHappyHarvest_1_1SpawnPoint.html#a0bc5f6cd9b552cd1fd017125fe653428", null ]
    ] ],
    [ "HappyHarvest.CameraSetter", "classHappyHarvest_1_1CameraSetter.html", [
      [ "Awake", "classHappyHarvest_1_1CameraSetter.html#a2d78c68fca79b35f893af9a75c5f97f5", null ]
    ] ]
];