var searchData=
[
  ['needtarget_0',['needtarget',['../classHappyHarvest_1_1Item.html#ac7d01ae2f4b347a00a523ed5eddaa8b6',1,'HappyHarvest.Item.NeedTarget()'],['../classHappyHarvest_1_1Product.html#a456718829da2ee3d063f908b57cd8e2a',1,'HappyHarvest.Product.NeedTarget()']]]
];
