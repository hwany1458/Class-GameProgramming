var CropInitializer_8cs =
[
    [ "HappyHarvest.CropInitializer.CropInitData", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html", "structHappyHarvest_1_1CropInitializer_1_1CropInitData" ]
];