var structHappyHarvest_1_1CropInitializer_1_1CropInitData =
[
    [ "Cell", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a995a9dfae6e496f6c5b4aa248c440b01", null ],
    [ "CropToPlant", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a714f1f60c12742683533b8d3e6415647", null ],
    [ "StartingStage", "structHappyHarvest_1_1CropInitializer_1_1CropInitData.html#a9eb818ae9015172cf4c830155832a177", null ]
];