var structCore_1_1Input_1_1WheelInfo =
[
    [ "zoomAmount", "structCore_1_1Input_1_1WheelInfo.html#af30728cec6e2fbc4fee713641e1d82a3", null ]
];