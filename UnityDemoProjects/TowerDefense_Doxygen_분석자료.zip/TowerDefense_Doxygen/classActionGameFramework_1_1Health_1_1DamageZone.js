var classActionGameFramework_1_1Health_1_1DamageZone =
[
    [ "ScaleDamage", "classActionGameFramework_1_1Health_1_1DamageZone.html#a310c3c10e887c2a9a136dfa7ae2e2e95", null ],
    [ "LazyLoad", "classActionGameFramework_1_1Health_1_1DamageZone.html#a4b295cc5f53df62e418ea6f5680d49bf", null ],
    [ "damageableBehaviour", "classActionGameFramework_1_1Health_1_1DamageZone.html#a49f0f0174d005f5cb09d2366bdb3310d", null ],
    [ "damageScale", "classActionGameFramework_1_1Health_1_1DamageZone.html#a4ce3dc1303535073752b9452f40622f9", null ]
];