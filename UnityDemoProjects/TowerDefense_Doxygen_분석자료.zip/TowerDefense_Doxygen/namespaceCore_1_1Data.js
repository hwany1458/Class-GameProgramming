var namespaceCore_1_1Data =
[
    [ "EncryptedJsonSaver", "classCore_1_1Data_1_1EncryptedJsonSaver.html", "classCore_1_1Data_1_1EncryptedJsonSaver" ],
    [ "FileSaver", "classCore_1_1Data_1_1FileSaver.html", "classCore_1_1Data_1_1FileSaver" ],
    [ "GameDataStoreBase", "classCore_1_1Data_1_1GameDataStoreBase.html", "classCore_1_1Data_1_1GameDataStoreBase" ],
    [ "GameManagerBase", "classCore_1_1Data_1_1GameManagerBase.html", "classCore_1_1Data_1_1GameManagerBase" ],
    [ "IDataSaver", "interfaceCore_1_1Data_1_1IDataSaver.html", "interfaceCore_1_1Data_1_1IDataSaver" ],
    [ "IDataStore", "interfaceCore_1_1Data_1_1IDataStore.html", "interfaceCore_1_1Data_1_1IDataStore" ],
    [ "JsonSaver", "classCore_1_1Data_1_1JsonSaver.html", "classCore_1_1Data_1_1JsonSaver" ]
];