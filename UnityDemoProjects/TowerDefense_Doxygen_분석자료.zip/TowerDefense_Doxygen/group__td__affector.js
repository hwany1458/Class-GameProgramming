var group__td__affector =
[
    [ "TowerDefense.Affectors.Affector", "classTowerDefense_1_1Affectors_1_1Affector.html", [
      [ "Initialize", "classTowerDefense_1_1Affectors_1_1Affector.html#ae6009b3185ec237b1dc5b7c40afb7b07", null ],
      [ "Initialize", "classTowerDefense_1_1Affectors_1_1Affector.html#a524a390ff8a7a52deb0b197e9c0a1c62", null ],
      [ "description", "classTowerDefense_1_1Affectors_1_1Affector.html#af173f62fb21829f28ec0a5df4b61ff51", null ],
      [ "alignment", "classTowerDefense_1_1Affectors_1_1Affector.html#a4bc559ac8836ad457c3de328421b657c", null ],
      [ "enemyMask", "classTowerDefense_1_1Affectors_1_1Affector.html#a9de281ea1956d730bd8daa2995afee91", null ]
    ] ],
    [ "TowerDefense.Affectors.AttackAffector", "classTowerDefense_1_1Affectors_1_1AttackAffector.html", [
      [ "Initialize", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a95f17dfe332038c9837a5dce70fe7f92", null ],
      [ "Initialize", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a5c259632d6bf7f9f0e95f2244ddf3eb7", null ],
      [ "OnDestroy", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a8bcc0234f199eaa8e4c9e39bcfbf40d5", null ],
      [ "OnLostTarget", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a515ba523e9947c90736e539b9b4bac34", null ],
      [ "OnAcquiredTarget", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a59bffdc004a22b8bc32271775c5b1387", null ],
      [ "GetProjectileDamage", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a4ce2fec6c4f7b24a1ae02311e99989d0", null ],
      [ "SetUpTimers", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#ab07e93c3f4138a2be8fd62dff7763443", null ],
      [ "Update", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#af74c967d7c76c5206a211079826aa500", null ],
      [ "OnFireTimer", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a09a0da034d97b944e797d89db3c5ffc0", null ],
      [ "FireProjectile", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a990df28bfd3d204d4a9e1b914c3b03d7", null ],
      [ "ByDistance", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a41d1c057132585658df6435c10ae3aac", null ],
      [ "OnDrawGizmosSelected", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a191a903fd47123da2e968231d2d9e372", null ],
      [ "projectile", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#aea416aac650221f0a84469de0ee51174", null ],
      [ "projectilePoints", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#ac2e4ce4a4a470be64f87c3cd2091b970", null ],
      [ "epicenter", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a0836d319b70cf1827f4a52d5c2ac81ea", null ],
      [ "isMultiAttack", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#afad43f913f037112381305cc0d03f9a6", null ],
      [ "fireRate", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#aebd4cfbbd82185aa058f023fdaa3afe1", null ],
      [ "randomAudioSource", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a35333ea944a4ae96a2120d3cb7f1f5fb", null ],
      [ "towerTargetter", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a84bc02cc2ff7c7bbe9693379bf4156ce", null ],
      [ "radiusEffectColor", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a409b741a04a781cf11ae3dcdfa0975cc", null ],
      [ "searchCondition", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#aeb464e4332af4a8f6aa83753c0a437cf", null ],
      [ "fireCondition", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#add7d7bfa748709abfc6f9dfe751c6b0b", null ],
      [ "m_Launcher", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a714e7ceaccbfc65fada8d66aa9d0a228", null ],
      [ "m_FireTimer", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#afc2f5cf5c68bbd2822ec94a3109ac4d7", null ],
      [ "m_TrackingEnemy", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a753f6059e56afa48ede5dce3f51bbf4a", null ],
      [ "searchRate", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a21f827da9836123ebacb3c86949ed763", null ],
      [ "trackingEnemy", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#ae99fc49d9da3fc4bd2e1a208e42af4ec", null ],
      [ "effectRadius", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#ae9cb18464093e517fbcc1fb16b5f2127", null ],
      [ "effectColor", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a7920f5a765c92f812b31e08e933ff71e", null ],
      [ "targetter", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#a473fa4288b53d056f3537246f812bac9", null ],
      [ "damagerProjectile", "classTowerDefense_1_1Affectors_1_1AttackAffector.html#ae915d3e6130049d927d2389835def32f", null ]
    ] ],
    [ "TowerDefense.Affectors.CurrencyAffector", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html", [
      [ "Start", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#a0108f21d92435b80fa7d78c81035c0e8", null ],
      [ "Update", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#afd82d13445dbca35a83b24a23af5be17", null ],
      [ "OnEnable", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#ab6f3243ed568cbc195dea7e923c247ae", null ],
      [ "OnDisable", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#a1c2ba9c9a97eafcd47e1f0b4b873d2f0", null ],
      [ "OnCurrencyChanged", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#aee92bb4506b6e55c905194c3f2591bff", null ],
      [ "currencyGainer", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#adeff8702c96d16ea2c96efed67e39c8d", null ],
      [ "descriptionFormat", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#a434e5c0df8de219f0f010d25c4d7f6bd", null ],
      [ "audioSource", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#a9121a517af7cdc66d1ccdd0745c5af0e", null ],
      [ "currencyParticleSystem", "classTowerDefense_1_1Affectors_1_1CurrencyAffector.html#af1ac1ae6545bcd88e4c295837fdf4c95", null ]
    ] ],
    [ "TowerDefense.Affectors.PassiveAffector", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html", [
      [ "radiusEffectColor", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a9887eb8e4eb6291fe99df0111ac7a465", null ],
      [ "towerTargetter", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#ab1d2acb239ca1dc04e929b09ab2a11a1", null ],
      [ "effectRadius", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#ab2a35edd27f9141dffae61ef19cc4e86", null ],
      [ "effectColor", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a5fd9cb362e2b27ccdbdd98307a102229", null ],
      [ "targetter", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a75f66314c81303335677a4431a34fbec", null ]
    ] ],
    [ "TowerDefense.Affectors.SlowAffector", "classTowerDefense_1_1Affectors_1_1SlowAffector.html", [
      [ "Awake", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a57b20aa00d7cda47b6cbcb9725a3e545", null ],
      [ "OnDestroy", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a8707148c471582c8ee4ff3f6436c2ec3", null ],
      [ "AttachSlowComponent", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#ab8c991f8c72d85818d6fab5742c9ff07", null ],
      [ "RemoveSlowComponent", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#ad66d317dea1d0fda8ef94b5b3aba11f2", null ],
      [ "OnTargetEntersRange", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#ab60c6f993612cd7ba3435bcf0e491492", null ],
      [ "OnTargetExitsRange", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a3c632fc5d74b48180c0c7f893c423211", null ],
      [ "slowFactor", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#aa604bc0975c58eb1999540f84edf6da4", null ],
      [ "slowFactorFormat", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a7fcaceeb456b037e59807da55d32597e", null ],
      [ "enterParticleSystem", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a0c1fcbc763b08f372a81b375c7485ff7", null ],
      [ "slowFxPrefab", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#a96f0c71cf27216473421299661be42a3", null ],
      [ "audioSource", "classTowerDefense_1_1Affectors_1_1SlowAffector.html#af82f78e4353df1b308b966f937cb4da6", null ]
    ] ]
];