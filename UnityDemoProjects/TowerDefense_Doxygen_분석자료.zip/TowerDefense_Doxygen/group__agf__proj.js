var group__agf__proj =
[
    [ "ActionGameFramework.Helpers.Ballistics", "classActionGameFramework_1_1Helpers_1_1Ballistics.html", [
      [ "CalculateLinearFireVector", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a7ea34f38999c76e0a508127eb2343df1", null ],
      [ "CalculateLinearFlightTime", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a8d0f4a15fe76637ad744ec7fe38a57fb", null ],
      [ "CalculateLinearLeadingTargetPoint", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a6a12a2f2b649d22cd4f2d3a4cdf8155f", null ],
      [ "CalculateBallisticFireVectorFromAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#adcbf8d04af5a7a05785413406d11d9e2", null ],
      [ "CalculateBallisticFireVectorFromAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#af81a85957f1078a9900672f0f88f4c61", null ],
      [ "CalculateBallisticFireVectorFromVelocity", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#aeb79661bffae7a678af39ede05f9d612", null ],
      [ "CalculateBallisticFireVectorFromVelocity", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#adce2839b7b3168de41a5b85613653eb7", null ],
      [ "CalculateBallisticFireAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#abc470eb73bbca842c65251dd2017668a", null ],
      [ "CalculateBallisticFireAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a82ae97c9eba3243d7d3dbeb587f7ac0e", null ],
      [ "CalculateBallisticFlightTime", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a4111aa2b3965955e261fd2250b5de03f", null ],
      [ "CalculateBallisticFlightTime", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a935af292c549681b254ca56be510c6f0", null ],
      [ "CalculateBallisticLeadingTargetPointWithSpeed", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a239e57ba888e40fe4007a203fc366e9a", null ],
      [ "CalculateBallisticLeadingTargetPointWithSpeed", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a92154129a2606b199c44a04498eab76b", null ],
      [ "CalculateBallisticLeadingTargetPointWithAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#a413acc273d926d842a11caca7d049258", null ],
      [ "CalculateBallisticLeadingTargetPointWithAngle", "classActionGameFramework_1_1Helpers_1_1Ballistics.html#ad6b73c97976f36ade3015fc321580ce9", null ]
    ] ],
    [ "ActionGameFramework.Projectiles.BallisticProjectile", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html", [
      [ "FireAtPoint", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a074a3d590df5740a8e232564526289eb", null ],
      [ "FireInDirection", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#aff8505bfcca85566990b64d7b3218b01", null ],
      [ "FireAtVelocity", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#af1f4b6bb5426e0e1081ed3f9754f8b1a", null ],
      [ "IgnoreCollision", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#abaf42546d8b63db0a40f12fc8cac9ed8", null ],
      [ "Awake", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a0b6c6f9b4e55b7e467913d4fb76f2865", null ],
      [ "Update", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a4d55341467369eee7c0ace8ad9dc391a", null ],
      [ "Fire", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a95ef4dc10ae518dd0b29980e3b4d1340", null ],
      [ "OnValidate", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a0b26415ea667c7fc6e0550f559947c05", null ],
      [ "arcPreference", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a21528940289b01359049aeef83d865bc", null ],
      [ "fireMode", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#aa5bbd0264d6eda771327a8d45b3ea786", null ],
      [ "firingAngle", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#adae5d09ae5b333967a0bbb6b387bb6a2", null ],
      [ "startSpeed", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a5595223cc1270efe2a0d317ec84aa653", null ],
      [ "collisionIgnoreTime", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a3b99ed534f5b04743d6ed1a5ff44de7f", null ],
      [ "m_Fired", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a2bf290072c1d6c5058d37ea6d09729bf", null ],
      [ "m_IgnoringCollsions", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#ab23a247d2abf5fdee502a51beba81eea", null ],
      [ "m_CollisionIgnoreCount", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a90484871a8bfd9f6b096775eedc13438", null ],
      [ "m_Rigidbody", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#aa8fe4be22743cc0a1b6c49a09b30c093", null ],
      [ "m_CollidersIgnoring", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#afe776ee392ea3512c88597c4310d7362", null ],
      [ "m_Colliders", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a4fe4d66ddd9bcb338b9570109af70a91", null ],
      [ "fired", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html#a393fea6a657b326d1d6b35e5e9a21fea", null ]
    ] ],
    [ "ActionGameFramework.Projectiles.HomingLinearProjectile", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html", [
      [ "SetHomingTarget", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a1e3374ebc14e363de895af7140ff8e39", null ],
      [ "FixedUpdate", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#aae4978ff6c327655b41e40cd90f47a11", null ],
      [ "Update", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#ab8eb1d83a5094a981d1123f5a9e6d4be", null ],
      [ "GetHeading", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a7e029872c259afaea71dc83a8bab01d7", null ],
      [ "Fire", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a2eed54022fed326a09b43072eb722d52", null ],
      [ "OnTargetDied", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a557911c607e7a643804c45e3b10b2149", null ],
      [ "leadingPrecision", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a4cf2c5dfa7a9615a075e32cd4a89be1f", null ],
      [ "leadTarget", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a9e3a165abc67c13ae322e75e7028f7be", null ],
      [ "m_HomingTarget", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#a7734cd150f3fc3035999f5ada242ea2e", null ],
      [ "m_TargetVelocity", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html#acd6c98e05fadecd915ea191108d76a72", null ]
    ] ],
    [ "ActionGameFramework.Projectiles.IProjectile", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html", [
      [ "FireAtPoint", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html#a9f0414f8cdfa2bf383aacb112d086b53", null ],
      [ "FireInDirection", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html#abb0e3cce3731741eb89f93b931985f17", null ],
      [ "FireAtVelocity", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html#a52e09474919c6088c575511792c56d9a", null ],
      [ "fired", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html#a133ec571a8caa9e1b823506035b3c438", null ]
    ] ],
    [ "ActionGameFramework.Projectiles.LinearProjectile", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html", [
      [ "FireAtPoint", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#ae006cba1b172a7634419efa8632e2323", null ],
      [ "FireInDirection", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a5f533cc1ddc508f084f1295052afed50", null ],
      [ "FireAtVelocity", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#aa26ecfaa1bb95227471013b01509e3ed", null ],
      [ "Awake", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a9f3d2c4d05c3a49692751428e7b06ce1", null ],
      [ "Update", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#afdcac819fb66ccdb624fd243fcf83da7", null ],
      [ "Fire", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a9f23616d48e06c302b6b63abec4d20c9", null ],
      [ "acceleration", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a74b4a2517d1ab2a29484b6dd174141b5", null ],
      [ "startSpeed", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a36fd39644e77c9f3c0c07ef73af3221f", null ],
      [ "m_Fired", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a2a30f17a7406ecddb5fdab928e0929d7", null ],
      [ "m_Rigidbody", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a046cbf37ed87f68e7790cb272c32da57", null ],
      [ "fired", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html#a93d05a4d1b61f8d5b6ef421b90277a1e", null ]
    ] ],
    [ "ActionGameFramework.Projectiles.WobblingHomingProjectile", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html", [
      [ "State", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a139db9a68acaac48379d87679bc577cf", [
        [ "Wobbling", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a139db9a68acaac48379d87679bc577cfa3dd19b302c23f1cc1cc28aa74a487a51", null ],
        [ "Turning", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a139db9a68acaac48379d87679bc577cfa52f8e1f874b075c87750fd28311b03e7", null ],
        [ "Targeting", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a139db9a68acaac48379d87679bc577cfa78781cc1291aa54a9008720982b04563", null ]
      ] ],
      [ "Update", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#aadca32ed812eb57a798fe72fe927d076", null ],
      [ "Fire", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a8e3c31692c8079df4db4099f6326709a", null ],
      [ "wobbleTimeRange", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#aee726238f60dbee55081fa29e30e0dea", null ],
      [ "wobbleDirectionChangeSpeed", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a010c5ce56842953c755908f1df21a38e", null ],
      [ "wobbleMagnitude", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a6396d42fe2737eb4a51688b3e26d1bc2", null ],
      [ "turningTime", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a71e67f8cd5cbdbc787c6d2a45a35c171", null ],
      [ "m_State", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#af3ba515a81f88256d621b0cb040ac58f", null ],
      [ "m_CurrentWobbleTime", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a8b2c969230e1879bfb2d6d9da17bdec6", null ],
      [ "m_WobbleDuration", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a038cc20cb351204c5c5ba2bf89edf81d", null ],
      [ "m_CurrentTurnTime", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a1922cddd0078772a0abdadeb183ce13c", null ],
      [ "m_WobbleChangeTime", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#ad52839a9729797cf0d640305311df4ed", null ],
      [ "m_WobbleVector", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a0fe857e4fc3ff70c28cbe74e68264aed", null ],
      [ "m_TargetWobbleVector", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html#a3b2ffc3c439af2b1142a62a1b2107399", null ]
    ] ]
];