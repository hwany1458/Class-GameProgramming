var BallisticArcHeight_8cs =
[
    [ "BallisticArcHeight", "BallisticArcHeight_8cs.html#ad2a10140496f48ac8408c1c15e3a4222", [
      [ "UseHigh", "BallisticArcHeight_8cs.html#ad2a10140496f48ac8408c1c15e3a4222ad00f0f9513d88e91e87c77f8658afa75", null ],
      [ "UseLow", "BallisticArcHeight_8cs.html#ad2a10140496f48ac8408c1c15e3a4222ab316058c083c183a203ae9332fcb4419", null ],
      [ "PreferHigh", "BallisticArcHeight_8cs.html#ad2a10140496f48ac8408c1c15e3a4222ab6e5ee6fc6ff479adf22a8fe49554b9c", null ],
      [ "PreferLow", "BallisticArcHeight_8cs.html#ad2a10140496f48ac8408c1c15e3a4222a2c0ecf6c11290a0f1a5158c7a63891be", null ]
    ] ]
];