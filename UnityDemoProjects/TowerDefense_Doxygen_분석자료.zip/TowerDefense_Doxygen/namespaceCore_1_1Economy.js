var namespaceCore_1_1Economy =
[
    [ "Currency", "classCore_1_1Economy_1_1Currency.html", "classCore_1_1Economy_1_1Currency" ]
];