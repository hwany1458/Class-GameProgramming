var classTowerDefense_1_1Game_1_1LevelSaveData =
[
    [ "LevelSaveData", "classTowerDefense_1_1Game_1_1LevelSaveData.html#a9441d54aa8f8405d189417ffc4390e7a", null ],
    [ "id", "classTowerDefense_1_1Game_1_1LevelSaveData.html#a9e0a658bb83f5bbacd5bbf13ffc2333f", null ],
    [ "numberOfStars", "classTowerDefense_1_1Game_1_1LevelSaveData.html#ad34d090c7cdd9be396ad652b3604d8e5", null ]
];