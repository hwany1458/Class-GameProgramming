var structCore_1_1Health_1_1HitInfo =
[
    [ "HitInfo", "structCore_1_1Health_1_1HitInfo.html#a0db28c971952bfa0d1a3314d6281695e", null ],
    [ "m_HealthChangeInfo", "structCore_1_1Health_1_1HitInfo.html#a23ca5023d4675f8b82ba24de3c727df5", null ],
    [ "m_DamagePoint", "structCore_1_1Health_1_1HitInfo.html#aaf65d5bae917a53dac9cd568ab6278ea", null ],
    [ "healthChangeInfo", "structCore_1_1Health_1_1HitInfo.html#a51f0031d4274ffdef95ce5479074ff13", null ],
    [ "damagePoint", "structCore_1_1Health_1_1HitInfo.html#a8e4d05a4b271a6a1b2eb0a464de51bf4", null ]
];