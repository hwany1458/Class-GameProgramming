var namespaceActionGameFramework_1_1Projectiles =
[
    [ "Editor", "namespaceActionGameFramework_1_1Projectiles_1_1Editor.html", "namespaceActionGameFramework_1_1Projectiles_1_1Editor" ],
    [ "BallisticProjectile", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile.html", "classActionGameFramework_1_1Projectiles_1_1BallisticProjectile" ],
    [ "HomingLinearProjectile", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile.html", "classActionGameFramework_1_1Projectiles_1_1HomingLinearProjectile" ],
    [ "IProjectile", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html", "interfaceActionGameFramework_1_1Projectiles_1_1IProjectile" ],
    [ "LinearProjectile", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile.html", "classActionGameFramework_1_1Projectiles_1_1LinearProjectile" ],
    [ "WobblingHomingProjectile", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile.html", "classActionGameFramework_1_1Projectiles_1_1WobblingHomingProjectile" ],
    [ "BallisticArcHeight", "namespaceActionGameFramework_1_1Projectiles.html#ad2a10140496f48ac8408c1c15e3a4222", [
      [ "UseHigh", "namespaceActionGameFramework_1_1Projectiles.html#ad2a10140496f48ac8408c1c15e3a4222ad00f0f9513d88e91e87c77f8658afa75", null ],
      [ "UseLow", "namespaceActionGameFramework_1_1Projectiles.html#ad2a10140496f48ac8408c1c15e3a4222ab316058c083c183a203ae9332fcb4419", null ],
      [ "PreferHigh", "namespaceActionGameFramework_1_1Projectiles.html#ad2a10140496f48ac8408c1c15e3a4222ab6e5ee6fc6ff479adf22a8fe49554b9c", null ],
      [ "PreferLow", "namespaceActionGameFramework_1_1Projectiles.html#ad2a10140496f48ac8408c1c15e3a4222a2c0ecf6c11290a0f1a5158c7a63891be", null ]
    ] ],
    [ "BallisticFireMode", "namespaceActionGameFramework_1_1Projectiles.html#a49b50ad71cd1d6af7e6b4232935ae295", [
      [ "UseLaunchSpeed", "namespaceActionGameFramework_1_1Projectiles.html#a49b50ad71cd1d6af7e6b4232935ae295a5e696daf2b7a5c39be57d88a2baf00f3", null ],
      [ "UseLaunchAngle", "namespaceActionGameFramework_1_1Projectiles.html#a49b50ad71cd1d6af7e6b4232935ae295ac56e39e9e7c193e8b7c8ff29bb4df536", null ]
    ] ]
];