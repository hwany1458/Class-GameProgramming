var classTowerDefense_1_1Affectors_1_1PassiveAffector =
[
    [ "radiusEffectColor", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a9887eb8e4eb6291fe99df0111ac7a465", null ],
    [ "towerTargetter", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#ab1d2acb239ca1dc04e929b09ab2a11a1", null ],
    [ "effectRadius", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#ab2a35edd27f9141dffae61ef19cc4e86", null ],
    [ "effectColor", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a5fd9cb362e2b27ccdbdd98307a102229", null ],
    [ "targetter", "classTowerDefense_1_1Affectors_1_1PassiveAffector.html#a75f66314c81303335677a4431a34fbec", null ]
];