/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Tower Defense Template 소스 분석", "index.html", [
    [ "세 계층 구조", "index.html#sec_layers", null ],
    [ "한눈에 보는 구조", "index.html#sec_overview", null ],
    [ "핵심 루프 1회: 적 하나가 홈베이스까지 가거나 죽기까지", "index.html#sec_loop", null ],
    [ "데이터와 로직의 분리", "index.html#sec_data", null ],
    [ "현황 판정 요약 (강의용)", "index.html#sec_status", null ],
    [ "확장 포인트 (2단계 입력)", "index.html#sec_extension", null ],
    [ "모듈 안내", "index.html#sec_modules", null ],
    [ "Topics", "topics.html", "topics" ],
    [ "패키지", "namespaces.html", [
      [ "Package List", "namespaces.html", "namespaces_dup" ],
      [ "패키지 멤버들", "namespacemembers.html", [
        [ "모두", "namespacemembers.html", null ],
        [ "함수", "namespacemembers_func.html", null ],
        [ "열거형 타입", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "클래스", "annotated.html", [
      [ "클래스 목록", "annotated.html", "annotated_dup" ],
      [ "클래스 색인", "classes.html", null ],
      [ "클래스 계통도", "hierarchy.html", "hierarchy" ],
      [ "클래스 멤버", "functions.html", [
        [ "모두", "functions.html", "functions_dup" ],
        [ "함수", "functions_func.html", "functions_func" ],
        [ "변수", "functions_vars.html", "functions_vars" ],
        [ "열거형 타입", "functions_enum.html", null ],
        [ "속성", "functions_prop.html", null ],
        [ "이벤트", "functions_evnt.html", null ]
      ] ]
    ] ],
    [ "파일들", "files.html", [
      [ "파일 목록", "files.html", "files_dup" ],
      [ "파일 멤버", "globals.html", [
        [ "모두", "globals.html", null ],
        [ "타입정의", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Affector_8cs.html",
"PointerActionInfo_8cs.html",
"classActionGameFramework_1_1Projectiles_1_1Editor_1_1BallisticProjectileEditor.html#ac23f5fae5c8e059234619188a5e44c29",
"classCore_1_1Health_1_1DamageableBehaviour.html#a116b9451e3a0af5d6d0a514353c251ee",
"classCore_1_1Utilities_1_1Editor_1_1HexPointTests.html#afba01e7f766641dfdf79ed2a644fc73b",
"classTowerDefense_1_1Economy_1_1LootDrop.html",
"classTowerDefense_1_1Nodes_1_1RandomNodeSelector.html#aea0e8a167e44645b89b17ef7954ed937",
"classTowerDefense_1_1UI_1_1EndGameScreen.html#a6170b1bec0b6f09e6a23bcf7c349c803",
"classTowerDefense_1_1UI_1_1MouseScroll.html#a049324cffd3d7a544a477829e1ed3eec",
"interfaceActionGameFramework_1_1Projectiles_1_1IProjectile.html#a9f0414f8cdfa2bf383aacb112d086b53"
];

var SYNCONMSG = '패널 동기화를 비활성화하기 위해 클릭하십시오';
var SYNCOFFMSG = '패널 동기화를 활성화하기 위해 클릭하십시오';