var TowerFitStatus_8cs =
[
    [ "TowerFitStatus", "TowerFitStatus_8cs.html#a9a2c196cd17505eb013413ae822e3706", [
      [ "Fits", "TowerFitStatus_8cs.html#a9a2c196cd17505eb013413ae822e3706aa00f6d6b3c23f1db2f1509dfb2644a0d", null ],
      [ "Overlaps", "TowerFitStatus_8cs.html#a9a2c196cd17505eb013413ae822e3706a0f6cd0a96a11dbf73252729e2f8271d2", null ],
      [ "OutOfBounds", "TowerFitStatus_8cs.html#a9a2c196cd17505eb013413ae822e3706a46dc1018ac1d8fca7c2752a61ce2fd0f", null ]
    ] ]
];