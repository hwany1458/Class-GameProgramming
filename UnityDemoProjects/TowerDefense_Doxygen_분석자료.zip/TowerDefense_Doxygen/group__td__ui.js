var group__td__ui =
[
    [ "TowerDefense.UI.EndGameScreen", "classTowerDefense_1_1UI_1_1EndGameScreen.html", [
      [ "GoToMainMenu", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a36c3f8895b9f8869a12705553c9dd437", null ],
      [ "RestartLevel", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a83240d23df2d7156ca63e5cd46c6eb16", null ],
      [ "GoToNextLevel", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a5d6b083f3f8a65ed5d59f404b8f973f2", null ],
      [ "Start", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a1f2dd6badfb47e754a3d099fa3e07696", null ],
      [ "OpenEndGameScreen", "classTowerDefense_1_1UI_1_1EndGameScreen.html#ad17c44bb952251b3a008c3e5262f5972", null ],
      [ "Victory", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a1948f16627c69a170fd983067b39533d", null ],
      [ "Defeat", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a3ce47882e72397ee25ca871e2462d421", null ],
      [ "OnDestroy", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a54107cb1e52a53f377dca335483cb10f", null ],
      [ "SafelyUnsubscribe", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a491abf2a85b19c1dc8af832853aa83b0", null ],
      [ "LazyLoad", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a03bdf6ad70255e65176fe0b0a3ed82be", null ],
      [ "CalculateFinalScore", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a268ae0fbfdf13b0d5ed5c2b1a9234478", null ],
      [ "CalculateScore", "classTowerDefense_1_1UI_1_1EndGameScreen.html#af1e94450f9160bdc7e30e8995c1fe99e", null ],
      [ "victorySound", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a53381fb4d8a7969140fbbdc9a248c620", null ],
      [ "defeatSound", "classTowerDefense_1_1UI_1_1EndGameScreen.html#acd1ed549b755fbe6fcecd15e41775127", null ],
      [ "audioSource", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a023e319a43ccaab05785641837b1f09b", null ],
      [ "endGameCanvas", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a401db13a9bb9a4d0ae71379948fc327b", null ],
      [ "endGameMessageText", "classTowerDefense_1_1UI_1_1EndGameScreen.html#afba20d4b8bf4f275fc9a6d8e62d4be91", null ],
      [ "scorePanel", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a27c71004ec2f14bd3a7143a82aaa50c3", null ],
      [ "menuSceneName", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a37303b43359d1f868ccef7d5662fb3bd", null ],
      [ "levelCompleteText", "classTowerDefense_1_1UI_1_1EndGameScreen.html#ae097fc358589726cf6de659db04a1d8f", null ],
      [ "levelFailedText", "classTowerDefense_1_1UI_1_1EndGameScreen.html#ac222b898dd977aaefee1d0a6408a53cb", null ],
      [ "background", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a72f6c3c1369762f23fc7c01432649faf", null ],
      [ "winBackgroundColor", "classTowerDefense_1_1UI_1_1EndGameScreen.html#aeb2aa1ab7edb76573fd7552ecfd84906", null ],
      [ "loseBackgroundColor", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a3eda0109e7ce97276a07aceb37eb7ba5", null ],
      [ "nextLevelButton", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a6170b1bec0b6f09e6a23bcf7c349c803", null ],
      [ "m_LevelManager", "classTowerDefense_1_1UI_1_1EndGameScreen.html#a035ac65c64ce994cda5933d40c8073d6", null ]
    ] ],
    [ "TowerDefense.UI.ExitButton", "classTowerDefense_1_1UI_1_1ExitButton.html", [
      [ "OnPointerClick", "classTowerDefense_1_1UI_1_1ExitButton.html#a896105116d95f6ed960f7418e2778d72", null ],
      [ "Awake", "classTowerDefense_1_1UI_1_1ExitButton.html#a5163fe093e7b887e936bb2b92b45a7b4", null ]
    ] ],
    [ "TowerDefense.UI.IntervalParticleSystemPlayer", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html", [
      [ "Start", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html#a9e9d9f686dcbc433b507b97524d520f9", null ],
      [ "Update", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html#af9b5f582927c0b497b6b868a4c292b05", null ],
      [ "particleSystemToPlay", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html#a0904c2acd61ace6541272973682cdc46", null ],
      [ "interval", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html#a65da41be47f7f6ee1abdfff59a6d6ec2", null ],
      [ "m_NextPlayTime", "classTowerDefense_1_1UI_1_1IntervalParticleSystemPlayer.html#a40fa57518811a0052ff341b25c2863fb", null ]
    ] ],
    [ "TowerDefense.UI.LevelSelectButton", "classTowerDefense_1_1UI_1_1LevelSelectButton.html", [
      [ "ButtonClicked", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a0cd95c97b996d27c108025d7965fb107", null ],
      [ "Initialize", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a65617ace3da27b784b162e6ecac519b7", null ],
      [ "HasPlayedState", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a98c111c29f03c61202a59d7894e5faeb", null ],
      [ "ChangeScenes", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#abb7c35bf405abc09ff2d88409081ffcc", null ],
      [ "LazyLoad", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a7562e024475f0b3de32c88ef4e307b90", null ],
      [ "OnDestroy", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#ac550189b288c51a12526e74352442eb6", null ],
      [ "OnSelect", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#ae289d18c6956966bb6206e9051d34bfb", null ],
      [ "m_Button", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a90654fd0e0b416e6b3d49b1bd4f4011c", null ],
      [ "titleDisplay", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a0d0913d8293e7cfaff51f766cd0635cc", null ],
      [ "description", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#afac254a0755816f7386b6183d3c6d781", null ],
      [ "starAchieved", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#acd7966d14c29b0f5ad55ec5a6dc739d3", null ],
      [ "stars", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#aa3581c00cc80a39595ffe2654666de29", null ],
      [ "m_MouseScroll", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a4979e2882cf1d0908e195c3daed117c2", null ],
      [ "m_Item", "classTowerDefense_1_1UI_1_1LevelSelectButton.html#a0ddbeda86e9c75a7a7cf9efc3327d832", null ]
    ] ],
    [ "TowerDefense.UI.LevelSelectScreen", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html", [
      [ "Start", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a667dc6056ea356b07e2655ff66de4031", null ],
      [ "CreateButton", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a9d6c6e92b893d0d9641dfe25a45496ae", null ],
      [ "Show", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a9c9b4d9c1cd559a0ab6e4ff03b749b3c", null ],
      [ "Hide", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a86ac94e5acf337ad39262c72fff6315b", null ],
      [ "SetUpNavigation", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a505ead759ac9c475258d5d2af08e8ee9", null ],
      [ "selectionPrefab", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#aedc3a219ec2e77fdc6722b37c1c542ff", null ],
      [ "layout", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a1dbcdeeb2af645f2f73dc06b65737938", null ],
      [ "rightBuffer", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a85116d93e904e3a58a5897d6b79b9397", null ],
      [ "backButton", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a431cc56e68e0cdca03c3221f2cd30638", null ],
      [ "mouseScroll", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a01dd7de956fc4ffd1ff95e6bf60080f4", null ],
      [ "cameraAnimator", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#aca3c01c1e4068f1af5a7852cbdf69030", null ],
      [ "enterCameraAnim", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a4f876d8873205011c015bfe886137ca7", null ],
      [ "exitCameraAnim", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#ace77d6e6d0c69e2f3a483f43b81a0ce4", null ],
      [ "m_LevelList", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a55d00317a0d6641c4d1c05abbc34b031", null ],
      [ "m_Buttons", "classTowerDefense_1_1UI_1_1LevelSelectScreen.html#a859335e8c5a1e45c8b5c9f5ac6cd4a12", null ]
    ] ],
    [ "TowerDefense.UI.MouseScroll", "classTowerDefense_1_1UI_1_1MouseScroll.html", [
      [ "SetHasRightBuffer", "classTowerDefense_1_1UI_1_1MouseScroll.html#a3a103752cd69af6f1f47fbc7c86d9263", null ],
      [ "Start", "classTowerDefense_1_1UI_1_1MouseScroll.html#a15b16c3c39bbc606c31c04a3493128ff", null ],
      [ "Update", "classTowerDefense_1_1UI_1_1MouseScroll.html#a6beac8e89ea5a234f31396e282a5b318", null ],
      [ "SelectChild", "classTowerDefense_1_1UI_1_1MouseScroll.html#a049324cffd3d7a544a477829e1ed3eec", null ],
      [ "clampScroll", "classTowerDefense_1_1UI_1_1MouseScroll.html#a46396a878792ac94128b5edd7cfa2068", null ],
      [ "scrollXBuffer", "classTowerDefense_1_1UI_1_1MouseScroll.html#a80a74b49f2314af9b23a59e608227795", null ],
      [ "scrollYBuffer", "classTowerDefense_1_1UI_1_1MouseScroll.html#a41f634e709381ccd2ee03a78273015fc", null ],
      [ "m_ScrollRect", "classTowerDefense_1_1UI_1_1MouseScroll.html#aeb0f6c258dd4f39bdc476b8a116b5594", null ],
      [ "m_ScrollRectTransform", "classTowerDefense_1_1UI_1_1MouseScroll.html#aaef6bb12662f21f8e6d353b03d12819e", null ],
      [ "m_OverrideScrolling", "classTowerDefense_1_1UI_1_1MouseScroll.html#a072f87557cd0f9e92f8435959bf83c8d", null ],
      [ "m_HasRightBuffer", "classTowerDefense_1_1UI_1_1MouseScroll.html#a7e9e9eeafb9b56dd3e900636208bfe89", null ]
    ] ],
    [ "TowerDefense.UI.MovingCanvas", "classTowerDefense_1_1UI_1_1MovingCanvas.html", [
      [ "TryMove", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a8ffeb2b9450d7f2f7e5c0482d81df38b", null ],
      [ "Awake", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a5e31613bf1636aa40c3b1c3c73ecea9b", null ],
      [ "content", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a28a6c27c382541ee411742552906d3b7", null ],
      [ "offset", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a1b15b0ce386d765c8605a3e3ae750c40", null ],
      [ "m_Canvas", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a18c7526f18bbf4851eb1e33c451f36a1", null ],
      [ "canvasEnabled", "classTowerDefense_1_1UI_1_1MovingCanvas.html#a2432179591e941226241e05f1cc350bb", null ]
    ] ],
    [ "TowerDefense.UI.OptionsMenu", "classTowerDefense_1_1UI_1_1OptionsMenu.html", [
      [ "UpdateVolumes", "classTowerDefense_1_1UI_1_1OptionsMenu.html#a153fa5a492bd16c739df96f85be43a04", null ],
      [ "Show", "classTowerDefense_1_1UI_1_1OptionsMenu.html#a544d9262b6d57644bc7ead842ca08a00", null ],
      [ "Hide", "classTowerDefense_1_1UI_1_1OptionsMenu.html#af1ef0fe6bd31665301938aadce52274a", null ],
      [ "GetSliderVolumes", "classTowerDefense_1_1UI_1_1OptionsMenu.html#ab9fdf26ece004ef89e323651aa40232b", null ],
      [ "masterSlider", "classTowerDefense_1_1UI_1_1OptionsMenu.html#a7ab34f50ca7ed832423b766ed3a4924e", null ],
      [ "sfxSlider", "classTowerDefense_1_1UI_1_1OptionsMenu.html#ab0d1f62c831ab2a0f4302ae1d80a00ce", null ],
      [ "musicSlider", "classTowerDefense_1_1UI_1_1OptionsMenu.html#aed16ea751ce10f9635e4a286f5839714", null ]
    ] ],
    [ "TowerDefense.UI.PauseMenu", "classTowerDefense_1_1UI_1_1PauseMenu.html", [
      [ "State", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae0b83266c579db5704f9684ded237a82", [
        [ "Open", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae0b83266c579db5704f9684ded237a82ac3bf447eabe632720a3aa1a7ce401274", null ],
        [ "LevelSelectPressed", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae0b83266c579db5704f9684ded237a82a3e54a1889a050cf6df7e8ca3d9242da4", null ],
        [ "RestartPressed", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae0b83266c579db5704f9684ded237a82a588dcffd67b20af6feb251367b3ca28c", null ],
        [ "Closed", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae0b83266c579db5704f9684ded237a82a03f4a47830f97377a35321051685071e", null ]
      ] ],
      [ "OpenPauseMenu", "classTowerDefense_1_1UI_1_1PauseMenu.html#a3f9181cf5b1f35c5d3dd51476195cdcc", null ],
      [ "OnGameUIStateChanged", "classTowerDefense_1_1UI_1_1PauseMenu.html#a73e67737a604eca823554fc0ac1bf7ff", null ],
      [ "LevelSelectPressed", "classTowerDefense_1_1UI_1_1PauseMenu.html#aed3dd6e0a9b2554b790a063194fda84e", null ],
      [ "RestartPressed", "classTowerDefense_1_1UI_1_1PauseMenu.html#a1bc89a832988fde0fc00fcc0b7db8562", null ],
      [ "ClosePauseMenu", "classTowerDefense_1_1UI_1_1PauseMenu.html#acff129448c080e042707d8e01a999e0f", null ],
      [ "Awake", "classTowerDefense_1_1UI_1_1PauseMenu.html#a6a4404cd86e39480ef0122a7f0121c39", null ],
      [ "Start", "classTowerDefense_1_1UI_1_1PauseMenu.html#a2a797e8a522e97f672658ea41c202b9f", null ],
      [ "Update", "classTowerDefense_1_1UI_1_1PauseMenu.html#afc6361db55433f72c6d0c08add667c8e", null ],
      [ "SetPauseMenuCanvas", "classTowerDefense_1_1UI_1_1PauseMenu.html#a8bdd84a04a50751a93c4dae8e17c0fe7", null ],
      [ "Pause", "classTowerDefense_1_1UI_1_1PauseMenu.html#a6fb97c5a0dcb3b0d8d2c755103449855", null ],
      [ "Unpause", "classTowerDefense_1_1UI_1_1PauseMenu.html#a1c9f7809c08308c6369ff293cfa0a525", null ],
      [ "pauseMenuCanvas", "classTowerDefense_1_1UI_1_1PauseMenu.html#a8b522b56ce9c4c6a1fb3b2c3d5bb2371", null ],
      [ "titleText", "classTowerDefense_1_1UI_1_1PauseMenu.html#aef3e6f6db2cf94a7f71d53c8876d068e", null ],
      [ "descriptionText", "classTowerDefense_1_1UI_1_1PauseMenu.html#a74e5af2b43e2773db8b87eb5bba02076", null ],
      [ "levelSelectConfirmButton", "classTowerDefense_1_1UI_1_1PauseMenu.html#ae509dceae6f05f4693c3f83dfd3b5c30", null ],
      [ "restartConfirmButton", "classTowerDefense_1_1UI_1_1PauseMenu.html#a256dc1b0a0752e6564fb241f4e9086f2", null ],
      [ "levelSelectButton", "classTowerDefense_1_1UI_1_1PauseMenu.html#ac67ad0bc4cd3cda1e0225c3bcb3db808", null ],
      [ "restartButton", "classTowerDefense_1_1UI_1_1PauseMenu.html#ab8ea42a3179181a6e38cf2af289f5898", null ],
      [ "topPanel", "classTowerDefense_1_1UI_1_1PauseMenu.html#a861c87332f3964785abe4106c983bf47", null ],
      [ "topPanelDisabledColor", "classTowerDefense_1_1UI_1_1PauseMenu.html#ab84985fcd58a4fcec70bf3cbd2296101", null ],
      [ "m_State", "classTowerDefense_1_1UI_1_1PauseMenu.html#a1d876a4a51f71fe40a528939e90af1e8", null ],
      [ "m_MenuChangedThisFrame", "classTowerDefense_1_1UI_1_1PauseMenu.html#acb770e73e0612d5e79398e33c6be4eb0", null ]
    ] ],
    [ "TowerDefense.UI.PlayAnimation", "classTowerDefense_1_1UI_1_1PlayAnimation.html", [
      [ "Play", "classTowerDefense_1_1UI_1_1PlayAnimation.html#a2186ce8c8182c44d4cf5d5c0d619ac09", null ],
      [ "Start", "classTowerDefense_1_1UI_1_1PlayAnimation.html#a24c13afb65c655577209a8baf88814bf", null ],
      [ "m_Animation", "classTowerDefense_1_1UI_1_1PlayAnimation.html#ac63ac10083c54213eb50f9e950b6ca71", null ]
    ] ],
    [ "TowerDefense.UI.RadiusVisualizerController", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html", [
      [ "SetupRadiusVisualizers", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#a27a46e2e1c88a7cb8ae53e692aaff23a", null ],
      [ "HideRadiusVisualizers", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#a1df127630e7532034f7febb863251a08", null ],
      [ "radiusVisualizerPrefab", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#a3ebe984e8af050af5f1587a85709e689", null ],
      [ "radiusVisualizerHeight", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#ae3add0bbfd2ac72894ddf276aa0ea7a8", null ],
      [ "localEuler", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#ae72d120996b5f11b99f056d5dab9ebd9", null ],
      [ "m_RadiusVisualizers", "classTowerDefense_1_1UI_1_1RadiusVisualizerController.html#a5a72ede5abb176135384166acb716d10", null ]
    ] ],
    [ "TowerDefense.UI.Rotator", "classTowerDefense_1_1UI_1_1Rotator.html", [
      [ "Update", "classTowerDefense_1_1UI_1_1Rotator.html#a3c94a190328eb5995b49a00fbae43fab", null ],
      [ "rotationSpeed", "classTowerDefense_1_1UI_1_1Rotator.html#a8fb6bb24af4b29dc2849aa272f89f54a", null ]
    ] ],
    [ "TowerDefense.UI.SceneLoader", "classTowerDefense_1_1UI_1_1SceneLoader.html", [
      [ "LoadScene", "classTowerDefense_1_1UI_1_1SceneLoader.html#a12001baeef48d2ae59d30dc70388f92e", null ],
      [ "RestartCurrentScene", "classTowerDefense_1_1UI_1_1SceneLoader.html#a745adbb84f37366d583de63646a46b89", null ],
      [ "sceneToLoadName", "classTowerDefense_1_1UI_1_1SceneLoader.html#a0a49d5cd3d6cb0b9333ff9d2dc14e239", null ]
    ] ],
    [ "TowerDefense.UI.ScorePanel", "classTowerDefense_1_1UI_1_1ScorePanel.html", [
      [ "SetStars", "classTowerDefense_1_1UI_1_1ScorePanel.html#a75c6c324ca06e288304891911286654e", null ],
      [ "starImages", "classTowerDefense_1_1UI_1_1ScorePanel.html#a00fd475ab1711e802d9ef356e7d1bca3", null ],
      [ "achievedStarSprite", "classTowerDefense_1_1UI_1_1ScorePanel.html#a44eab16ffff293f37dca7bda9f02d06e", null ]
    ] ],
    [ "TowerDefense.UI.TowerDefenseInputSchemeSwitcher", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html", [
      [ "Start", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#a3b353d7769c827af04351e32ec647531", null ],
      [ "Update", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#adab371510ac1c0cc785f38ade6760ac9", null ],
      [ "OnDestroy", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#a0926a15f08f9cc9c0d7f9ae3635ec05f", null ],
      [ "OnUIStateChanged", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#a7f66afa9688ed7afa581040854b5160c", null ],
      [ "isPaused", "classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#a7a2a41ec9a39f6e3dfa5d0ed6201086a", null ]
    ] ],
    [ "TowerDefense.UI.UrlOpen", "classTowerDefense_1_1UI_1_1UrlOpen.html", [
      [ "OpenUrl", "classTowerDefense_1_1UI_1_1UrlOpen.html#a743f925d8a51e8dbb9d4c39e755a198b", null ]
    ] ]
];