var namespaceCore_1_1Health =
[
    [ "Damageable", "classCore_1_1Health_1_1Damageable.html", "classCore_1_1Health_1_1Damageable" ],
    [ "DamageableBehaviour", "classCore_1_1Health_1_1DamageableBehaviour.html", "classCore_1_1Health_1_1DamageableBehaviour" ],
    [ "DamageableListener", "classCore_1_1Health_1_1DamageableListener.html", "classCore_1_1Health_1_1DamageableListener" ],
    [ "DeathEffect", "classCore_1_1Health_1_1DeathEffect.html", "classCore_1_1Health_1_1DeathEffect" ],
    [ "HealthChangeEvent", "classCore_1_1Health_1_1HealthChangeEvent.html", null ],
    [ "HealthChangeInfo", "structCore_1_1Health_1_1HealthChangeInfo.html", "structCore_1_1Health_1_1HealthChangeInfo" ],
    [ "HealthVisualizer", "classCore_1_1Health_1_1HealthVisualizer.html", "classCore_1_1Health_1_1HealthVisualizer" ],
    [ "HitEvent", "classCore_1_1Health_1_1HitEvent.html", null ],
    [ "HitInfo", "structCore_1_1Health_1_1HitInfo.html", "structCore_1_1Health_1_1HitInfo" ],
    [ "IAlignmentProvider", "interfaceCore_1_1Health_1_1IAlignmentProvider.html", "interfaceCore_1_1Health_1_1IAlignmentProvider" ],
    [ "SerializableIAlignmentProvider", "classCore_1_1Health_1_1SerializableIAlignmentProvider.html", null ],
    [ "SimpleAlignment", "classCore_1_1Health_1_1SimpleAlignment.html", "classCore_1_1Health_1_1SimpleAlignment" ]
];