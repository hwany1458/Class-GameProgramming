var group__td__place =
[
    [ "TowerDefense.Towers.Placement.IPlacementArea", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html", [
      [ "WorldToGrid", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#a5d9e080c9bb7aff19930af527776cc3e", null ],
      [ "GridToWorld", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#ab0bb7aaa1ed620319744f6ca1a620c27", null ],
      [ "Fits", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#a8f9af5a0dafcac450e17c84e019d43ce", null ],
      [ "Occupy", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#a0df64b7761d8b26c44d9edd93ee3700f", null ],
      [ "Clear", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#a4c2b116c6aba102e9e05a56e57924da6", null ],
      [ "transform", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html#a8d129ac6ff1d372b2dfaa709910e9310", null ]
    ] ],
    [ "TowerDefense.Towers.Placement.PlacementAreaExtensions", "classTowerDefense_1_1Towers_1_1Placement_1_1PlacementAreaExtensions.html", [
      [ "Snap", "classTowerDefense_1_1Towers_1_1Placement_1_1PlacementAreaExtensions.html#aec72b2a583e380833d80d7f4c52dda46", null ]
    ] ],
    [ "TowerDefense.Towers.Placement.SingleTowerPlacementArea", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html", [
      [ "Awake", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a9e6046d91f606398948bb69d732ad276", null ],
      [ "WorldToGrid", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a27bef3a59229e170bbc4d2209f01c031", null ],
      [ "GridToWorld", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a0886ec4f5d6e9306bfb2592d6d160010", null ],
      [ "Fits", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#ac4ceddd48bb248253637759ee72a54c9", null ],
      [ "Occupy", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a2fb15c4d7607ccc99d8e1f7b9ca082cf", null ],
      [ "Clear", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#ab4418388a73899d12b5b81954807cf14", null ],
      [ "OnDrawGizmos", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a78ca9d4a208446130a687b7dd2ef5104", null ],
      [ "placementTilePrefab", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#ab80b5fedf1829e9add17cbc667b0079f", null ],
      [ "placementTilePrefabMobile", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#ab294553d72b209fc0d76535eb8aa8bd5", null ],
      [ "m_SpawnedTile", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a097ec4d5989a682f1f37c8d4f3ed9b55", null ],
      [ "m_IsOccupied", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html#a25010b8ee2b39898d00444d602dc5007", null ]
    ] ],
    [ "TowerDefense.Towers.Placement.TowerPlacementGrid", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html", [
      [ "WorldToGrid", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a13b6fd41f6a7862aad1eafc61ff53096", null ],
      [ "GridToWorld", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#ad27342e2d6db85b99ebeedc47660640a", null ],
      [ "Fits", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a67a2616ee1905ade65f412d6aa42b982", null ],
      [ "Occupy", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a0fcca67858203bc31ca4f706ddef6b63", null ],
      [ "Clear", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#ab11c29c5bac2298e6f6f0ccf19ccbb45", null ],
      [ "Awake", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a9bb17340ac365690de83b62431c7c81b", null ],
      [ "ResizeCollider", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a441406d576aa494f5c587374cb9247a9", null ],
      [ "SetUpGrid", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a24f8996b37148d5bd6fbb6f518c795d2", null ],
      [ "OnValidate", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#ad777784430a438acdb69649d3606d3c8", null ],
      [ "OnDrawGizmos", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#af5875a14b8e5b1137fdc49556b1959b6", null ],
      [ "placementTilePrefab", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#ab5c1fd66ed33b2dd3aa13a22bd6d5954", null ],
      [ "placementTilePrefabMobile", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a85898d7e8a8078be67a529c2fd62fb83", null ],
      [ "dimensions", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a6d87aa6ff6e431500debe2e396aa6c21", null ],
      [ "gridSize", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#ac0fd22394e55090869b8c582599e26c8", null ],
      [ "m_InvGridSize", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#afd1cbb91addca9fd0106d761cfee74c6", null ],
      [ "m_AvailableCells", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a0afca40166615a35cf593f7323682842", null ],
      [ "m_Tiles", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html#a2387d3b08ffcbb684f5644c3c3e7ee07", null ]
    ] ]
];