var interfaceCore_1_1Data_1_1IDataSaver =
[
    [ "Save", "interfaceCore_1_1Data_1_1IDataSaver.html#a5842179bd803f3e67f6a23efed91a797", null ],
    [ "Load", "interfaceCore_1_1Data_1_1IDataSaver.html#ab6bcb7abaf0ea61dd83f0ab1294b2d02", null ],
    [ "Delete", "interfaceCore_1_1Data_1_1IDataSaver.html#af26fc5f0740ea433c8fe8a1bb888dac8", null ]
];