var searchData=
[
  ['jsonsaver_0',['jsonsaver',['../classCore_1_1Data_1_1JsonSaver.html',1,'Core.Data.JsonSaver&lt; T &gt;'],['../classCore_1_1Data_1_1JsonSaver.html#aa053c19f5a7d0aed026d14332e73d7a0',1,'Core.Data.JsonSaver.JsonSaver()']]],
  ['jsonsaver_2ecs_1',['JsonSaver.cs',['../JsonSaver_8cs.html',1,'']]],
  ['jsonsaver_3c_20tdatastore_20_3e_2',['JsonSaver&lt; TDataStore &gt;',['../classCore_1_1Data_1_1JsonSaver.html',1,'Core::Data']]]
];
