var searchData=
[
  ['healthchangeinfo_0',['healthChangeInfo',['../structCore_1_1Health_1_1HitInfo.html#a51f0031d4274ffdef95ce5479074ff13',1,'Core::Health::HitInfo']]],
  ['healthdifference_1',['healthDifference',['../structCore_1_1Health_1_1HealthChangeInfo.html#aaa10a46b8584c1a712f079422266050a',1,'Core::Health::HealthChangeInfo']]]
];
