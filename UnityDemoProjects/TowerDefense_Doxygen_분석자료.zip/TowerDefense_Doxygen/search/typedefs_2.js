var searchData=
[
  ['object_0',['object',['../SerializableInterfaceDrawer_8cs.html#aef19bab18b9814edeef255c43e4f6bbc',1,'Object:&#160;SerializableInterfaceDrawer.cs'],['../Pool_8cs.html#aef19bab18b9814edeef255c43e4f6bbc',1,'Object:&#160;Pool.cs']]]
];
