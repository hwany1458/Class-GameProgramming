var searchData=
[
  ['ghostcollider_0',['ghostCollider',['../classTowerDefense_1_1UI_1_1HUD_1_1TowerPlacementGhost.html#a89bf5d2db75eab5fe4ecadf2042fc0f8',1,'TowerDefense::UI::HUD::TowerPlacementGhost']]],
  ['gridposition_1',['gridPosition',['../classTowerDefense_1_1Towers_1_1Tower.html#a9920e3e6c844d99b677d93d01ec012a5',1,'TowerDefense::Towers::Tower']]]
];
