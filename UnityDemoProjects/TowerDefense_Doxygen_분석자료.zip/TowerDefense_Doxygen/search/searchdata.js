var indexSectionsWithContent =
{
  0: "12abcdefghijklmnoprstuvwxyz—가강게경계구기노단데레로루리매메모목배변보분뼈사상생선세소스싱안어에영오요유입저적전조주죽체카타터투판포피하한핵현홈확효",
  1: "abcdefghijklmnoprstuvw",
  2: "act",
  3: "abcdefghijklmnoprstuvw",
  4: "abcdefghijklmnoprstuvwxyz",
  5: "abcdefghiklmnoprstuvwxyz",
  6: "dgorstu",
  7: "ablpst",
  8: "abcefghilnoprstuw",
  9: "abcdefghiklmnoprstuvwz",
  10: "abcdfghilmnprstw",
  11: "abcdhtu—게경기노단데레리매메목배변뼈사상생선스싱어에영오유입저적전조주체카타터투피효",
  12: "dt분소"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "events",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수",
  6: "타입정의",
  7: "열거형 타입",
  8: "열거형 멤버",
  9: "속성",
  10: "이벤트",
  11: "그룹들",
  12: "페이지들"
};

