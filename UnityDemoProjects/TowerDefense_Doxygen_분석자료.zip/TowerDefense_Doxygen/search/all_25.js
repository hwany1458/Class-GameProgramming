var searchData=
[
  ['데미지_20주고받기_0',['B1. AGF — 데미지 주고받기',['../group__agf__health.html',1,'']]],
  ['데이터와_20로직의_20분리_1',['데이터와 로직의 분리',['../index.html#sec_data',1,'']]]
];
