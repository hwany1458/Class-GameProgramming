var searchData=
[
  ['name_0',['name',['../classCore_1_1Game_1_1LevelItem.html#a37b5e96147f092fda91d9c9f6847c99b',1,'Core::Game::LevelItem']]],
  ['nearestzoom_1',['nearestZoom',['../classCore_1_1Camera_1_1CameraRig.html#a18e26587a542f0d8009b5480ec7d645e',1,'Core::Camera::CameraRig']]],
  ['nearzoompanspeedmodifier_2',['nearZoomPanSpeedModifier',['../classCore_1_1Input_1_1CameraInputScheme.html#af76a762be23f5b34cd1fa29ab5cad64b',1,'Core::Input::CameraInputScheme']]],
  ['newhealth_3',['newHealth',['../structCore_1_1Health_1_1HealthChangeInfo.html#a9b8a5d92c7ef57c592c731c86c57166d',1,'Core::Health::HealthChangeInfo']]],
  ['nextlevelbutton_4',['nextLevelButton',['../classTowerDefense_1_1UI_1_1EndGameScreen.html#a6170b1bec0b6f09e6a23bcf7c349c803',1,'TowerDefense::UI::EndGameScreen']]],
  ['numberofstars_5',['numberOfStars',['../classTowerDefense_1_1Game_1_1LevelSaveData.html#ad34d090c7cdd9be396ad652b3604d8e5',1,'TowerDefense::Game::LevelSaveData']]]
];
