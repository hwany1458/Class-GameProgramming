var searchData=
[
  ['instance_0',['instance',['../classCore_1_1Utilities_1_1Singleton.html#a3dab719f55409dd41e575a823d548c07',1,'Core::Utilities::Singleton']]],
  ['instanceexists_1',['instanceExists',['../classCore_1_1Utilities_1_1Singleton.html#a68a8d6726cd86427a108df4e68cb21f2',1,'Core::Utilities::Singleton']]],
  ['isatdestination_2',['isAtDestination',['../classTowerDefense_1_1Agents_1_1Agent.html#a7449e4b18754df64c9249b460cca8964',1,'TowerDefense::Agents::Agent']]],
  ['isatmaxhealth_3',['isAtMaxHealth',['../classCore_1_1Health_1_1Damageable.html#a6c064c84b6471715e93146967d1fbff9',1,'Core::Health::Damageable']]],
  ['isatmaxlevel_4',['isAtMaxLevel',['../classTowerDefense_1_1Towers_1_1Tower.html#aa3fcd6e4eecfb7447b872ac3a0ca03a0',1,'TowerDefense::Towers::Tower']]],
  ['isbuilding_5',['isBuilding',['../classTowerDefense_1_1UI_1_1HUD_1_1GameUI.html#a6560e521d62b8c205c2e1e20af223e32',1,'TowerDefense::UI::HUD::GameUI']]],
  ['isdead_6',['isdead',['../classCore_1_1Health_1_1Damageable.html#a2b65e4261686484f0cd5a2e8c29fac8a',1,'Core.Health.Damageable.isDead'],['../classCore_1_1Health_1_1DamageableBehaviour.html#a642f4c56c806cf9a2999044a0e1c714f',1,'Core.Health.DamageableBehaviour.isDead']]],
  ['isdefault_7',['isdefault',['../classCore_1_1Input_1_1KeyboardMouseInput.html#a586cd37310a4b2a77e503e055d759e7a',1,'Core.Input.KeyboardMouseInput.isDefault'],['../classCore_1_1Input_1_1TouchInput.html#ac74aa4908068bb50ecfd9c4a37d47b72',1,'Core.Input.TouchInput.isDefault'],['../classCore_1_1Input_1_1InputScheme.html#aefe283848b44123bb191b692cb875b02',1,'Core.Input.InputScheme.isDefault']]],
  ['isgameover_8',['isGameOver',['../classTowerDefense_1_1Level_1_1LevelManager.html#a00e58611f8a67d2287771a2f0544b10d',1,'TowerDefense::Level::LevelManager']]],
  ['ispathblocked_9',['isPathBlocked',['../classTowerDefense_1_1Agents_1_1Agent.html#a4c4bb82c5e93616c4d4397637692742c',1,'TowerDefense::Agents::Agent']]],
  ['ispaused_10',['isPaused',['../classTowerDefense_1_1UI_1_1TowerDefenseInputSchemeSwitcher.html#a7a2a41ec9a39f6e3dfa5d0ed6201086a',1,'TowerDefense::UI::TowerDefenseInputSchemeSwitcher']]],
  ['isreadonly_11',['isreadonly',['../classCore_1_1Game_1_1LevelList.html#aeed7be77c55907bd9b72537e951f7304',1,'Core.Game.LevelList.IsReadOnly'],['../classTowerDefense_1_1Towers_1_1Data_1_1TowerLibrary.html#ac0567e278d03ec3c70cedc847dc74347',1,'TowerDefense.Towers.Data.TowerLibrary.IsReadOnly']]],
  ['issetup_12',['isSetUp',['../classActionGameFramework_1_1Audio_1_1HealthChangeSoundSelector.html#a548d65e1cc38132f0a2f5ca71f953e35',1,'ActionGameFramework::Audio::HealthChangeSoundSelector']]],
  ['istowerselected_13',['isTowerSelected',['../classTowerDefense_1_1UI_1_1HUD_1_1GameUI.html#a1572eab28e343e482b95645157ba36ad',1,'TowerDefense::UI::HUD::GameUI']]]
];
