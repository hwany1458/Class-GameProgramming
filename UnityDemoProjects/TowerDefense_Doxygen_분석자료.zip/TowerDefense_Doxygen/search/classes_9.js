var searchData=
[
  ['jsonsaver_0',['JsonSaver',['../classCore_1_1Data_1_1JsonSaver.html',1,'Core::Data']]],
  ['jsonsaver_3c_20tdatastore_20_3e_1',['JsonSaver&lt; TDataStore &gt;',['../classCore_1_1Data_1_1JsonSaver.html',1,'Core::Data']]]
];
