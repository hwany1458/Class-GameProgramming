var searchData=
[
  ['jsonsaver_0',['JsonSaver',['../classCore_1_1Data_1_1JsonSaver.html#aa053c19f5a7d0aed026d14332e73d7a0',1,'Core::Data::JsonSaver']]]
];
