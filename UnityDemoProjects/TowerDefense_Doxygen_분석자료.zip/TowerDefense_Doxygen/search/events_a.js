var searchData=
[
  ['numberofenemieschanged_0',['numberOfEnemiesChanged',['../classTowerDefense_1_1Level_1_1LevelManager.html#a60f72e1d9645ddab12231428bfc22dbf',1,'TowerDefense::Level::LevelManager']]]
];
