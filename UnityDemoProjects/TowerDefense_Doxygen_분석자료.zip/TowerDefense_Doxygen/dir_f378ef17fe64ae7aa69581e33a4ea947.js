var dir_f378ef17fe64ae7aa69581e33a4ea947 =
[
    [ "EncryptedJsonSaver.cs", "EncryptedJsonSaver_8cs.html", null ],
    [ "FileSaver.cs", "FileSaver_8cs.html", null ],
    [ "GameDataStoreBase.cs", "GameDataStoreBase_8cs.html", null ],
    [ "GameManagerBase.cs", "GameManagerBase_8cs.html", null ],
    [ "IDataSaver.cs", "IDataSaver_8cs.html", null ],
    [ "IDataStore.cs", "IDataStore_8cs.html", null ],
    [ "JsonSaver.cs", "JsonSaver_8cs.html", null ]
];