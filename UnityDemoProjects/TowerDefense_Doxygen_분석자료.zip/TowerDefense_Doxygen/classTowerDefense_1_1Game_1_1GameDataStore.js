var classTowerDefense_1_1Game_1_1GameDataStore =
[
    [ "PreSave", "classTowerDefense_1_1Game_1_1GameDataStore.html#a010a98dfe06df3cf6830441e553fd7d1", null ],
    [ "PostLoad", "classTowerDefense_1_1Game_1_1GameDataStore.html#a8a0900ef1655863dce8e1fd87782032c", null ],
    [ "CompleteLevel", "classTowerDefense_1_1Game_1_1GameDataStore.html#a3147a4a6f8ff0c887ac4ad702c039f0f", null ],
    [ "IsLevelCompleted", "classTowerDefense_1_1Game_1_1GameDataStore.html#a2f72168d1bd3f9d0541f78aeee155a00", null ],
    [ "GetNumberOfStarForLevel", "classTowerDefense_1_1Game_1_1GameDataStore.html#aee0d13fbba36b7912131da9719fc350e", null ],
    [ "completedLevels", "classTowerDefense_1_1Game_1_1GameDataStore.html#a40842d81d8eed9d10c4b67020cbcc28e", null ]
];