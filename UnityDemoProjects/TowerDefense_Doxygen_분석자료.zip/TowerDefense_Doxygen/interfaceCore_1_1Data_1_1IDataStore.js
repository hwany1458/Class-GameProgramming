var interfaceCore_1_1Data_1_1IDataStore =
[
    [ "PreSave", "interfaceCore_1_1Data_1_1IDataStore.html#a2dc01ef375f5846e162676f1f49ed4c8", null ],
    [ "PostLoad", "interfaceCore_1_1Data_1_1IDataStore.html#a1a5abe6bbc9f676a718cf1045d4c2e6a", null ]
];