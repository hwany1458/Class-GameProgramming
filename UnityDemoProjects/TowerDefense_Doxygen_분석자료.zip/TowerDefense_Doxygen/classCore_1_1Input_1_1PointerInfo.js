var classCore_1_1Input_1_1PointerInfo =
[
    [ "currentPosition", "classCore_1_1Input_1_1PointerInfo.html#a32d0c68a5c522b2de5124720a1f41729", null ],
    [ "previousPosition", "classCore_1_1Input_1_1PointerInfo.html#a2cd22c73292e2e27b83e341337f2fc73", null ],
    [ "delta", "classCore_1_1Input_1_1PointerInfo.html#a464ba3e8c2e7e12db15279c27d8031ad", null ],
    [ "startedOverUI", "classCore_1_1Input_1_1PointerInfo.html#af37c11f82720782852f447204bed1ec2", null ]
];