var PlacementTile_8cs =
[
    [ "PlacementTileState", "PlacementTile_8cs.html#ace642889a1e288f80b7aca5143a9594f", [
      [ "Filled", "PlacementTile_8cs.html#ace642889a1e288f80b7aca5143a9594fad9d586f8c792f8f661052af42536323c", null ],
      [ "Empty", "PlacementTile_8cs.html#ace642889a1e288f80b7aca5143a9594face2c8aed9c2fa0cfbed56cbda4d8bf07", null ]
    ] ]
];