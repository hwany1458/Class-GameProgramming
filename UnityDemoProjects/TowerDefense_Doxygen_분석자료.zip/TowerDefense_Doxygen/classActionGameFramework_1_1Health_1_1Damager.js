var classActionGameFramework_1_1Health_1_1Damager =
[
    [ "SetDamage", "classActionGameFramework_1_1Health_1_1Damager.html#a407afc1532a71b83cac81616a9961e48", null ],
    [ "HasDamaged", "classActionGameFramework_1_1Health_1_1Damager.html#afa2acc89f54118c88c28cc932cd5d181", null ],
    [ "OnCollisionEnter", "classActionGameFramework_1_1Health_1_1Damager.html#ac7d5af0be243cf729fb546e6c136010a", null ],
    [ "damage", "classActionGameFramework_1_1Health_1_1Damager.html#a2e72c181b1b1c9c82cf1b16d33ac2163", null ],
    [ "hasDamaged", "classActionGameFramework_1_1Health_1_1Damager.html#aca4f8110d8e1a14ce66a4b63df04b239", null ],
    [ "chanceToSpawnCollisionPrefab", "classActionGameFramework_1_1Health_1_1Damager.html#a70937e9c6294c4b667aa5ee4b2c1bc6f", null ],
    [ "collisionParticles", "classActionGameFramework_1_1Health_1_1Damager.html#a1fd3c4352453f8ff8377447e09e26a87", null ],
    [ "alignment", "classActionGameFramework_1_1Health_1_1Damager.html#a7917358453f942a6e519994fcfef7674", null ],
    [ "alignmentProvider", "classActionGameFramework_1_1Health_1_1Damager.html#aa1f4156fca23dc9761bb62cb1f5c5b8e", null ]
];