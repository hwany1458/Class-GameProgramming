var namespaceCore =
[
    [ "Camera", "namespaceCore_1_1Camera.html", "namespaceCore_1_1Camera" ],
    [ "Data", "namespaceCore_1_1Data.html", "namespaceCore_1_1Data" ],
    [ "Economy", "namespaceCore_1_1Economy.html", "namespaceCore_1_1Economy" ],
    [ "Extensions", "namespaceCore_1_1Extensions.html", "namespaceCore_1_1Extensions" ],
    [ "Game", "namespaceCore_1_1Game.html", "namespaceCore_1_1Game" ],
    [ "Health", "namespaceCore_1_1Health.html", "namespaceCore_1_1Health" ],
    [ "Input", "namespaceCore_1_1Input.html", "namespaceCore_1_1Input" ],
    [ "UI", "namespaceCore_1_1UI.html", "namespaceCore_1_1UI" ],
    [ "Utilities", "namespaceCore_1_1Utilities.html", "namespaceCore_1_1Utilities" ]
];