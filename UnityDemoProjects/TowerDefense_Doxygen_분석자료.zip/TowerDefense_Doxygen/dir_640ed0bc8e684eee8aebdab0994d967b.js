var dir_640ed0bc8e684eee8aebdab0994d967b =
[
    [ "CameraInputScheme.cs", "CameraInputScheme_8cs.html", null ],
    [ "InputController.cs", "InputController_8cs.html", "InputController_8cs" ],
    [ "InputScheme.cs", "InputScheme_8cs.html", null ],
    [ "InputSchemeSwitcher.cs", "InputSchemeSwitcher_8cs.html", null ],
    [ "KeyboardMouseInput.cs", "KeyboardMouseInput_8cs.html", "KeyboardMouseInput_8cs" ],
    [ "MouseButtonInfo.cs", "MouseButtonInfo_8cs.html", null ],
    [ "MouseCursorInfo.cs", "MouseCursorInfo_8cs.html", null ],
    [ "PinchInfo.cs", "PinchInfo_8cs.html", null ],
    [ "PointerActionInfo.cs", "PointerActionInfo_8cs.html", null ],
    [ "PointerInfo.cs", "PointerInfo_8cs.html", null ],
    [ "TouchInfo.cs", "TouchInfo_8cs.html", null ],
    [ "TouchInput.cs", "TouchInput_8cs.html", "TouchInput_8cs" ],
    [ "WheelInfo.cs", "WheelInfo_8cs.html", null ]
];