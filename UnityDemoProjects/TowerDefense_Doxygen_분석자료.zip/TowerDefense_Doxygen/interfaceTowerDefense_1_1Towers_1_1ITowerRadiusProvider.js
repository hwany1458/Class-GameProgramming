var interfaceTowerDefense_1_1Towers_1_1ITowerRadiusProvider =
[
    [ "effectRadius", "interfaceTowerDefense_1_1Towers_1_1ITowerRadiusProvider.html#a0ac17943ab14fed274de356b8972b037", null ],
    [ "effectColor", "interfaceTowerDefense_1_1Towers_1_1ITowerRadiusProvider.html#aa15e7d73e7af0b3fd9ed70520f21e84e", null ],
    [ "targetter", "interfaceTowerDefense_1_1Towers_1_1ITowerRadiusProvider.html#aa9bcc0579b22a7919660ee99f86685ab", null ]
];