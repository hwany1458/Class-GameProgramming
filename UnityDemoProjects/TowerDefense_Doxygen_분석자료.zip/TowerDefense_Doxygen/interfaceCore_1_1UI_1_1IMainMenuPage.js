var interfaceCore_1_1UI_1_1IMainMenuPage =
[
    [ "Hide", "interfaceCore_1_1UI_1_1IMainMenuPage.html#a29e3122fe883086fef8a7a0e1738a557", null ],
    [ "Show", "interfaceCore_1_1UI_1_1IMainMenuPage.html#ad4b62235d6338c9725931b59fd356db6", null ]
];