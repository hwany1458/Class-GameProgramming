var dir_1f8149b104fad1b417ac615e87b88986 =
[
    [ "PoolableEffect.cs", "PoolableEffect_8cs.html", null ]
];