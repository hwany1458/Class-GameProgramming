var classCore_1_1Input_1_1TouchInfo =
[
    [ "touchId", "classCore_1_1Input_1_1TouchInfo.html#a785750bfc5bab52b67b4dcd5a2cb4194", null ]
];