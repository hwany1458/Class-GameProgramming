var dir_d4a9135fa15415058190f4e09facc164 =
[
    [ "WaveEditor.cs", "WaveEditor_8cs.html", null ]
];