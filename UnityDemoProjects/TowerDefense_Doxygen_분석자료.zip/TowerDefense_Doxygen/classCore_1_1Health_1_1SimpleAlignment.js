var classCore_1_1Health_1_1SimpleAlignment =
[
    [ "CanHarm", "classCore_1_1Health_1_1SimpleAlignment.html#a00bd8d30bbd502d0f0e99688e793b59c", null ],
    [ "opponents", "classCore_1_1Health_1_1SimpleAlignment.html#a1cb075592e13256f9ca13bc40b5cfbcd", null ]
];