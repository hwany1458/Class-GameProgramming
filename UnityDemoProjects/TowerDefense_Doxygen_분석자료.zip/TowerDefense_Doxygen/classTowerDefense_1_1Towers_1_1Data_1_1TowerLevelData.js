var classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData =
[
    [ "description", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#a028d30d18ba0322faeb0c0e72e346384", null ],
    [ "upgradeDescription", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#ad93d83744e319313739878ca3e268f19", null ],
    [ "cost", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#a681f9f599f196afee60c138373d90f58", null ],
    [ "sell", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#af050dc34c6e147b5a3c438b6bb981099", null ],
    [ "maxHealth", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#a63303334c1808df33973a2a727d29e05", null ],
    [ "startingHealth", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#a3fcb80f6bcb6beee84959dd27e7c2da1", null ],
    [ "icon", "classTowerDefense_1_1Towers_1_1Data_1_1TowerLevelData.html#a7374a639e34a05bf188be8870cdffe50", null ]
];