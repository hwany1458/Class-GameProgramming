var group__core__input =
[
    [ "Core.Input.CameraInputScheme", "classCore_1_1Input_1_1CameraInputScheme.html", [
      [ "GetPanSpeedForZoomLevel", "classCore_1_1Input_1_1CameraInputScheme.html#ab9ed119a1c96c4a21149a6a8e44ed64b", null ],
      [ "PanWithScreenCoordinates", "classCore_1_1Input_1_1CameraInputScheme.html#a7a1a4220452a64d2d587f1493d21d110", null ],
      [ "cameraRig", "classCore_1_1Input_1_1CameraInputScheme.html#aa1ca4b49d03e8cbf5f758fb5c13defd1", null ],
      [ "nearZoomPanSpeedModifier", "classCore_1_1Input_1_1CameraInputScheme.html#af76a762be23f5b34cd1fa29ab5cad64b", null ]
    ] ],
    [ "Core.Input.InputController", "classCore_1_1Input_1_1InputController.html", [
      [ "Awake", "classCore_1_1Input_1_1InputController.html#aa6036e08ae98cdb2d4764e8e63bd86da", null ],
      [ "Update", "classCore_1_1Input_1_1InputController.html#a639e8cab468d0dec921ee7f9b9143aa7", null ],
      [ "UpdateMouse", "classCore_1_1Input_1_1InputController.html#aa4abf2eaff59ec35306d50585e9ce05c", null ],
      [ "UpdateTouches", "classCore_1_1Input_1_1InputController.html#a74ba84c0aca697d81e15721948ebd9b3", null ],
      [ "UpdateHoldingFinger", "classCore_1_1Input_1_1InputController.html#a8404b41d0d9f145858ee08da70f1ef38", null ],
      [ "k_FlickAccumulationFactor", "classCore_1_1Input_1_1InputController.html#a70358ba8b9e175ffe451a8e04d713e59", null ],
      [ "dragThresholdTouch", "classCore_1_1Input_1_1InputController.html#a5912ddace8a2116e69aa759161c49b9f", null ],
      [ "dragThresholdMouse", "classCore_1_1Input_1_1InputController.html#a71acd9b97263d028e88bd47c5fab650e", null ],
      [ "tapTime", "classCore_1_1Input_1_1InputController.html#a745769fdd128e8ffe066144ed1de8b50", null ],
      [ "holdTime", "classCore_1_1Input_1_1InputController.html#a2419a3735f3d02807e316199f130f07a", null ],
      [ "mouseWheelSensitivity", "classCore_1_1Input_1_1InputController.html#afb9e3efec2fe2b72ab853f151c1c6994", null ],
      [ "trackMouseButtons", "classCore_1_1Input_1_1InputController.html#a62de9f5d8ce68eb54c18d59914c85500", null ],
      [ "flickThreshold", "classCore_1_1Input_1_1InputController.html#a463dca51fa1da40e422b4ceac171b6fb", null ],
      [ "m_Touches", "classCore_1_1Input_1_1InputController.html#a9394c7209cc3d6b0d5af006812196a2f", null ],
      [ "m_MouseInfo", "classCore_1_1Input_1_1InputController.html#a979f34f5caadf4a55c5d5a17b001eaa0", null ],
      [ "activeTouchCount", "classCore_1_1Input_1_1InputController.html#a8810e558a2676028054350ed2954c07e", null ],
      [ "mouseButtonPressedThisFrame", "classCore_1_1Input_1_1InputController.html#a5d08bf8750335d6693899fc26fee008c", null ],
      [ "mouseMovedOnThisFrame", "classCore_1_1Input_1_1InputController.html#a90892a9b2d416a62e671686730da5a3a", null ],
      [ "touchPressedThisFrame", "classCore_1_1Input_1_1InputController.html#a76803997dea8875bc6c6b6f44daffed1", null ],
      [ "basicMouseInfo", "classCore_1_1Input_1_1InputController.html#a78d85b72b640b55afda7a66cc202044e", null ],
      [ "pressed", "classCore_1_1Input_1_1InputController.html#af7d97354254067d85228a1d39973c04a", null ],
      [ "released", "classCore_1_1Input_1_1InputController.html#a3c2c9654ec98e1f56ec84a280049076d", null ],
      [ "tapped", "classCore_1_1Input_1_1InputController.html#a825705ac3d278e034f1e39d343a28d64", null ],
      [ "startedDrag", "classCore_1_1Input_1_1InputController.html#a34088ae5ea8f239d4e675cac410991cd", null ],
      [ "dragged", "classCore_1_1Input_1_1InputController.html#a5c9b23d7cc91e280955e2d70cba93e88", null ],
      [ "startedHold", "classCore_1_1Input_1_1InputController.html#acd194337c88a741755b956e8eb0c8612", null ],
      [ "spunWheel", "classCore_1_1Input_1_1InputController.html#a65d9446ea6bbd7c2dee95bced7a3edf5", null ],
      [ "pinched", "classCore_1_1Input_1_1InputController.html#a135000e1eb9419ee49f6cc491391c675", null ],
      [ "mouseMoved", "classCore_1_1Input_1_1InputController.html#a9b0bb719d69394e3fe87638f591f550c", null ]
    ] ],
    [ "Core.Input.InputScheme", "classCore_1_1Input_1_1InputScheme.html", [
      [ "Activate", "classCore_1_1Input_1_1InputScheme.html#af4eb92e133bb408b6c7c4fa296f38f78", null ],
      [ "Deactivate", "classCore_1_1Input_1_1InputScheme.html#a12729c6abd45e1ecb55713f432b203cf", null ],
      [ "shouldActivate", "classCore_1_1Input_1_1InputScheme.html#a4aaa7bcc9ca61862df67643785f279cb", null ],
      [ "isDefault", "classCore_1_1Input_1_1InputScheme.html#aefe283848b44123bb191b692cb875b02", null ]
    ] ],
    [ "Core.Input.InputSchemeSwitcher", "classCore_1_1Input_1_1InputSchemeSwitcher.html", [
      [ "Awake", "classCore_1_1Input_1_1InputSchemeSwitcher.html#a4318b3a846f66218bbefcc9b2a6c588c", null ],
      [ "Update", "classCore_1_1Input_1_1InputSchemeSwitcher.html#a0495a2c1f324278d8361deb66862a3fc", null ],
      [ "m_InputSchemes", "classCore_1_1Input_1_1InputSchemeSwitcher.html#ae6681fe7854af41beaadbdd65e24b8b5", null ],
      [ "m_DefaultScheme", "classCore_1_1Input_1_1InputSchemeSwitcher.html#a4f7ca76fd17848d8f183d3dfe19a0b63", null ],
      [ "m_CurrentScheme", "classCore_1_1Input_1_1InputSchemeSwitcher.html#a5347ad57fba5409db2e4562e2d7433e4", null ]
    ] ],
    [ "Core.Input.KeyboardMouseInput", "classCore_1_1Input_1_1KeyboardMouseInput.html", [
      [ "OnEnable", "classCore_1_1Input_1_1KeyboardMouseInput.html#a0e6447ab5cfd5dd4f7798c062f7e7996", null ],
      [ "OnDisable", "classCore_1_1Input_1_1KeyboardMouseInput.html#a44258953d9626df6c6eabb7786b3505e", null ],
      [ "Update", "classCore_1_1Input_1_1KeyboardMouseInput.html#a4b1a2f5400c47c2445da1036c921cb25", null ],
      [ "OnDrag", "classCore_1_1Input_1_1KeyboardMouseInput.html#a33d4a6d1ecdc4c50ba102005c1fe4be7", null ],
      [ "OnWheel", "classCore_1_1Input_1_1KeyboardMouseInput.html#afa5a1fc88db887ac4f5c3867db53fe25", null ],
      [ "OnPress", "classCore_1_1Input_1_1KeyboardMouseInput.html#ab6bf22cd881d717dba25bb0ed963738a", null ],
      [ "DoScreenEdgePan", "classCore_1_1Input_1_1KeyboardMouseInput.html#a5ce16bef8a5609e1ea046ea267bfe01c", null ],
      [ "DoKeyboardPan", "classCore_1_1Input_1_1KeyboardMouseInput.html#add60f43cb435788cedd0017b7504d268", null ],
      [ "DecayZoom", "classCore_1_1Input_1_1KeyboardMouseInput.html#acf817fc1a4eb9c2d0542789f47591055", null ],
      [ "DoRightMouseDragPan", "classCore_1_1Input_1_1KeyboardMouseInput.html#a920488388bdb8ab059153b0f842c4a02", null ],
      [ "DoWheelZoom", "classCore_1_1Input_1_1KeyboardMouseInput.html#af13ef043bc80a378c30cfbf5db40a62b", null ],
      [ "DoMiddleMousePan", "classCore_1_1Input_1_1KeyboardMouseInput.html#a86e55ef5f01cffc7e2a1cca69c0dbf97", null ],
      [ "screenPanThreshold", "classCore_1_1Input_1_1KeyboardMouseInput.html#a92295da568aea144925fd6d3e2999fc9", null ],
      [ "mouseEdgePanSpeed", "classCore_1_1Input_1_1KeyboardMouseInput.html#a5656b452dfb9b0dc336e9f4efa995605", null ],
      [ "mouseRmbPanSpeed", "classCore_1_1Input_1_1KeyboardMouseInput.html#ae48791bcc5bf140d591558c2e1d056fd", null ],
      [ "shouldActivate", "classCore_1_1Input_1_1KeyboardMouseInput.html#aedb7f075e19cca682ae5d072fd1d96d1", null ],
      [ "isDefault", "classCore_1_1Input_1_1KeyboardMouseInput.html#a586cd37310a4b2a77e503e055d759e7a", null ]
    ] ],
    [ "Core.Input.MouseButtonInfo", "classCore_1_1Input_1_1MouseButtonInfo.html", [
      [ "isDown", "classCore_1_1Input_1_1MouseButtonInfo.html#a08f000b1165ff7d9ee791c84dd0cb7ed", null ],
      [ "mouseButtonId", "classCore_1_1Input_1_1MouseButtonInfo.html#ae6948231e3d245fb5166ac76f04a7daf", null ]
    ] ],
    [ "Core.Input.MouseCursorInfo", "classCore_1_1Input_1_1MouseCursorInfo.html", null ],
    [ "Core.Input.PinchInfo", "structCore_1_1Input_1_1PinchInfo.html", [
      [ "touch1", "structCore_1_1Input_1_1PinchInfo.html#a23f607dd3c838a89d48065b28f152886", null ],
      [ "touch2", "structCore_1_1Input_1_1PinchInfo.html#ab604db0d8d16b58e3f0686d2b16f8f85", null ]
    ] ],
    [ "Core.Input.PointerActionInfo", "classCore_1_1Input_1_1PointerActionInfo.html", [
      [ "startPosition", "classCore_1_1Input_1_1PointerActionInfo.html#abc0af507a221a95ef5a4e9265ad88223", null ],
      [ "flickVelocity", "classCore_1_1Input_1_1PointerActionInfo.html#a55e94848c3e8a6ce62c95b9e77307983", null ],
      [ "totalMovement", "classCore_1_1Input_1_1PointerActionInfo.html#aaa0355268cc70d64c7037d4b214d7af4", null ],
      [ "startTime", "classCore_1_1Input_1_1PointerActionInfo.html#ae5b792b8c914ed128a3620d3b6a91acf", null ],
      [ "isDrag", "classCore_1_1Input_1_1PointerActionInfo.html#a5eda5d371ba834f97e2e7b3cee67c79d", null ],
      [ "isHold", "classCore_1_1Input_1_1PointerActionInfo.html#ad76d394ca744a330949d88354f5b43e4", null ],
      [ "wasHold", "classCore_1_1Input_1_1PointerActionInfo.html#ade844376248a93a7c05dd26d4b6f314e", null ]
    ] ],
    [ "Core.Input.PointerInfo", "classCore_1_1Input_1_1PointerInfo.html", [
      [ "currentPosition", "classCore_1_1Input_1_1PointerInfo.html#a32d0c68a5c522b2de5124720a1f41729", null ],
      [ "previousPosition", "classCore_1_1Input_1_1PointerInfo.html#a2cd22c73292e2e27b83e341337f2fc73", null ],
      [ "delta", "classCore_1_1Input_1_1PointerInfo.html#a464ba3e8c2e7e12db15279c27d8031ad", null ],
      [ "startedOverUI", "classCore_1_1Input_1_1PointerInfo.html#af37c11f82720782852f447204bed1ec2", null ]
    ] ],
    [ "Core.Input.TouchInfo", "classCore_1_1Input_1_1TouchInfo.html", [
      [ "touchId", "classCore_1_1Input_1_1TouchInfo.html#a785750bfc5bab52b67b4dcd5a2cb4194", null ]
    ] ],
    [ "Core.Input.TouchInput", "classCore_1_1Input_1_1TouchInput.html", [
      [ "OnEnable", "classCore_1_1Input_1_1TouchInput.html#a10cacac32fd2f828a8eec34489d874eb", null ],
      [ "OnDisable", "classCore_1_1Input_1_1TouchInput.html#afde0a4cb1d2c1b1afd1377b98c6e85da", null ],
      [ "Update", "classCore_1_1Input_1_1TouchInput.html#a614b5f9092d1c82db6bfb6cdbf4a1d7d", null ],
      [ "OnPress", "classCore_1_1Input_1_1TouchInput.html#ac96a2ab291807bf917581c09bdea11f9", null ],
      [ "OnRelease", "classCore_1_1Input_1_1TouchInput.html#ac6d5f60d474d8502428b607bff10ec73", null ],
      [ "OnDrag", "classCore_1_1Input_1_1TouchInput.html#a2a292175af9c9c7e56ae7b25eeab2834", null ],
      [ "OnPinch", "classCore_1_1Input_1_1TouchInput.html#a9c339b26d4240c30abc29c86f9afb1f9", null ],
      [ "UpdateFlick", "classCore_1_1Input_1_1TouchInput.html#aea92eb79846254ba4f52b30e3141c396", null ],
      [ "DecayZoom", "classCore_1_1Input_1_1TouchInput.html#a050aa0b3efa47bb34fbd615da7b581d3", null ],
      [ "DoFlickCatch", "classCore_1_1Input_1_1TouchInput.html#a5b69fa8213fa3c8ce85a688d4d47b7a7", null ],
      [ "DoReleaseFlick", "classCore_1_1Input_1_1TouchInput.html#ab8f3fcd2c6d25b19e5ba69a75cb19eac", null ],
      [ "DoDragPan", "classCore_1_1Input_1_1TouchInput.html#a392616da6c41d5e1f147a300fe33e95c", null ],
      [ "DoPinchZoom", "classCore_1_1Input_1_1TouchInput.html#a5aa6cc2c3bb3326a13190bfb87792c50", null ],
      [ "PanCamera", "classCore_1_1Input_1_1TouchInput.html#aa359ba588219950de7f1d544f4e0b884", null ],
      [ "panSpeed", "classCore_1_1Input_1_1TouchInput.html#aa3a7907463d0b1f6461aaafa6db29135", null ],
      [ "flickDecayFactor", "classCore_1_1Input_1_1TouchInput.html#af81fff4b12a4f41564b40bbea33e81a0", null ],
      [ "m_FlickDirection", "classCore_1_1Input_1_1TouchInput.html#a3b6bc00f69f165ffced7661d8f43f40d", null ],
      [ "shouldActivate", "classCore_1_1Input_1_1TouchInput.html#a45de528c8e8a16548027a9d4912df159", null ],
      [ "isDefault", "classCore_1_1Input_1_1TouchInput.html#ac74aa4908068bb50ecfd9c4a37d47b72", null ]
    ] ],
    [ "Core.Input.WheelInfo", "structCore_1_1Input_1_1WheelInfo.html", [
      [ "zoomAmount", "structCore_1_1Input_1_1WheelInfo.html#af30728cec6e2fbc4fee713641e1d82a3", null ]
    ] ],
    [ "TowerDefense.Input.TowerDefenseKeyboardMouseInput", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html", [
      [ "OnEnable", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a3506945e720519ad8146f0520e4ba9bc", null ],
      [ "OnDisable", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a651177c5b101635b8ab78e159cb60a01", null ],
      [ "Update", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#ae8e2639694a74d1f94633de14c962419", null ],
      [ "TrySetBuildMode", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a7012c201107d89b8b88ae61e8ddb648f", null ],
      [ "OnMouseMoved", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a2d3c5e6bf8dc8d360c074b911d4fa1c0", null ],
      [ "OnTap", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a96753b2adcf94269b0960ce6355cc947", null ],
      [ "m_GameUI", "classTowerDefense_1_1Input_1_1TowerDefenseKeyboardMouseInput.html#a7fef6aa6e377df24fd96040db7e58228", null ]
    ] ],
    [ "TowerDefense.Input.TowerDefenseTouchInput", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html", [
      [ "OnTowerPlacementConfirmation", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a20ab2f17bbbee844b438cbbf842bca85", null ],
      [ "Cancel", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a116fd62bbb830aad14e2381d638d290f", null ],
      [ "OnEnable", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#ab271ea4932adc814a71cbcdb6496d721", null ],
      [ "OnDisable", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a25d9059eb458f2ac634abfeef5cc4093", null ],
      [ "Awake", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a06dc738a21fdf4d508e3305eb9ac1025", null ],
      [ "Update", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a7a65803b298c2318910402b260be823a", null ],
      [ "OnPress", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a8438391cb5f0d4988a5566ec8250beaa", null ],
      [ "OnRelease", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#aa6f2b95c5a98fef2521600de0e03ca9a", null ],
      [ "OnTap", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a0dc67b1711f0d73439f793020e4d72b1", null ],
      [ "OnStartDrag", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a8677160d311408f549d65795cea9a532", null ],
      [ "OnDrag", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a75d08992e613be5be7148527f33b5d7b", null ],
      [ "DragGhost", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a387c238cb5bec93856f79471132143b4", null ],
      [ "EdgePan", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a62713d0be63556561b8230113ff657da", null ],
      [ "OnStateChanged", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a1be9b73bea51ba0627b97827d3033348", null ],
      [ "OnGhostBecameValid", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a6fc574ccf1ec2b11bd2d7a1cd148313d", null ],
      [ "panAreaScreenPercentage", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a310bb37671a9ff85118ace4384be10a9", null ],
      [ "confirmationButtons", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#ac7cfb071c68c76767987369540e78a01", null ],
      [ "invalidButtons", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#aae67a4e99bc4ba7dd0dad934984194b8", null ],
      [ "m_GameUI", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#ad97d53bd757bb848513e465b6dbb31a0", null ],
      [ "m_IsGhostSelected", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#a036d09e566fb67136f4b61cba43a1e9d", null ],
      [ "m_DragPointer", "classTowerDefense_1_1Input_1_1TowerDefenseTouchInput.html#aca5f32c738b75e72ce54c413d7e0c28f", null ]
    ] ]
];