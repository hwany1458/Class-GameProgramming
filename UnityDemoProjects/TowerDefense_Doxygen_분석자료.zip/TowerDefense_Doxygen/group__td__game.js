var group__td__game =
[
    [ "TowerDefense.Game.GameDataStore", "classTowerDefense_1_1Game_1_1GameDataStore.html", [
      [ "PreSave", "classTowerDefense_1_1Game_1_1GameDataStore.html#a010a98dfe06df3cf6830441e553fd7d1", null ],
      [ "PostLoad", "classTowerDefense_1_1Game_1_1GameDataStore.html#a8a0900ef1655863dce8e1fd87782032c", null ],
      [ "CompleteLevel", "classTowerDefense_1_1Game_1_1GameDataStore.html#a3147a4a6f8ff0c887ac4ad702c039f0f", null ],
      [ "IsLevelCompleted", "classTowerDefense_1_1Game_1_1GameDataStore.html#a2f72168d1bd3f9d0541f78aeee155a00", null ],
      [ "GetNumberOfStarForLevel", "classTowerDefense_1_1Game_1_1GameDataStore.html#aee0d13fbba36b7912131da9719fc350e", null ],
      [ "completedLevels", "classTowerDefense_1_1Game_1_1GameDataStore.html#a40842d81d8eed9d10c4b67020cbcc28e", null ]
    ] ],
    [ "TowerDefense.Game.GameManager", "classTowerDefense_1_1Game_1_1GameManager.html", [
      [ "Awake", "classTowerDefense_1_1Game_1_1GameManager.html#ae83ae2acec1a63d91933bd96ccdb8095", null ],
      [ "CompleteLevel", "classTowerDefense_1_1Game_1_1GameManager.html#a59e14c294d3ac9bc955640b1fdfb8cac", null ],
      [ "GetLevelForCurrentScene", "classTowerDefense_1_1Game_1_1GameManager.html#aaecb95e43900894e6f2521c5817e65c9", null ],
      [ "IsLevelCompleted", "classTowerDefense_1_1Game_1_1GameManager.html#a2309c6203920004822d9574449e3d45b", null ],
      [ "GetStarsForLevel", "classTowerDefense_1_1Game_1_1GameManager.html#a3bdea2e22963e14d5894e91f5fbbb276", null ],
      [ "levelList", "classTowerDefense_1_1Game_1_1GameManager.html#a9aa6c1d6ef568558e008a15e4cb62664", null ]
    ] ],
    [ "TowerDefense.Game.LevelSaveData", "classTowerDefense_1_1Game_1_1LevelSaveData.html", [
      [ "LevelSaveData", "classTowerDefense_1_1Game_1_1LevelSaveData.html#a9441d54aa8f8405d189417ffc4390e7a", null ],
      [ "id", "classTowerDefense_1_1Game_1_1LevelSaveData.html#a9e0a658bb83f5bbacd5bbf13ffc2333f", null ],
      [ "numberOfStars", "classTowerDefense_1_1Game_1_1LevelSaveData.html#ad34d090c7cdd9be396ad652b3604d8e5", null ]
    ] ]
];