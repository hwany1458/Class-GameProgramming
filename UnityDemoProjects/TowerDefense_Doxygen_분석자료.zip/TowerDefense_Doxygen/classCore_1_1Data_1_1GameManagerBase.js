var classCore_1_1Data_1_1GameManagerBase =
[
    [ "GetVolumes", "classCore_1_1Data_1_1GameManagerBase.html#aa10b26a215ea21ba7c5c7271290d13cd", null ],
    [ "SetVolumes", "classCore_1_1Data_1_1GameManagerBase.html#ac4f9b784d64f2e070227cc2437910df9", null ],
    [ "Awake", "classCore_1_1Data_1_1GameManagerBase.html#a95fd4417df40f0be548f86e9c36d879e", null ],
    [ "Start", "classCore_1_1Data_1_1GameManagerBase.html#a2627d4f60deaf2d33883850d46de65b9", null ],
    [ "LoadData", "classCore_1_1Data_1_1GameManagerBase.html#a4a5309a58f9fb8bf998ddfc4a480373c", null ],
    [ "SaveData", "classCore_1_1Data_1_1GameManagerBase.html#a4d41502dd3f0a369e4c50590dfefb56f", null ],
    [ "LogarithmicDbTransform", "classCore_1_1Data_1_1GameManagerBase.html#ad4d21c01dd901a57d01be170df706cec", null ],
    [ "k_SavedGameFile", "classCore_1_1Data_1_1GameManagerBase.html#a379ec6472cbe5ff65d9388b1944ae984", null ],
    [ "gameMixer", "classCore_1_1Data_1_1GameManagerBase.html#a973337adde0675dfc264b27cdcff21cc", null ],
    [ "masterVolumeParameter", "classCore_1_1Data_1_1GameManagerBase.html#a7e0279dbb31dd7d70e58354e4e46a90c", null ],
    [ "sfxVolumeParameter", "classCore_1_1Data_1_1GameManagerBase.html#ab0c2e83a33bbd75adada7eaf9d145638", null ],
    [ "musicVolumeParameter", "classCore_1_1Data_1_1GameManagerBase.html#a691a78931ed0526ced44e17ff03e93d7", null ],
    [ "m_DataSaver", "classCore_1_1Data_1_1GameManagerBase.html#a1c92046cd58f0a06bce7282f200f7eb3", null ],
    [ "m_DataStore", "classCore_1_1Data_1_1GameManagerBase.html#a81cbbce542d1beabc59cb606625e9abb", null ]
];