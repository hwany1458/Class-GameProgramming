var classTowerDefense_1_1UI_1_1Rotator =
[
    [ "Update", "classTowerDefense_1_1UI_1_1Rotator.html#a3c94a190328eb5995b49a00fbae43fab", null ],
    [ "rotationSpeed", "classTowerDefense_1_1UI_1_1Rotator.html#a8fb6bb24af4b29dc2849aa272f89f54a", null ]
];