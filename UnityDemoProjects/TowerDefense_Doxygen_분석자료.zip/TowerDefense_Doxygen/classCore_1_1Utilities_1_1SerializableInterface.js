var classCore_1_1Utilities_1_1SerializableInterface =
[
    [ "GetInterface", "classCore_1_1Utilities_1_1SerializableInterface.html#a1798a710f8f6f694eeb5df3fe8d5c89a", null ],
    [ "unityObjectReference", "classCore_1_1Utilities_1_1SerializableInterface.html#a56c352c45f9e32ed5991a166ba91b6e4", null ],
    [ "m_InterfaceReference", "classCore_1_1Utilities_1_1SerializableInterface.html#a3ee57ec1b42b09b8aac8cec939ae92e2", null ]
];