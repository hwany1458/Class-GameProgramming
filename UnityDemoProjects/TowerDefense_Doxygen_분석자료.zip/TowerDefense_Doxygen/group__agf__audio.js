var group__agf__audio =
[
    [ "ActionGameFramework.Audio.HealthChangeAudioSource", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html", [
      [ "Awake", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#aa9d8047baac5ce17254251211dfb9184", null ],
      [ "PlaySound", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#afcffcdee7f7c599f09ece947844e4e44", null ],
      [ "PlayHealthChangeSound", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#a77477b1b912a5042cf418e4745368f36", null ],
      [ "Sort", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#af587dbaf6640109caff5dd5fedd721db", null ],
      [ "soundSelector", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#a09a24291cbd4443719ac299d90a0bdfe", null ],
      [ "m_Source", "classActionGameFramework_1_1Audio_1_1HealthChangeAudioSource.html#a5421235042c4e4f432379fbefbe4b892", null ]
    ] ],
    [ "ActionGameFramework.Audio.HealthChangeSoundComparer", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundComparer.html", [
      [ "Compare", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundComparer.html#a88fdc17f66b703f33cd8dba46ada981a", null ]
    ] ],
    [ "ActionGameFramework.Audio.HealthChangeSound", "classActionGameFramework_1_1Audio_1_1HealthChangeSound.html", [
      [ "healthChange", "classActionGameFramework_1_1Audio_1_1HealthChangeSound.html#ad0a9f3611bb54ef05cb2316dbd569410", null ],
      [ "sound", "classActionGameFramework_1_1Audio_1_1HealthChangeSound.html#a4ac9d54d75d23bce37395be71a9fb753", null ]
    ] ],
    [ "ActionGameFramework.Audio.HealthChangeSoundSelector", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundSelector.html", [
      [ "GetClipFromHealthChangeInfo", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundSelector.html#a5981edb43fb5b6d27105697e8370d7a3", null ],
      [ "healthChangeSounds", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundSelector.html#aadde9cdd7db77ec2f2d5930b0bce7f5b", null ],
      [ "isSetUp", "classActionGameFramework_1_1Audio_1_1HealthChangeSoundSelector.html#a548d65e1cc38132f0a2f5ca71f953e35", null ]
    ] ],
    [ "ActionGameFramework.Audio.RandomAudioSource", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html", [
      [ "OnEnable", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#a4216db1418bafee7c36df3d88b571870", null ],
      [ "PlayRandomClip", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#a26a53130ec910b79f1db94a888d92a61", null ],
      [ "PlayRandomClip", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#a4b086c77c0b926a4e9f245c6ae198ce1", null ],
      [ "clips", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#a3da91f1a66e7bd079181b509422beb18", null ],
      [ "playOnEnabled", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#ad0c341db64e548c0c8e0f1f7858a4c75", null ],
      [ "m_Source", "classActionGameFramework_1_1Audio_1_1RandomAudioSource.html#a7164a4708b0d12ae33b14d2940693e1a", null ]
    ] ],
    [ "ActionGameFramework.Audio.WeightedAudioClip", "classActionGameFramework_1_1Audio_1_1WeightedAudioClip.html", [
      [ "clip", "classActionGameFramework_1_1Audio_1_1WeightedAudioClip.html#aa0d4636f6fc7a3cc89acfcf3d42aa10a", null ],
      [ "weight", "classActionGameFramework_1_1Audio_1_1WeightedAudioClip.html#a2964831cc87597a34bd7fb63edc0c037", null ]
    ] ],
    [ "ActionGameFramework.Audio.WeightedAudioList", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html", [
      [ "WeightedSelection", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html#aa67ecd2785b81826d92eb3ecf1fccf82", null ],
      [ "CalculateWeightSum", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html#a1caf58a7139f960afc2d19b839f87ddb", null ],
      [ "weightedItems", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html#acc41ef6a5749f415ed25f70f60998a25", null ],
      [ "m_WeightSum", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html#a6abc7af8d74d422f30cfaf559f7b1322", null ],
      [ "weightSum", "classActionGameFramework_1_1Audio_1_1WeightedAudioList.html#a8d2b28e1a8f1b3d62ecc53d09198a3eb", null ]
    ] ]
];