var namespaceTowerDefense_1_1Towers_1_1Placement =
[
    [ "IPlacementArea", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea.html", "interfaceTowerDefense_1_1Towers_1_1Placement_1_1IPlacementArea" ],
    [ "PlacementAreaExtensions", "classTowerDefense_1_1Towers_1_1Placement_1_1PlacementAreaExtensions.html", "classTowerDefense_1_1Towers_1_1Placement_1_1PlacementAreaExtensions" ],
    [ "SingleTowerPlacementArea", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea.html", "classTowerDefense_1_1Towers_1_1Placement_1_1SingleTowerPlacementArea" ],
    [ "TowerPlacementGrid", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid.html", "classTowerDefense_1_1Towers_1_1Placement_1_1TowerPlacementGrid" ],
    [ "TowerFitStatus", "namespaceTowerDefense_1_1Towers_1_1Placement.html#a9a2c196cd17505eb013413ae822e3706", [
      [ "Fits", "namespaceTowerDefense_1_1Towers_1_1Placement.html#a9a2c196cd17505eb013413ae822e3706aa00f6d6b3c23f1db2f1509dfb2644a0d", null ],
      [ "Overlaps", "namespaceTowerDefense_1_1Towers_1_1Placement.html#a9a2c196cd17505eb013413ae822e3706a0f6cd0a96a11dbf73252729e2f8271d2", null ],
      [ "OutOfBounds", "namespaceTowerDefense_1_1Towers_1_1Placement.html#a9a2c196cd17505eb013413ae822e3706a46dc1018ac1d8fca7c2752a61ce2fd0f", null ]
    ] ]
];