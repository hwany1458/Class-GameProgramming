Gem Hunter Match 소스 분석 {#mainpage}
=========================

이 문서는 Unity 공식 2D URP 샘플 **Gem Hunter Match**(Asset Store 1.6, Unity 6000.3.10f1 기준)의
게임플레이 스크립트 30개(약 4,900줄)를 Doxygen으로 분석한 자료다. 「유니티 샘플 기반 게임 제작」 강의의
1단계(분석) 교재이며, 2단계(기능 도출)에서 확장 포인트를 찾는 근거로 쓴다.

분석 범위는 `Assets/GemHunterMatch/Scripts`(네임스페이스 `Match3`)다. ReadMe·Tutorial 에디터 스크립트,
셰이더 그래프(TileShader, Radial Warp), 아트·오디오 자산은 제외했다.

@section sec_overview 한눈에 보는 구조

코드의 1/3(1,565줄)이 HappyHarvest 의 TerrainManager 격인 **Board** 한 클래스에 들어 있다.
Board는 "매 프레임 돌아가는 상태 기계"이고, 나머지 클래스는 Board에 데이터를 넣거나(저작 타일·LevelData·GameSettings)
Board가 내는 결과를 받는다(LevelData 목표 카운트·UIHandler·GameManager 코인).

| 역할 | 클래스 | 수명 |
|---|---|---|
| 전역 상태(코인·별·목숨·보너스 아이템), 사운드, VFX 풀, 입력 액션 | Match3.GameManager | 영속 (DontDestroyOnLoad, Resources/GameManager) |
| 보드 상태 기계: 입력 → 스와프 → 매치 → 삭제 → 낙하 → 보충 → 힌트 | Match3.Board | 레벨 씬마다 |
| 레벨 규칙: 목표(GemGoal[])·최대 이동 수·배경·음악, 목표 달성/이동 소진 이벤트 | Match3.LevelData | 레벨 씬마다 |
| 셀 하나의 내용물(현재 젬·들어오는 젬·장애물·잠금) | Match3.BoardCell | Board.CellContent 사전 |
| 젬과 그 파생(보너스 젬·나무상자) | Match3.Gem → Match3.BonusGem, Match3.Crate | 셀마다 프리팹 인스턴스 |
| 레벨 저작용 타일(런타임에는 보이지 않음) | Match3.GemPlacerTile, Match3.GemSpawner, Match3.ObstaclePlacer | 씬의 Logic 타일맵 |
| 모든 튜닝 값 한 곳 | Match3.GameSettings (Visual/Bonus/Shop/Sound) | GameManager 프리팹의 필드 |
| HUD·목표 표시·상점·결과·디버그 메뉴 | Match3.UIHandler | 레벨 씬마다 |
| 레벨 목록과 로딩 | Match3.LevelList (ScriptableObject) | 에셋 (Data/LevelList.asset) |

씬 구성: `Init`(GameManager 생성 보장 → 씬 1 로드) → `Main`(레벨 선택, LevelList) → `Level1~3` (LevelTemplate.scenetemplate로 복제).

@section sec_board 보드 모양은 씬이다, 데이터가 아니다

레벨 씬의 **Logic 타일맵**에 칠한 저작용 타일이 `TileBase.StartUp()` 시점에 Board의 static 메서드를 호출해 셀을 등록한다.

- GemPlacerTile.StartUp → Board.RegisterCell(cell, 고정 젬 또는 null=무작위)
- GemSpawner.StartUp → Board.RegisterSpawner(cell) (위에서 새 젬이 떨어지는 열)
- ObstaclePlacer.StartUp → Board.AddObstacle(cell, obstacle) (밧줄 TieBlocker 등)

따라서 "새 레벨"은 코드가 아니라 **씬 복제 + 타일 칠하기 + LevelData 값 입력 + LevelList 등록**이다 → @ref manual_newlevel "새 레벨 만들기".
Board.Init()은 등록된 셀로 Bounds를 계산하고 초기 매치가 없도록 GenerateBoard()로 젬을 채운다. GameManager.ComputeCamera()가 Bounds에 맞춰 카메라를 잡는다.

@section sec_loop 핵심 루프 1회: 스와프가 끝나기까지

```
[매 프레임] Board.Update()
  ├─ PoolSystem.Update()                 VFX 풀 수명 관리
  ├─ IBoardAction.Tick()                 진행 중인 보너스 액션(로켓 등) — false 반환 시 제거
  ├─ CheckInput()                        클릭/드래그 → 인접 셀이면 스와프 예약 (m_SwipeQueued)
  ├─ TickSwap()      [SwapStage.Forward] 두 젬을 서로 자리로 이동 → 도착하면 DoCheck(양쪽)
  │                                       ├─ 매치 있음 → Match 생성, LevelData.Moved() (이동 수 -1)
  │                                       └─ 매치 없음 → SwapStage.Return 으로 되돌림
  ├─ MoveGems()      [m_TickingCells]     낙하 중인 젬 이동(FallSpeed·가속 곡선), 도착 셀을 매치 검사 대상에 추가
  ├─ DoMatchCheck()  [m_CellToMatchCheck] DoCheck(cell): 가로·세로 3+ 탐색 → Match 등록
  ├─ MatchTicking()  [m_TickingMatch]     DeletionTimer 후 DestroyGem → 코인 VFX, LevelData.Matched(gem) 목표 카운트,
  │                                       BonusGem.Shapes 중 FitIn()되는 모양이 있으면 그 자리에 보너스 젬 생성
  ├─ EmptyCheck()    [m_EmptyCells]       빈 셀 위의 젬을 아래로(대각선 포함), 스포너 열이면 NewGemAt 으로 보충
  └─ 힌트 타이머: 아무 일도 없으면 InactivityBeforeHint(2초) 후 FindAllPossibleMatch()의 한 수를 HintPrefab으로 표시
[종료] LevelData.OnAllGoalFinished / OnNoMoveLeft → Board.TriggerFinalStretch()
       → 보드가 멈추면(m_FinalStretch && 변화 없음) UIHandler.ShowEnd() → 승리 시 GameManager.WinStar(), 패배 시 LoseLife()
```

포럼에 보고된 "빠른 스와프 + 폭탄 시 낙하 멈춤 / `TickSwap` NullReference"는 모두 이 단계들이
같은 프레임에 겹칠 때(스와프 중인 셀이 동시에 매치·낙하 대상이 될 때) 생긴다. BoardCell.Locked 와 Board의 `m_FreezeMoveLock` 이 이를 막는 장치다.

@section sec_data 데이터와 로직의 분리

- **보너스 젬**은 Gem을 상속한 프리팹이며 GameSettings.BonusSettings.Bonuses 배열에 등록한다. 어떤 매치 모양에서 생성될지는
  프리팹의 MatchShape 리스트(회전·대칭 허용 포함)로 정의 — 새 보너스는 BonusGem 상속 + `Use()` 구현 + MatchShape 지정.
- **보너스 아이템**(화면 하단 바, 상점에서 구매)은 BonusItem(ScriptableObject) 파생. BonusGemBonusItem이 보너스 젬을 아이템으로 감싼다 (`Data/BonusItems`).
- **상점 품목**은 ShopSetting.ShopItem 파생 3종: ShopItemCoin, ShopItemLive, ShopItemBonusItem (`Data/ShopItems`). 생성 메뉴 `2D Match`.
- **장애물**은 두 계통이다: Crate는 Gem 파생(셀을 차지, HP 3, 인접 매치로 피해), TieBlocker는 Obstacle 파생(젬 위에 덮임, 아래 매치로 해제).
- 코드에 박힌 상수: 목숨 초기값 `Lives = 5`, SFX 소스 16개, VFX 코인 풀 12개, 더블클릭 판정 시간, `Application.targetFrameRate = 60`.

@section sec_status 현황 판정 요약 (강의용)

| 기능 | 현황 | 근거 |
|---|---|---|
| 스와프·매치 판정·삭제·낙하·보충 | ● 완성 | Board (단, 포럼 보고 버그 — 현 버전 재현 여부 0주차 확인) |
| 보너스 젬 4종(소형/대형 폭탄, 로켓, 색 제거) + 매치 모양 기반 생성 | ● 완성 | BonusGem 파생, MatchShape.FitIn |
| 블로커 2종(나무상자·밧줄) | ● 완성 | Crate, TieBlocker |
| 목표·이동 수·승패 판정·결과 화면 | ● 완성 | LevelData, UIHandler.ShowEnd |
| 힌트(2초 무조작 시 가능한 수 표시) | ● 완성 | Board.FindAllPossibleMatch, GameSettings.InactivityBeforeHint |
| 상점(코인·목숨·보너스 아이템 구매), 보너스 아이템 바 | ● 완성 | ShopItem 3종, GameManager.BonusItems, UIHandler.ShowShop |
| 코인·별·목숨 영속화 | ○ 없음 | GameManager 프로퍼티는 메모리뿐. 저장되는 것은 사운드 볼륨(sounds.json)뿐 |
| 레벨 잠금·진행·별점 | ○ 없음 | Stars는 누적 숫자만, 레벨별 기록 없음. Main 메뉴는 LevelList 전부 노출 |
| 점수·콤보 | ○ 없음 | 매치당 코인 VFX만 |
| 목숨 시간 회복, 제한 시간 모드 | ○ 없음 | — |
| 터치 입력 | ● 지원 | ClickAction/ClickPosition InputAction, 세로 화면 카메라 프레이밍(ComputeCamera), UI SafeArea |
| 디버그 메뉴 | ▲ 참고 | F12(에디터/개발 빌드)로 아무 셀에 아무 젬 배치 — 테스트 시 유용 |

@section sec_extension 확장 포인트 (2단계 입력)

1. **데이터·씬만으로**: 새 레벨(씬 템플릿), 새 상점 품목, 보너스 아이템 가격·구성, 튜닝 값(GameSettings).
2. **상속으로**: 새 보너스 젬(BonusGem + MatchShape), 새 장애물(Obstacle 또는 Gem 파생), 새 상점 품목 종류(ShopItem), 새 보너스 아이템(BonusItem).
3. **새 컴포넌트로(Board 수정 없이)**: 점수·콤보(LevelData.OnGoalChanged/OnMoveHappened와 Match.DeletedCount 활용 — 단 "젬 삭제" 이벤트는 LevelData.Matched 경유), 진행 저장(GameManager 코인·별·목숨을 JSON으로), 레벨 잠금(Main 메뉴 + 저장 데이터), 별점 결과(RemainingMove 기준).
4. **Board 수정이 필요한 것**: 낙하 버그 수정, 매치 삭제 이벤트 공개(현재는 LevelData.Matched 호출뿐), 제한 시간 모드, 새 매치 규칙(L/T 모양은 MatchShape로 이미 가능).

@section sec_modules 모듈 안내

[Topics](topics.html) 페이지에서 역할별로 클래스를 묶어 두었다. Board 페이지의 **피호출 그래프**(이 함수를 누가 부르는가)는
"Board를 고치면 어디가 흔들리는가"를 볼 때, **호출 그래프**는 Update → 각 단계의 순서를 따라갈 때 쓴다.

@note 한국어 설명은 강의용으로 분석자가 덧붙인 것이며, 각 멤버의 영문 주석은 원본 소스의 XML 주석이다.
