var topics =
[
    [ "1. 코어 — 전역 상태·씬 흐름·설정", "group__core.html", "group__core" ],
    [ "2. 보드 — 상태 기계와 셀", "group__board.html", "group__board" ],
    [ "3. 젬·보너스 젬·블로커", "group__gems.html", "group__gems" ],
    [ "4. 레벨 — 규칙·저작 타일·레벨 목록", "group__level.html", "group__level" ],
    [ "5. 보너스 아이템·상점", "group__items.html", "group__items" ],
    [ "6. UI", "group__ui.html", "group__ui" ],
    [ "7. 연출·VFX·조명", "group__fx.html", "group__fx" ],
    [ "8. 에디터 전용", "group__editor.html", "group__editor" ]
];