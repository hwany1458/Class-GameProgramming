var classMatch3_1_1ObstaclePlacer =
[
    [ "GetTileData", "classMatch3_1_1ObstaclePlacer.html#a3fe542f06ca53bc22865090f1546ef29", null ],
    [ "StartUp", "classMatch3_1_1ObstaclePlacer.html#acc99e588e20167610f6644bc9931dd7c", null ],
    [ "PreviewEditorSprite", "classMatch3_1_1ObstaclePlacer.html#a6ad77789363b27366aeadbd41b79a1ba", null ],
    [ "ObstaclePrefab", "classMatch3_1_1ObstaclePlacer.html#a64977bfdab5bd96e2d73a100e5272a54", null ]
];