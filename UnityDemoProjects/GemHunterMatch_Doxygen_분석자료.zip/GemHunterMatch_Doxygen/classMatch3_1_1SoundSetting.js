var classMatch3_1_1SoundSetting =
[
    [ "Mixer", "classMatch3_1_1SoundSetting.html#ac1f4e320d98de5750fecafdf62b768d1", null ],
    [ "SFXSourcePrefab", "classMatch3_1_1SoundSetting.html#adc1ae770d5920c3fbe3eb597139f0a6d", null ],
    [ "MusicSourcePrefab", "classMatch3_1_1SoundSetting.html#acdb8dafb7d5b1ca9b6fbc651487ecc0b", null ],
    [ "MenuSound", "classMatch3_1_1SoundSetting.html#a71d300e14b3691d05984061b138a5342", null ],
    [ "SwipSound", "classMatch3_1_1SoundSetting.html#a4f3eba8d71a5165db46251f459608ed2", null ],
    [ "FallSound", "classMatch3_1_1SoundSetting.html#a5c819426e44d2b490637f89200c1fd6c", null ],
    [ "CoinSound", "classMatch3_1_1SoundSetting.html#a12ebc0467754bedcfe23af047cf20553", null ],
    [ "WinVoice", "classMatch3_1_1SoundSetting.html#a4dbc089c9b2f4b84a6a7d0e1dfb6be9d", null ],
    [ "LooseVoice", "classMatch3_1_1SoundSetting.html#a49ac30996367af85a299ccacac198850", null ],
    [ "WinSound", "classMatch3_1_1SoundSetting.html#aaa9bd168ea8ee93a9ab294a65b4839da", null ],
    [ "LooseSound", "classMatch3_1_1SoundSetting.html#a4ba4930b98d188da98663611704fdafe", null ]
];