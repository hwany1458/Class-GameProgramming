var classMatch3_1_1GameSettings =
[
    [ "InactivityBeforeHint", "classMatch3_1_1GameSettings.html#a8d42dec6debd566794ca93e967866f04", null ],
    [ "VisualSettings", "classMatch3_1_1GameSettings.html#ae44c0dfa895f083f51c0d7a6a19a7213", null ],
    [ "BonusSettings", "classMatch3_1_1GameSettings.html#a17e9938f49327a803b87458458ceaf3b", null ],
    [ "ShopSettings", "classMatch3_1_1GameSettings.html#a81d7fe78d417dd4ce6dd818c98f38f24", null ],
    [ "SoundSettings", "classMatch3_1_1GameSettings.html#ab03a5fad3e4eec2d613d613746787a75", null ]
];