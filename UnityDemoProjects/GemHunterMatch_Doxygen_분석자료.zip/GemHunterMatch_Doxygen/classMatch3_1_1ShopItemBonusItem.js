var classMatch3_1_1ShopItemBonusItem =
[
    [ "Buy", "classMatch3_1_1ShopItemBonusItem.html#aa6d12d0e25fea593e681c5504d5f692f", null ],
    [ "BonusItem", "classMatch3_1_1ShopItemBonusItem.html#ad596910627a05393aa4ee00f9cdd330c", null ]
];