var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", null ],
    [ "Scripts", "dir_3ac9928fc2e7e2cbc53db7c1a11acda2.html", "dir_3ac9928fc2e7e2cbc53db7c1a11acda2" ]
];