var hierarchy =
[
    [ "Match3.BoardCell", "classMatch3_1_1BoardCell.html", null ],
    [ "Match3.GameManager.BonusItemEntry", "classMatch3_1_1GameManager_1_1BonusItemEntry.html", null ],
    [ "Match3.BonusSetting", "classMatch3_1_1BonusSetting.html", null ],
    [ "Match3.UIHandler.DebugGemButton", "classMatch3_1_1UIHandler_1_1DebugGemButton.html", null ],
    [ "Match3.GameSettings", "classMatch3_1_1GameSettings.html", null ],
    [ "Match3.LevelData.GemGoal", "classMatch3_1_1LevelData_1_1GemGoal.html", null ],
    [ "Match3.Board.IBoardAction", "interfaceMatch3_1_1Board_1_1IBoardAction.html", [
      [ "Match3.RocketAction", "classMatch3_1_1RocketAction.html", null ]
    ] ],
    [ "IPreprocessBuildWithReport", null, [
      [ "Match3.BuildLevelList", "classMatch3_1_1BuildLevelList.html", null ]
    ] ],
    [ "ISerializationCallbackReceiver", null, [
      [ "Match3.MatchShape", "classMatch3_1_1MatchShape.html", null ]
    ] ],
    [ "Match3.Obstacle.LockStateData", "classMatch3_1_1Obstacle_1_1LockStateData.html", null ],
    [ "Match3.Match", "classMatch3_1_1Match.html", null ],
    [ "MonoBehaviour", null, [
      [ "Match3.Board", "classMatch3_1_1Board.html", null ],
      [ "Match3.GameManager", "classMatch3_1_1GameManager.html", null ],
      [ "Match3.Gem", "classMatch3_1_1Gem.html", [
        [ "Match3.BonusGem", "classMatch3_1_1BonusGem.html", [
          [ "Match3.ColorClean", "classMatch3_1_1ColorClean.html", null ],
          [ "Match3.LargeBomb", "classMatch3_1_1LargeBomb.html", null ],
          [ "Match3.LineRocket", "classMatch3_1_1LineRocket.html", null ],
          [ "Match3.SmallBomb", "classMatch3_1_1SmallBomb.html", null ]
        ] ],
        [ "Match3.Crate", "classMatch3_1_1Crate.html", null ]
      ] ],
      [ "Match3.InitLoader", "classMatch3_1_1InitLoader.html", null ],
      [ "Match3.LevelData", "classMatch3_1_1LevelData.html", null ],
      [ "Match3.LightManager", "classMatch3_1_1LightManager.html", null ],
      [ "Match3.MainMenu", "classMatch3_1_1MainMenu.html", null ],
      [ "Match3.Obstacle", "classMatch3_1_1Obstacle.html", [
        [ "Match3.TieBlocker", "classMatch3_1_1TieBlocker.html", null ]
      ] ],
      [ "Match3.UIHandler", "classMatch3_1_1UIHandler.html", null ]
    ] ],
    [ "Match3.Board.PossibleSwap", "classMatch3_1_1Board_1_1PossibleSwap.html", null ],
    [ "PropertyDrawer", null, [
      [ "Match3.MatchShapePropertyDrawer", "classMatch3_1_1MatchShapePropertyDrawer.html", null ]
    ] ],
    [ "ScriptableObject", null, [
      [ "Match3.BonusItem", "classMatch3_1_1BonusItem.html", [
        [ "Match3.BonusGemBonusItem", "classMatch3_1_1BonusGemBonusItem.html", null ]
      ] ],
      [ "Match3.LevelList", "classMatch3_1_1LevelList.html", null ],
      [ "Match3.ShopSetting.ShopItem", "classMatch3_1_1ShopSetting_1_1ShopItem.html", [
        [ "Match3.ShopItemBonusItem", "classMatch3_1_1ShopItemBonusItem.html", null ],
        [ "Match3.ShopItemCoin", "classMatch3_1_1ShopItemCoin.html", null ],
        [ "Match3.ShopItemLive", "classMatch3_1_1ShopItemLive.html", null ]
      ] ]
    ] ],
    [ "Match3.UIHandler.ShopEntry", "classMatch3_1_1UIHandler_1_1ShopEntry.html", null ],
    [ "Match3.ShopSetting", "classMatch3_1_1ShopSetting.html", null ],
    [ "Match3.GameManager.SoundData", "classMatch3_1_1GameManager_1_1SoundData.html", null ],
    [ "Match3.SoundSetting", "classMatch3_1_1SoundSetting.html", null ],
    [ "TileBase", null, [
      [ "Match3.GemPlacerTile", "classMatch3_1_1GemPlacerTile.html", null ],
      [ "Match3.GemSpawner", "classMatch3_1_1GemSpawner.html", null ],
      [ "Match3.ObstaclePlacer", "classMatch3_1_1ObstaclePlacer.html", null ]
    ] ],
    [ "Match3.UIHandler.UIAnimationEntry", "classMatch3_1_1UIHandler_1_1UIAnimationEntry.html", null ],
    [ "VFXInstance", "classMatch3_1_1VFXInstance.html", null ],
    [ "Match3.VFXPoolSystem.VFXInstance", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html", null ],
    [ "Match3.VFXPoolSystem", "classMatch3_1_1VFXPoolSystem.html", null ],
    [ "Match3.VisualSetting", "classMatch3_1_1VisualSetting.html", null ]
];