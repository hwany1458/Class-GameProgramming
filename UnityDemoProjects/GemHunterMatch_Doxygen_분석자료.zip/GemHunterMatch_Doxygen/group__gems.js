var group__gems =
[
    [ "Match3.BonusSetting", "classMatch3_1_1BonusSetting.html", [
      [ "Bonuses", "classMatch3_1_1BonusSetting.html#afd7429be6352767d9dca68c791355807", null ]
    ] ],
    [ "Match3.Gem", "classMatch3_1_1Gem.html", [
      [ "State", "classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbe", [
        [ "Still", "classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbeacddbd3031f6f6e9708e2eb9c1a467f65", null ],
        [ "Falling", "classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbea0f57d5b441651c57eac9f91efaa5a75a", null ],
        [ "Bouncing", "classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbea93a5daccfac872d82b8fd4b329adfd9f", null ],
        [ "Disappearing", "classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbead1820ff4aad6d28ab1331a56d3352778", null ]
      ] ],
      [ "Init", "classMatch3_1_1Gem.html#a90eba66929fd84912811c03ce60823cb", null ],
      [ "Use", "classMatch3_1_1Gem.html#a278064e526baa3e033ef741b967d36a3", null ],
      [ "Damage", "classMatch3_1_1Gem.html#a414b24a714436e805ef7f9f02ea19a3a", null ],
      [ "MoveTo", "classMatch3_1_1Gem.html#aacdfc415db3607f42e0543258d4e6618", null ],
      [ "StartMoveTimer", "classMatch3_1_1Gem.html#aa0645351181e9f50cb65b5afd3ea2fb9", null ],
      [ "TickMoveTimer", "classMatch3_1_1Gem.html#a56df899862d1def46170ced32c1ba82a", null ],
      [ "StopFalling", "classMatch3_1_1Gem.html#af8898dc3a0e6c350990378bcf6d741cd", null ],
      [ "StopBouncing", "classMatch3_1_1Gem.html#aaa3f42ba1d9edfe4505a2c07d040e95e", null ],
      [ "Destroyed", "classMatch3_1_1Gem.html#a6e489a0f6b64fd7931f1e027f86e7f26", null ],
      [ "GemType", "classMatch3_1_1Gem.html#a0121c9c28564d107a26a055f086bc537", null ],
      [ "MatchEffectPrefabs", "classMatch3_1_1Gem.html#a0d968054e4ec81947482578801118df9", null ],
      [ "UISprite", "classMatch3_1_1Gem.html#a685adad7fa5170c75d27f12ff47dff0d", null ],
      [ "CurrentMatch", "classMatch3_1_1Gem.html#a5e288b711d3295c33356b3e27f2cdd58", null ],
      [ "SpeedMultiplier", "classMatch3_1_1Gem.html#a88ba7d05a000ebb49cd8239e1b1b2341", null ],
      [ "m_Usable", "classMatch3_1_1Gem.html#a6df7b5f581a423c9ae5e76e2a055cf91", null ],
      [ "m_Used", "classMatch3_1_1Gem.html#a3c7e9e13bf5cf7de07db53cec3717ca4", null ],
      [ "m_CanMove", "classMatch3_1_1Gem.html#a7b5d7991e39b851bb063bc4b03a576cf", null ],
      [ "m_CurrentIndex", "classMatch3_1_1Gem.html#a92ee6c9509cdbc54462e7a0de56053aa", null ],
      [ "m_HitPoints", "classMatch3_1_1Gem.html#ae20f218974e9cabc38a64f523a156ee3", null ],
      [ "m_FallTime", "classMatch3_1_1Gem.html#a7de9bc4b022840b04b1be502ab94aed5", null ],
      [ "m_CurrentState", "classMatch3_1_1Gem.html#ab328d03ea2613e27b504dff85926e200", null ],
      [ "CanMove", "classMatch3_1_1Gem.html#a89b2cbeb798e5b2ab680c44483e15b2c", null ],
      [ "CurrentIndex", "classMatch3_1_1Gem.html#a3a3bf51bc0ed738bf15a63f2b6c3d163", null ],
      [ "Usable", "classMatch3_1_1Gem.html#a8d9c512c929a1b664e12f6fe0200d5b9", null ],
      [ "Used", "classMatch3_1_1Gem.html#ad007c1020cb46401975f015ca46e8931", null ],
      [ "FallTime", "classMatch3_1_1Gem.html#a0969e6d3a67d0a961aac21e81364b1fe", null ],
      [ "CurrentState", "classMatch3_1_1Gem.html#af738c65c8351fa972d6caea0d8c26fe6", null ],
      [ "HitPoint", "classMatch3_1_1Gem.html#aa6c6f4852a07028a1922302ad15a2f33", null ]
    ] ],
    [ "Match3.BonusGem", "classMatch3_1_1BonusGem.html", [
      [ "Awake", "classMatch3_1_1BonusGem.html#a1bff33621295af06d14a274d354727db", null ],
      [ "HandleContent", "classMatch3_1_1BonusGem.html#a62369f6e9f910d58543a84fa15fcff1e", null ],
      [ "BonusTriggerEffect", "classMatch3_1_1BonusGem.html#a6822df339d02697e11efbf048a36c98b", null ],
      [ "Shapes", "classMatch3_1_1BonusGem.html#a000f515c128d8f8f56348c0331547932", null ]
    ] ],
    [ "Match3.MatchShape", "classMatch3_1_1MatchShape.html", [
      [ "OnBeforeSerialize", "classMatch3_1_1MatchShape.html#a20ae971c092296df06c4e6f7378293f1", null ],
      [ "OnAfterDeserialize", "classMatch3_1_1MatchShape.html#a78bbb8e35102e8b437f537a8d39ef5bb", null ],
      [ "FitIn", "classMatch3_1_1MatchShape.html#a169e801f10931a930a477694ae63450a", null ],
      [ "GetRotation", "classMatch3_1_1MatchShape.html#a650abf4226cb0541ec1feb44c24c04b5", null ],
      [ "GetBoundOf", "classMatch3_1_1MatchShape.html#a712392063cc485d1e150720c6f00ebd3", null ],
      [ "CanMirror", "classMatch3_1_1MatchShape.html#a4027ea4c26a63f8ed1cc4759f069975e", null ],
      [ "CanRotate", "classMatch3_1_1MatchShape.html#a59db7e1ef28ba5d334ec756621274af3", null ],
      [ "Cells", "classMatch3_1_1MatchShape.html#a86a204ec0054eb3b467289988aea517f", null ],
      [ "Bounds", "classMatch3_1_1MatchShape.html#ad48b8de8ee1741a5e285d5ca28044aa6", null ],
      [ "Cell90Rot", "classMatch3_1_1MatchShape.html#a3eb071201290a974fc06ac32c4043c45", null ],
      [ "Cell180Rot", "classMatch3_1_1MatchShape.html#a5243d408cfc3527f5613590bf60bbfb4", null ],
      [ "Cell270Rot", "classMatch3_1_1MatchShape.html#a57c7096552d5dca09a1c51bbb656af30", null ],
      [ "CellHMirror", "classMatch3_1_1MatchShape.html#a940b164ae343b81c4fe41e9e56e2f960", null ],
      [ "CellVMirror", "classMatch3_1_1MatchShape.html#a5b83a5d8f16a354c242d2d4885f05b2a", null ]
    ] ],
    [ "Match3.SmallBomb", "classMatch3_1_1SmallBomb.html", [
      [ "Awake", "classMatch3_1_1SmallBomb.html#a881467aa7c6f17b8ad80aeb518949ad9", null ],
      [ "Use", "classMatch3_1_1SmallBomb.html#a7180dd752da588d1bbf09fbc5de65c9e", null ],
      [ "TriggerSound", "classMatch3_1_1SmallBomb.html#addc4255ed58ecc352d51cd387dcd51c0", null ]
    ] ],
    [ "Match3.LargeBomb", "classMatch3_1_1LargeBomb.html", [
      [ "Awake", "classMatch3_1_1LargeBomb.html#a38c69af616cf3a8a9e56ab161e8bb75b", null ],
      [ "Use", "classMatch3_1_1LargeBomb.html#a3dfda8325fa14053d27c636b79c44fca", null ],
      [ "TriggerSound", "classMatch3_1_1LargeBomb.html#a34885b91ab4dea136046bb9c5c407378", null ]
    ] ],
    [ "Match3.LineRocket", "classMatch3_1_1LineRocket.html", [
      [ "Awake", "classMatch3_1_1LineRocket.html#ab249f04c2ac625b721cdcba14b4fab6f", null ],
      [ "Use", "classMatch3_1_1LineRocket.html#aa61afc89c4d0564ed3cc9aa9c1b704d7", null ],
      [ "VisualPrefab", "classMatch3_1_1LineRocket.html#a32cad05b6302f48cdb8d9bd4d56af825", null ],
      [ "Vertical", "classMatch3_1_1LineRocket.html#add9e36d1b2d1ed2186fd0d1c3285d757", null ],
      [ "TriggerSound", "classMatch3_1_1LineRocket.html#aa88b74c605a3d3e51215c0c0e83b6e25", null ]
    ] ],
    [ "Match3.RocketAction", "classMatch3_1_1RocketAction.html", [
      [ "RocketAction", "classMatch3_1_1RocketAction.html#a056908e26613b73c675da896ef1907a9", null ],
      [ "Tick", "classMatch3_1_1RocketAction.html#a12baefa99f3ef9e8dd3deedef96be3d2", null ],
      [ "m_CurrentCell", "classMatch3_1_1RocketAction.html#a9002e6901d2c736a9bfdae049092f6cf", null ],
      [ "m_Direction", "classMatch3_1_1RocketAction.html#aee7446e75e252fdb12e9224d4cda4741", null ],
      [ "m_Visual", "classMatch3_1_1RocketAction.html#ae882ced838f458a71201d015e9760a69", null ],
      [ "MoveSpeed", "classMatch3_1_1RocketAction.html#aaab165e1e11b71bdbb7bb0d2e9be5e30", null ]
    ] ],
    [ "Match3.ColorClean", "classMatch3_1_1ColorClean.html", [
      [ "Awake", "classMatch3_1_1ColorClean.html#ae001041b144ba5742a0f1d3818add0fb", null ],
      [ "Use", "classMatch3_1_1ColorClean.html#adebca2152782bcebab1efa9939e43f49", null ],
      [ "UseEffect", "classMatch3_1_1ColorClean.html#af6cb61f04a18a21f706f869acdeabcf3", null ],
      [ "TriggerSound", "classMatch3_1_1ColorClean.html#ad926a1bba1f0b9cc1899900d94e40e42", null ],
      [ "m_PositionMap", "classMatch3_1_1ColorClean.html#a6fb6e5422bfe106c156e9f14f05e9cc5", null ]
    ] ],
    [ "Match3.Crate", "classMatch3_1_1Crate.html", [
      [ "Awake", "classMatch3_1_1Crate.html#a1e9d82427ffe6b09c11b73fcc6c686d5", null ],
      [ "Init", "classMatch3_1_1Crate.html#afee50bfdba626f6e7e137df87b2148e6", null ],
      [ "Damage", "classMatch3_1_1Crate.html#abbe6a2874223d0dd4364ff7ec377bc97", null ],
      [ "OnDestroy", "classMatch3_1_1Crate.html#aa99a7522efa6f58942438801309a5d24", null ],
      [ "AdjacentMatch", "classMatch3_1_1Crate.html#a2425b7ed542aa1825da8f808b9d21c68", null ],
      [ "UpdateState", "classMatch3_1_1Crate.html#a6f15d6fd2887ac066859fee24a092a1e", null ],
      [ "CanBeDestroyedWithAdjacentMatch", "classMatch3_1_1Crate.html#a30a0f2438a76e39ba60e68723d6bf252", null ],
      [ "HealthStates", "classMatch3_1_1Crate.html#af625a67fa71875f369904f8c854ced8a", null ],
      [ "Health", "classMatch3_1_1Crate.html#af7689a74700ac4801a9585f8f257c825", null ],
      [ "DamagedClip", "classMatch3_1_1Crate.html#ad363cf8cff55120ea48873e8d06287df", null ],
      [ "DamageEffect", "classMatch3_1_1Crate.html#a293d76abcd507924e4b234a0c70980f9", null ],
      [ "m_Renderer", "classMatch3_1_1Crate.html#a515b40fb96fab567678eac6f27906511", null ]
    ] ],
    [ "Match3.Obstacle", "classMatch3_1_1Obstacle.html", [
      [ "Init", "classMatch3_1_1Obstacle.html#aba55e15303d00d677aa7078cbc7c127d", null ],
      [ "Clear", "classMatch3_1_1Obstacle.html#a78f97afbc52c81fd39689e74f234f4f3", null ],
      [ "Damage", "classMatch3_1_1Obstacle.html#a50a21886100ddbc2aae77e6e5d18d406", null ],
      [ "ChangeState", "classMatch3_1_1Obstacle.html#a1864bdfe6cca1b2043a6d9853ec22777", null ],
      [ "LockState", "classMatch3_1_1Obstacle.html#afd86b62c243e34dd33398a3979e86fc5", null ],
      [ "m_SpriteRenderer", "classMatch3_1_1Obstacle.html#af7bce0dc16df69569135cd2980c1c2aa", null ],
      [ "m_CurrentState", "classMatch3_1_1Obstacle.html#ab3c1d9a8a4853f4a5a00474ef7129b16", null ],
      [ "m_Cell", "classMatch3_1_1Obstacle.html#a0cd1c19ad7229eb46405713282eaff5f", null ],
      [ "m_Done", "classMatch3_1_1Obstacle.html#ae707668183f2f8e3d2e8f47dbba735ca", null ]
    ] ],
    [ "Match3.Obstacle.LockStateData", "classMatch3_1_1Obstacle_1_1LockStateData.html", [
      [ "Sprite", "classMatch3_1_1Obstacle_1_1LockStateData.html#af1d0e2fbd5c8ed46ab02fdba43ab5834", null ],
      [ "UndoneVFX", "classMatch3_1_1Obstacle_1_1LockStateData.html#aa532b093c6f67b07a2e5ff9ae218c59f", null ]
    ] ],
    [ "Match3.TieBlocker", "classMatch3_1_1TieBlocker.html", [
      [ "Init", "classMatch3_1_1TieBlocker.html#a992c867433c214e3a2eefc321a0d8141", null ],
      [ "Clear", "classMatch3_1_1TieBlocker.html#ab3c8cd98511a9de89ee03f8e394814c7", null ],
      [ "CellMatch", "classMatch3_1_1TieBlocker.html#a87d535c0a3f3e4e133eeec808edcc823", null ]
    ] ]
];