var searchData=
[
  ['colorclean_0',['ColorClean',['../classMatch3_1_1ColorClean.html',1,'Match3']]],
  ['crate_1',['Crate',['../classMatch3_1_1Crate.html',1,'Match3']]]
];
