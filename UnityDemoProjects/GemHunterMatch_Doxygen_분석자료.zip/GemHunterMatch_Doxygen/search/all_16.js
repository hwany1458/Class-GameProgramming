var searchData=
[
  ['random_0',['Random',['../Board_8cs.html#a832e8f52fca5a678819ec96269dcb532',1,'Board.cs']]],
  ['registercell_1',['RegisterCell',['../classMatch3_1_1Board.html#a22a52392484b2c9b5bc4b6efa47a03b6',1,'Match3::Board']]],
  ['registerdeletedcallback_2',['RegisterDeletedCallback',['../classMatch3_1_1Board.html#ab832a45d13c7deb0cdcfe0f10a65da91',1,'Match3::Board']]],
  ['registergemtodebug_3',['RegisterGemToDebug',['../classMatch3_1_1UIHandler.html#a00a4e833811f57a0ebd13109a8993aa8',1,'Match3::UIHandler']]],
  ['registermatchedcallback_4',['RegisterMatchedCallback',['../classMatch3_1_1Board.html#a79bce03c55fd676a3e7ac56b391b8d49',1,'Match3::Board']]],
  ['registerspawner_5',['RegisterSpawner',['../classMatch3_1_1Board.html#ac225dce3127d98f76ce872a7fedd8e5b',1,'Match3::Board']]],
  ['remainingmove_6',['RemainingMove',['../classMatch3_1_1LevelData.html#a529ff6784daa26f14c56a4bb9ab9a73c',1,'Match3::LevelData']]],
  ['removecell_7',['RemoveCell',['../classMatch3_1_1MatchShapePropertyDrawer.html#a7a631ce4b5852757aa5df4e2611461b2',1,'Match3::MatchShapePropertyDrawer']]],
  ['return_8',['Return',['../classMatch3_1_1Board.html#a678ae9417bb561c72ac4dee8651ed91ca988fd738de9c6d177440c5dcf69e73ce',1,'Match3::Board']]],
  ['rocketaction_9',['rocketaction',['../classMatch3_1_1RocketAction.html',1,'Match3.RocketAction'],['../classMatch3_1_1RocketAction.html#a056908e26613b73c675da896ef1907a9',1,'Match3.RocketAction.RocketAction()']]]
];
