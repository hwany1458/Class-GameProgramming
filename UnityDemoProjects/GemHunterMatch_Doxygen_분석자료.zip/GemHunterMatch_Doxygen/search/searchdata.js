var indexSectionsWithContent =
{
  0: "12345678abcdefghilmnoprstuvw—강구규기끝데레로루만모목보분상새셀소스씬아안에연요입전젬코타판포한핵현확흐",
  1: "bcdgilmoprstuv",
  2: "m",
  3: "bcgilmostuv",
  4: "abcdefghilmnoprstuw",
  5: "abcdefghilmnopstuvw",
  6: "r",
  7: "cs",
  8: "bdflmnrsw",
  9: "bcdfghilprsuv",
  10: "12345678u—규기레목보상셀아에연전젬코타흐",
  11: "ghm레만분새소"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수",
  6: "타입정의",
  7: "열거형 타입",
  8: "열거형 멤버",
  9: "속성",
  10: "그룹들",
  11: "페이지들"
};

