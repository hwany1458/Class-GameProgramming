var searchData=
[
  ['gem_0',['gem',['../classMatch3_1_1LevelData_1_1GemGoal.html#ab67685d70f86773d21cb4725a8ef3237',1,'Match3.LevelData.GemGoal.Gem'],['../classMatch3_1_1UIHandler_1_1DebugGemButton.html#afe31b5be387a2ef1aa0b71d11de51255',1,'Match3.UIHandler.DebugGemButton.Gem']]],
  ['gemgoaltemplate_1',['GemGoalTemplate',['../classMatch3_1_1UIHandler.html#aaad2ae2df2275a753ec3c579ff0ec23e',1,'Match3::UIHandler']]],
  ['gemholdprefab_2',['GemHoldPrefab',['../classMatch3_1_1Board.html#a5fc9fb84ab781fea096521ee70c031a4',1,'Match3::Board']]],
  ['gemtype_3',['GemType',['../classMatch3_1_1Gem.html#a0121c9c28564d107a26a055f086bc537',1,'Match3::Gem']]],
  ['globallightmaterial_4',['globalLightMaterial',['../classMatch3_1_1LightManager.html#a2d62f07cdbc9f2fe8f0184a241cbc431',1,'Match3::LightManager']]],
  ['goals_5',['Goals',['../classMatch3_1_1LevelData.html#a8404323cd7fb39e49cb5f9afe5407a45',1,'Match3::LevelData']]]
];
