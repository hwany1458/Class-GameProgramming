var searchData=
[
  ['iboardaction_0',['IBoardAction',['../interfaceMatch3_1_1Board_1_1IBoardAction.html',1,'Match3::Board']]],
  ['inactivitybeforehint_1',['InactivityBeforeHint',['../classMatch3_1_1GameSettings.html#a8d42dec6debd566794ca93e967866f04',1,'Match3::GameSettings']]],
  ['incominggem_2',['IncomingGem',['../classMatch3_1_1BoardCell.html#a50f1517fb28eca3e78490c7b47481671',1,'Match3::BoardCell']]],
  ['init_3',['init',['../classMatch3_1_1UIHandler.html#a4c006c4a47a9e65e5128a90179f13839',1,'Match3.UIHandler.Init()'],['../classMatch3_1_1Board.html#a42719e49b53140abee27ab2eefec1314',1,'Match3.Board.Init()'],['../classMatch3_1_1Crate.html#afee50bfdba626f6e7e137df87b2148e6',1,'Match3.Crate.Init()'],['../classMatch3_1_1Gem.html#a90eba66929fd84912811c03ce60823cb',1,'Match3.Gem.Init()'],['../classMatch3_1_1Obstacle.html#aba55e15303d00d677aa7078cbc7c127d',1,'Match3.Obstacle.Init()'],['../classMatch3_1_1TieBlocker.html#a992c867433c214e3a2eefc321a0d8141',1,'Match3.TieBlocker.Init()']]],
  ['initloader_4',['InitLoader',['../classMatch3_1_1InitLoader.html',1,'Match3']]],
  ['initloader_2ecs_5',['InitLoader.cs',['../InitLoader_8cs.html',1,'']]],
  ['instance_6',['instance',['../classMatch3_1_1GameManager.html#a07ddbcc74b44cb414714cc89b6050840',1,'Match3.GameManager.Instance'],['../classMatch3_1_1LevelData.html#a7dc56e7d94414a2b487f5664a60639f3',1,'Match3.LevelData.Instance'],['../classMatch3_1_1UIHandler.html#ab7c2e3658e60ed12a61babdcfed616d8',1,'Match3.UIHandler.Instance'],['../classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#af0ef1ac9a0acd238ffd65bd4893e4608',1,'Match3.VFXPoolSystem.VFXInstance.Instance']]],
  ['isempty_7',['IsEmpty',['../classMatch3_1_1BoardCell.html#af042eb243fcc43a84d3de25516b8613e',1,'Match3::BoardCell']]],
  ['isshuttingdown_8',['IsShuttingDown',['../classMatch3_1_1GameManager.html#ad1f3e72ac8ce1f31d7a42aebba7a3553',1,'Match3::GameManager']]],
  ['item_9',['Item',['../classMatch3_1_1GameManager_1_1BonusItemEntry.html#aecad0323422df9e4aa0c0e3ee99f876b',1,'Match3::GameManager::BonusItemEntry']]],
  ['itemname_10',['ItemName',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#a54f1719aae747f0fa27b33d444e81e6c',1,'Match3::ShopSetting::ShopItem']]],
  ['items_11',['Items',['../classMatch3_1_1ShopSetting.html#aaaf71e9c7ffb004c85c91eb3d5770940',1,'Match3::ShopSetting']]],
  ['itemsprite_12',['ItemSprite',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#ad64af196eba9e60c1fab299d5b2c2c86',1,'Match3::ShopSetting::ShopItem']]]
];
