var searchData=
[
  ['unlockmovement_0',['UnlockMovement',['../classMatch3_1_1Board.html#a44919708975afeae4f3a3bc8ae19cada',1,'Match3::Board']]],
  ['unregisterdeletedcallback_1',['UnregisterDeletedCallback',['../classMatch3_1_1Board.html#a97f4f3d5c4b272d9d48354ff9b215bac',1,'Match3::Board']]],
  ['unregistermatchedcallback_2',['UnregisterMatchedCallback',['../classMatch3_1_1Board.html#a6474269aecfd11145b83c09d9b53c2ab',1,'Match3::Board']]],
  ['update_3',['update',['../classMatch3_1_1Board.html#a1de931a8a9606dd888d79409053b1325',1,'Match3.Board.Update()'],['../classMatch3_1_1GameManager.html#ae0988d6b51f53e277ee131e3a829464f',1,'Match3.GameManager.Update()'],['../classMatch3_1_1LevelData.html#aa82f3bc82e700888b7cd048e42e9000f',1,'Match3.LevelData.Update()'],['../classMatch3_1_1LightManager.html#a763472251784f2688c42fc91c9a17713',1,'Match3.LightManager.Update()'],['../classMatch3_1_1UIHandler.html#af95d32037a1904b628820ca59867f5ff',1,'Match3.UIHandler.Update()'],['../classMatch3_1_1VFXPoolSystem.html#af1505ffb69102ab3135c59bb08fa1bfc',1,'Match3.VFXPoolSystem.Update()']]],
  ['updatebottombar_4',['UpdateBottomBar',['../classMatch3_1_1UIHandler.html#ae82ede9f58a05935d6cd7e29db61aa7e',1,'Match3::UIHandler']]],
  ['updatebuttonstate_5',['UpdateButtonState',['../classMatch3_1_1UIHandler_1_1ShopEntry.html#a8fc106e454a84ee25d1703b2f99632ac',1,'Match3::UIHandler::ShopEntry']]],
  ['updateshopentry_6',['UpdateShopEntry',['../classMatch3_1_1UIHandler.html#a6189f9a45dc183f7d70aebf4b4d271cb',1,'Match3::UIHandler']]],
  ['updatestate_7',['UpdateState',['../classMatch3_1_1Crate.html#a6f15d6fd2887ac066859fee24a092a1e',1,'Match3::Crate']]],
  ['updatetopbardata_8',['UpdateTopBarData',['../classMatch3_1_1UIHandler.html#ab75f6f8a6c75ed406c6a6eea62460134',1,'Match3::UIHandler']]],
  ['updatevolumes_9',['UpdateVolumes',['../classMatch3_1_1GameManager.html#a903b93addd2e0ad0fdccf05952804c00',1,'Match3::GameManager']]],
  ['use_10',['use',['../classMatch3_1_1ColorClean.html#adebca2152782bcebab1efa9939e43f49',1,'Match3.ColorClean.Use()'],['../classMatch3_1_1LargeBomb.html#a3dfda8325fa14053d27c636b79c44fca',1,'Match3.LargeBomb.Use()'],['../classMatch3_1_1LineRocket.html#aa61afc89c4d0564ed3cc9aa9c1b704d7',1,'Match3.LineRocket.Use()'],['../classMatch3_1_1SmallBomb.html#a7180dd752da588d1bbf09fbc5de65c9e',1,'Match3.SmallBomb.Use()'],['../classMatch3_1_1BonusGemBonusItem.html#ac9d2d0616631abc449aba630c2f7169d',1,'Match3.BonusGemBonusItem.Use()'],['../classMatch3_1_1BonusItem.html#af82c309122cf27849d71c96aa89cada6',1,'Match3.BonusItem.Use()'],['../classMatch3_1_1Gem.html#a278064e526baa3e033ef741b967d36a3',1,'Match3.Gem.Use()']]],
  ['usebonusitem_11',['UseBonusItem',['../classMatch3_1_1GameManager.html#afcf8f64165ba94cd4b0818b52f380bcf',1,'Match3::GameManager']]]
];
