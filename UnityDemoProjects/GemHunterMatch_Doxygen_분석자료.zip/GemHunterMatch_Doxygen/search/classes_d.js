var searchData=
[
  ['vfxinstance_0',['vfxinstance',['../classMatch3_1_1VFXInstance.html',1,'VFXInstance'],['../classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html',1,'Match3.VFXPoolSystem.VFXInstance']]],
  ['vfxpoolsystem_1',['VFXPoolSystem',['../classMatch3_1_1VFXPoolSystem.html',1,'Match3']]],
  ['visualsetting_2',['VisualSetting',['../classMatch3_1_1VisualSetting.html',1,'Match3']]]
];
