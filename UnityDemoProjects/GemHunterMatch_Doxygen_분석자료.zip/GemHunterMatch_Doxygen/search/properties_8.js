var searchData=
[
  ['poolsystem_0',['PoolSystem',['../classMatch3_1_1GameManager.html#aea6d78740cb1424d17fec9c988e57fe1',1,'Match3::GameManager']]]
];
