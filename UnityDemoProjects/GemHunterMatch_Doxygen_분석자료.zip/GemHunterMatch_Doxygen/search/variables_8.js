var searchData=
[
  ['inactivitybeforehint_0',['InactivityBeforeHint',['../classMatch3_1_1GameSettings.html#a8d42dec6debd566794ca93e967866f04',1,'Match3::GameSettings']]],
  ['incominggem_1',['IncomingGem',['../classMatch3_1_1BoardCell.html#a50f1517fb28eca3e78490c7b47481671',1,'Match3::BoardCell']]],
  ['instance_2',['Instance',['../classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#af0ef1ac9a0acd238ffd65bd4893e4608',1,'Match3::VFXPoolSystem::VFXInstance']]],
  ['item_3',['Item',['../classMatch3_1_1GameManager_1_1BonusItemEntry.html#aecad0323422df9e4aa0c0e3ee99f876b',1,'Match3::GameManager::BonusItemEntry']]],
  ['itemname_4',['ItemName',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#a54f1719aae747f0fa27b33d444e81e6c',1,'Match3::ShopSetting::ShopItem']]],
  ['items_5',['Items',['../classMatch3_1_1ShopSetting.html#aaaf71e9c7ffb004c85c91eb3d5770940',1,'Match3::ShopSetting']]],
  ['itemsprite_6',['ItemSprite',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#ad64af196eba9e60c1fab299d5b2c2c86',1,'Match3::ShopSetting::ShopItem']]]
];
