var searchData=
[
  ['iboardaction_0',['IBoardAction',['../interfaceMatch3_1_1Board_1_1IBoardAction.html',1,'Match3::Board']]],
  ['initloader_1',['InitLoader',['../classMatch3_1_1InitLoader.html',1,'Match3']]]
];
