var searchData=
[
  ['scenecount_0',['SceneCount',['../classMatch3_1_1LevelList.html#a4b7405b72305c91975bea6dfbd88ee5a',1,'Match3::LevelList']]],
  ['selecteddebuggem_1',['SelectedDebugGem',['../classMatch3_1_1UIHandler.html#ae38319feba334e7b0a6d5675697dde00',1,'Match3::UIHandler']]],
  ['stars_2',['Stars',['../classMatch3_1_1GameManager.html#a2aff9eaa908fca65584c688dd572c611',1,'Match3::GameManager']]]
];
