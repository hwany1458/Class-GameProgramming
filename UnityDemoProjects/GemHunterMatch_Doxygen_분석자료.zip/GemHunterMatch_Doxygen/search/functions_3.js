var searchData=
[
  ['damage_0',['damage',['../classMatch3_1_1Crate.html#abbe6a2874223d0dd4364ff7ec377bc97',1,'Match3.Crate.Damage()'],['../classMatch3_1_1Gem.html#a414b24a714436e805ef7f9f02ea19a3a',1,'Match3.Gem.Damage()'],['../classMatch3_1_1Obstacle.html#a50a21886100ddbc2aae77e6e5d18d406',1,'Match3.Obstacle.Damage()']]],
  ['darkenbackground_1',['DarkenBackground',['../classMatch3_1_1LevelData.html#a9142dada1d064733076b6b32c7a771a1',1,'Match3::LevelData']]],
  ['delayedinit_2',['DelayedInit',['../classMatch3_1_1GameManager.html#a17c0b8bbb8be1e1483ebe30d31986be6',1,'Match3::GameManager']]],
  ['deselectbonusitem_3',['DeselectBonusItem',['../classMatch3_1_1UIHandler.html#adbf8cd20c3e84b66f06feffa623af134',1,'Match3::UIHandler']]],
  ['destroyed_4',['Destroyed',['../classMatch3_1_1Gem.html#a6e489a0f6b64fd7931f1e027f86e7f26',1,'Match3::Gem']]],
  ['destroygem_5',['DestroyGem',['../classMatch3_1_1Board.html#a6a7e5303f43f60e9682e39345c8d275a',1,'Match3::Board']]],
  ['display_6',['Display',['../classMatch3_1_1UIHandler.html#aa5c705575b9617551d3baa7bd21511d0',1,'Match3::UIHandler']]],
  ['docheck_7',['DoCheck',['../classMatch3_1_1Board.html#a3261194afe335f6842e5b46b5ffad519',1,'Match3::Board']]],
  ['domatchcheck_8',['DoMatchCheck',['../classMatch3_1_1Board.html#a42d136d5a2ebf290f4cb99c470ae9fd5',1,'Match3::Board']]],
  ['drawdebugcross_9',['DrawDebugCross',['../classMatch3_1_1Board.html#a5089745ef1f5331c0844d01b4d37b9c2',1,'Match3::Board']]]
];
