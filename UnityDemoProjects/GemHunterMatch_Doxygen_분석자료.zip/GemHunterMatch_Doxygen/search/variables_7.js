var searchData=
[
  ['health_0',['Health',['../classMatch3_1_1Crate.html#af7689a74700ac4801a9585f8f257c825',1,'Match3::Crate']]],
  ['healthstates_1',['HealthStates',['../classMatch3_1_1Crate.html#af625a67fa71875f369904f8c854ced8a',1,'Match3::Crate']]],
  ['hintprefab_2',['HintPrefab',['../classMatch3_1_1VisualSetting.html#ab434884737bbd91478357175c3547768',1,'Match3::VisualSetting']]],
  ['holdtrailprefab_3',['HoldTrailPrefab',['../classMatch3_1_1Board.html#a3564f059b683562720592bbf4016aa8e',1,'Match3::Board']]]
];
