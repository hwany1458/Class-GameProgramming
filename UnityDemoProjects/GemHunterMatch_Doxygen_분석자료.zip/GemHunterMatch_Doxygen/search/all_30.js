var searchData=
[
  ['씬이다_20데이터가_20아니다_0',['보드 모양은 씬이다, 데이터가 아니다',['../index.html#sec_board',1,'']]]
];
