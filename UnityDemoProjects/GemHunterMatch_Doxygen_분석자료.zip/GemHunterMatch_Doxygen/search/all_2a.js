var searchData=
[
  ['분리_0',['데이터와 로직의 분리',['../index.html#sec_data',1,'']]],
  ['분석_1',['Gem Hunter Match 소스 분석',['../index.html',1,'']]]
];
