var searchData=
[
  ['lives_0',['Lives',['../classMatch3_1_1GameManager.html#adf7d50bd291587255d95362f42ed5f07',1,'Match3::GameManager']]]
];
