var searchData=
[
  ['로직의_20분리_0',['데이터와 로직의 분리',['../index.html#sec_data',1,'']]]
];
