var searchData=
[
  ['아니다_0',['보드 모양은 씬이다, 데이터가 아니다',['../index.html#sec_board',1,'']]],
  ['아이템·상점_1',['5. 보너스 아이템·상점',['../group__items.html',1,'']]]
];
