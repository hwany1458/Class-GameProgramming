var searchData=
[
  ['damagedclip_0',['DamagedClip',['../classMatch3_1_1Crate.html#ad363cf8cff55120ea48873e8d06287df',1,'Match3::Crate']]],
  ['damageeffect_1',['DamageEffect',['../classMatch3_1_1Crate.html#a293d76abcd507924e4b234a0c70980f9',1,'Match3::Crate']]],
  ['deletedcount_2',['DeletedCount',['../classMatch3_1_1Match.html#a11b7892a034280cefe66462270b7b46d',1,'Match3::Match']]],
  ['deletiontimer_3',['DeletionTimer',['../classMatch3_1_1Match.html#a7021e820c48eb4f53bc8ab0a8de2353b',1,'Match3::Match']]],
  ['direction_4',['Direction',['../classMatch3_1_1Board_1_1PossibleSwap.html#a06fd7eefe2aaf56f325608203c1aa067',1,'Match3::Board::PossibleSwap']]],
  ['displaysprite_5',['DisplaySprite',['../classMatch3_1_1BonusItem.html#ad2fbf0723e15f7fa4bda7a7d600ed101',1,'Match3::BonusItem']]]
];
