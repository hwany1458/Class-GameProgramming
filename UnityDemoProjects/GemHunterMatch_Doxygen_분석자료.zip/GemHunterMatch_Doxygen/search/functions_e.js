var searchData=
[
  ['registercell_0',['RegisterCell',['../classMatch3_1_1Board.html#a22a52392484b2c9b5bc4b6efa47a03b6',1,'Match3::Board']]],
  ['registerdeletedcallback_1',['RegisterDeletedCallback',['../classMatch3_1_1Board.html#ab832a45d13c7deb0cdcfe0f10a65da91',1,'Match3::Board']]],
  ['registergemtodebug_2',['RegisterGemToDebug',['../classMatch3_1_1UIHandler.html#a00a4e833811f57a0ebd13109a8993aa8',1,'Match3::UIHandler']]],
  ['registermatchedcallback_3',['RegisterMatchedCallback',['../classMatch3_1_1Board.html#a79bce03c55fd676a3e7ac56b391b8d49',1,'Match3::Board']]],
  ['registerspawner_4',['RegisterSpawner',['../classMatch3_1_1Board.html#ac225dce3127d98f76ce872a7fedd8e5b',1,'Match3::Board']]],
  ['removecell_5',['RemoveCell',['../classMatch3_1_1MatchShapePropertyDrawer.html#a7a631ce4b5852757aa5df4e2611461b2',1,'Match3::MatchShapePropertyDrawer']]],
  ['rocketaction_6',['RocketAction',['../classMatch3_1_1RocketAction.html#a056908e26613b73c675da896ef1907a9',1,'Match3::RocketAction']]]
];
