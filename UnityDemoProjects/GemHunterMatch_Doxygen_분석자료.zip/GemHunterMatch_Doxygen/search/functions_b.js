var searchData=
[
  ['newgemat_0',['NewGemAt',['../classMatch3_1_1Board.html#ad5594cf77fcaba385e5d50c722e47c5a',1,'Match3::Board']]]
];
