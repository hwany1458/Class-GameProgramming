var searchData=
[
  ['canbebought_0',['CanBeBought',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#a8ef31a6445ba8282027be8e5c51296cd',1,'Match3::ShopSetting::ShopItem']]],
  ['candelete_1',['CanDelete',['../classMatch3_1_1BoardCell.html#a3d275de889510c789f3e496db8e5251c',1,'Match3::BoardCell']]],
  ['canmatch_2',['CanMatch',['../classMatch3_1_1BoardCell.html#af51ee66680bb84e5baae01692f78d117',1,'Match3::BoardCell']]],
  ['cellmatch_3',['CellMatch',['../classMatch3_1_1TieBlocker.html#a87d535c0a3f3e4e133eeec808edcc823',1,'Match3::TieBlocker']]],
  ['changecoins_4',['ChangeCoins',['../classMatch3_1_1GameManager.html#a4d6dba6e612a2cf3c2cc4b9c335f58fb',1,'Match3::GameManager']]],
  ['changelock_5',['ChangeLock',['../classMatch3_1_1Board.html#a0a6b325018edc1efb62e08c193a4664a',1,'Match3::Board']]],
  ['changestate_6',['ChangeState',['../classMatch3_1_1Obstacle.html#a1864bdfe6cca1b2043a6d9853ec22777',1,'Match3::Obstacle']]],
  ['checkinput_7',['CheckInput',['../classMatch3_1_1Board.html#ac703a8a083ed6854316c3e8f8a5b5f91',1,'Match3::Board']]],
  ['clean_8',['Clean',['../classMatch3_1_1VFXPoolSystem.html#a2e07d588a63be5ff5018c958c647bff3',1,'Match3::VFXPoolSystem']]],
  ['clear_9',['clear',['../classMatch3_1_1Obstacle.html#a78f97afbc52c81fd39689e74f234f4f3',1,'Match3.Obstacle.Clear()'],['../classMatch3_1_1TieBlocker.html#ab3c8cd98511a9de89ee03f8e394814c7',1,'Match3.TieBlocker.Clear()']]],
  ['computecamera_10',['ComputeCamera',['../classMatch3_1_1GameManager.html#ab7b9c615c262b653adc3725b68f6de96',1,'Match3::GameManager']]],
  ['createbottombar_11',['CreateBottomBar',['../classMatch3_1_1UIHandler.html#a6083fba98ad0039a0464d2a5eef8ff20',1,'Match3::UIHandler']]],
  ['createcustommatch_12',['CreateCustomMatch',['../classMatch3_1_1Board.html#a26ac491c41d36f82ad15519b949589ae',1,'Match3::Board']]],
  ['createpropertygui_13',['CreatePropertyGUI',['../classMatch3_1_1MatchShapePropertyDrawer.html#a204bc4420d9c7bf09934574025f62348',1,'Match3::MatchShapePropertyDrawer']]],
  ['createui_14',['CreateUI',['../classMatch3_1_1MatchShapePropertyDrawer.html#affa8911433eb4522e0a60f382f3e7d0f',1,'Match3::MatchShapePropertyDrawer']]]
];
