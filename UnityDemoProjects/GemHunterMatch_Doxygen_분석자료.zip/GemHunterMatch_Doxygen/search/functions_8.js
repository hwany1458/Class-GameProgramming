var searchData=
[
  ['init_0',['init',['../classMatch3_1_1Board.html#a42719e49b53140abee27ab2eefec1314',1,'Match3.Board.Init()'],['../classMatch3_1_1Crate.html#afee50bfdba626f6e7e137df87b2148e6',1,'Match3.Crate.Init()'],['../classMatch3_1_1Gem.html#a90eba66929fd84912811c03ce60823cb',1,'Match3.Gem.Init()'],['../classMatch3_1_1Obstacle.html#aba55e15303d00d677aa7078cbc7c127d',1,'Match3.Obstacle.Init()'],['../classMatch3_1_1TieBlocker.html#a992c867433c214e3a2eefc321a0d8141',1,'Match3.TieBlocker.Init()'],['../classMatch3_1_1UIHandler.html#a4c006c4a47a9e65e5128a90179f13839',1,'Match3.UIHandler.Init()']]],
  ['isempty_1',['IsEmpty',['../classMatch3_1_1BoardCell.html#af042eb243fcc43a84d3de25516b8613e',1,'Match3::BoardCell']]],
  ['isshuttingdown_2',['IsShuttingDown',['../classMatch3_1_1GameManager.html#ad1f3e72ac8ce1f31d7a42aebba7a3553',1,'Match3::GameManager']]]
];
