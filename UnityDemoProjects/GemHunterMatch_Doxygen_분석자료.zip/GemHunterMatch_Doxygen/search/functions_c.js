var searchData=
[
  ['onafterdeserialize_0',['OnAfterDeserialize',['../classMatch3_1_1MatchShape.html#a78bbb8e35102e8b437f537a8d39ef5bb',1,'Match3::MatchShape']]],
  ['onbeforeserialize_1',['OnBeforeSerialize',['../classMatch3_1_1MatchShape.html#a20ae971c092296df06c4e6f7378293f1',1,'Match3::MatchShape']]],
  ['ondestroy_2',['ondestroy',['../classMatch3_1_1Board.html#a11f1e68a350abc3c379c64ad6b3fc946',1,'Match3.Board.OnDestroy()'],['../classMatch3_1_1Crate.html#aa99a7522efa6f58942438801309a5d24',1,'Match3.Crate.OnDestroy()'],['../classMatch3_1_1GameManager.html#a14d0d75cad97c41049a7969a2224f5b6',1,'Match3.GameManager.OnDestroy()']]],
  ['onpreprocessbuild_3',['OnPreprocessBuild',['../classMatch3_1_1BuildLevelList.html#aa814ad699d22a0ed121ee4f2eeeb98ea',1,'Match3::BuildLevelList']]]
];
