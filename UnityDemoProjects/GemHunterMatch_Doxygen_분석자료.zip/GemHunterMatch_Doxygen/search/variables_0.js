var searchData=
[
  ['amount_0',['Amount',['../classMatch3_1_1GameManager_1_1BonusItemEntry.html#acea066d0f7d8e1b5f45bb63b1e36a7e8',1,'Match3::GameManager::BonusItemEntry']]]
];
