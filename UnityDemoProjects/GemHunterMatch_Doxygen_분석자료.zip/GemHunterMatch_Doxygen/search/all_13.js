var searchData=
[
  ['needtarget_0',['NeedTarget',['../classMatch3_1_1BonusItem.html#aba6e9a1a8d6470ce36324a89fdccb916',1,'Match3::BonusItem']]],
  ['neighbours_1',['Neighbours',['../classMatch3_1_1BoardCell.html#a3cf6e30f02cf490a756f0481696dba60',1,'Match3::BoardCell']]],
  ['new_20level_2',['Creating a new Level',['../manual_newlevel.html#autotoc_md0',1,'']]],
  ['newgemat_3',['NewGemAt',['../classMatch3_1_1Board.html#ad5594cf77fcaba385e5d50c722e47c5a',1,'Match3::Board']]],
  ['none_4',['None',['../classMatch3_1_1Board.html#a678ae9417bb561c72ac4dee8651ed91ca6adf97f83acf6453d4a6a4b1070f3754',1,'Match3::Board']]]
];
