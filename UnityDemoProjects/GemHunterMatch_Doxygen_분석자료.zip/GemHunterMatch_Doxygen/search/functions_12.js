var searchData=
[
  ['waittofadein_0',['WaitToFadeIn',['../classMatch3_1_1Board.html#ae1f56385a06569a9f2e6698941fc1c40',1,'Match3::Board']]],
  ['winstar_1',['WinStar',['../classMatch3_1_1GameManager.html#a7a346bdba043f362c5e5d9928d64b4f9',1,'Match3::GameManager']]],
  ['wintriggered_2',['WinTriggered',['../classMatch3_1_1GameManager.html#a9ff3a39643520763b5a6a1d5a9877e0b',1,'Match3::GameManager']]],
  ['worldtocell_3',['WorldToCell',['../classMatch3_1_1Board.html#a2cc94831483fd3d38b1fabca91611743',1,'Match3::Board']]]
];
