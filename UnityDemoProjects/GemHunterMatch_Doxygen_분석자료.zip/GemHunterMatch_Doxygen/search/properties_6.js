var searchData=
[
  ['instance_0',['instance',['../classMatch3_1_1GameManager.html#a07ddbcc74b44cb414714cc89b6050840',1,'Match3.GameManager.Instance'],['../classMatch3_1_1LevelData.html#a7dc56e7d94414a2b487f5664a60639f3',1,'Match3.LevelData.Instance'],['../classMatch3_1_1UIHandler.html#ab7c2e3658e60ed12a61babdcfed616d8',1,'Match3.UIHandler.Instance']]]
];
