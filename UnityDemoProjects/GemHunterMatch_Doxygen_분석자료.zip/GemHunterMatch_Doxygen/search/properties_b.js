var searchData=
[
  ['usable_0',['Usable',['../classMatch3_1_1Gem.html#a8d9c512c929a1b664e12f6fe0200d5b9',1,'Match3::Gem']]],
  ['used_1',['Used',['../classMatch3_1_1Gem.html#ad007c1020cb46401975f015ca46e8931',1,'Match3::Gem']]]
];
