var searchData=
[
  ['match3_0',['Match3',['../namespaceMatch3.html',1,'']]]
];
