var searchData=
[
  ['vector3int_0',['Vector3Int',['../classMatch3_1_1Board.html#ae8946188e0e4807e3d9a7e328c5b3cdf',1,'Match3::Board']]],
  ['vertical_1',['Vertical',['../classMatch3_1_1LineRocket.html#add9e36d1b2d1ed2186fd0d1c3285d757',1,'Match3::LineRocket']]],
  ['vfxinstance_2',['vfxinstance',['../classMatch3_1_1VFXInstance.html',1,'VFXInstance'],['../classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html',1,'Match3.VFXPoolSystem.VFXInstance']]],
  ['vfxpoolsystem_3',['VFXPoolSystem',['../classMatch3_1_1VFXPoolSystem.html',1,'Match3']]],
  ['vfxpoolsystem_2ecs_4',['VFXPoolSystem.cs',['../VFXPoolSystem_8cs.html',1,'']]],
  ['visualprefab_5',['VisualPrefab',['../classMatch3_1_1LineRocket.html#a32cad05b6302f48cdb8d9bd4d56af825',1,'Match3::LineRocket']]],
  ['visualsetting_6',['VisualSetting',['../classMatch3_1_1VisualSetting.html',1,'Match3']]],
  ['visualsettings_7',['VisualSettings',['../classMatch3_1_1GameSettings.html#ae44c0dfa895f083f51c0d7a6a19a7213',1,'Match3::GameSettings']]],
  ['volumes_8',['Volumes',['../classMatch3_1_1GameManager.html#a21a519d90ca423d4a4180f4f85153044',1,'Match3::GameManager']]]
];
