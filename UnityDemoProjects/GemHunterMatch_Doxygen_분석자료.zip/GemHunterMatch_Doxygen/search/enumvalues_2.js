var searchData=
[
  ['falling_0',['Falling',['../classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbea0f57d5b441651c57eac9f91efaa5a75a',1,'Match3::Gem']]],
  ['forward_1',['Forward',['../classMatch3_1_1Board.html#a678ae9417bb561c72ac4dee8651ed91ca67d2f6740a8eaebf4d5c6f79be8da481',1,'Match3::Board']]]
];
