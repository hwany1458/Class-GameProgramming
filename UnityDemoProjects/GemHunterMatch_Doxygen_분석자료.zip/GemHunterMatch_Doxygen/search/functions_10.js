var searchData=
[
  ['tick_0',['tick',['../interfaceMatch3_1_1Board_1_1IBoardAction.html#a89a1468d941bdb3b154cfa81df2e4d55',1,'Match3.Board.IBoardAction.Tick()'],['../classMatch3_1_1RocketAction.html#a12baefa99f3ef9e8dd3deedef96be3d2',1,'Match3.RocketAction.Tick()']]],
  ['tickmovetimer_1',['TickMoveTimer',['../classMatch3_1_1Gem.html#a56df899862d1def46170ced32c1ba82a',1,'Match3::Gem']]],
  ['tickswap_2',['TickSwap',['../classMatch3_1_1Board.html#ac14aa1dbc66c435e9ab4047351a014d9',1,'Match3::Board']]],
  ['toggledebugmenu_3',['ToggleDebugMenu',['../classMatch3_1_1UIHandler.html#abe965c0fead4d9d02a8b21dfed226260',1,'Match3::UIHandler']]],
  ['toggleinput_4',['ToggleInput',['../classMatch3_1_1Board.html#a18958fd0effbb3335b4c159587886ba5',1,'Match3::Board']]],
  ['togglesettingmenu_5',['ToggleSettingMenu',['../classMatch3_1_1UIHandler.html#a2327c257dc2d8cdfd3b0ac2fe63f3b71',1,'Match3::UIHandler']]],
  ['triggercharacteranimation_6',['TriggerCharacterAnimation',['../classMatch3_1_1UIHandler.html#a574c185447f5b6299057b789e7695337',1,'Match3::UIHandler']]],
  ['triggerfinalstretch_7',['TriggerFinalStretch',['../classMatch3_1_1Board.html#af45d402f5bccebd452b9160d5d2d193b',1,'Match3::Board']]]
];
