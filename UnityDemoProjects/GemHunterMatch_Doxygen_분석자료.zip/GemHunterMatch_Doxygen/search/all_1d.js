var searchData=
[
  ['강의용_0',['현황 판정 요약 (강의용)',['../index.html#sec_status',1,'']]]
];
