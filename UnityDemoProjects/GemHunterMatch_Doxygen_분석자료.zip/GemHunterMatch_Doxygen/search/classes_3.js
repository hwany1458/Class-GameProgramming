var searchData=
[
  ['gamemanager_0',['GameManager',['../classMatch3_1_1GameManager.html',1,'Match3']]],
  ['gamesettings_1',['GameSettings',['../classMatch3_1_1GameSettings.html',1,'Match3']]],
  ['gem_2',['Gem',['../classMatch3_1_1Gem.html',1,'Match3']]],
  ['gemgoal_3',['GemGoal',['../classMatch3_1_1LevelData_1_1GemGoal.html',1,'Match3::LevelData']]],
  ['gemplacertile_4',['GemPlacerTile',['../classMatch3_1_1GemPlacerTile.html',1,'Match3']]],
  ['gemspawner_5',['GemSpawner',['../classMatch3_1_1GemSpawner.html',1,'Match3']]]
];
