var searchData=
[
  ['remainingmove_0',['RemainingMove',['../classMatch3_1_1LevelData.html#a529ff6784daa26f14c56a4bb9ab9a73c',1,'Match3::LevelData']]]
];
