var searchData=
[
  ['state_0',['State',['../classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbe',1,'Match3::Gem']]],
  ['swapstage_1',['SwapStage',['../classMatch3_1_1Board.html#a678ae9417bb561c72ac4dee8651ed91c',1,'Match3::Board']]]
];
