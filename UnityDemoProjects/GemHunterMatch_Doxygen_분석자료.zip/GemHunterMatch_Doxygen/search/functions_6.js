var searchData=
[
  ['generateboard_0',['GenerateBoard',['../classMatch3_1_1Board.html#a0adbd8a60920bd1ea82c9587785532ff',1,'Match3::Board']]],
  ['getboundof_1',['GetBoundOf',['../classMatch3_1_1MatchShape.html#a712392063cc485d1e150720c6f00ebd3',1,'Match3::MatchShape']]],
  ['getcellcenter_2',['GetCellCenter',['../classMatch3_1_1Board.html#a4f074c672fbaa95d67a0ce81f388dc58',1,'Match3::Board']]],
  ['getinstance_3',['GetInstance',['../classMatch3_1_1VFXPoolSystem.html#a13eb42a0de60f1424afbf715e80acbd3',1,'Match3::VFXPoolSystem']]],
  ['getreference_4',['GetReference',['../classMatch3_1_1Board.html#a4c056a9cef4aad08f7c8d0417efbe1d3',1,'Match3::Board']]],
  ['getreferences_5',['GetReferences',['../classMatch3_1_1GameManager.html#a3b6c28124460bb1cb3f52c034770625d',1,'Match3::GameManager']]],
  ['getrotation_6',['GetRotation',['../classMatch3_1_1MatchShape.html#a650abf4226cb0541ec1feb44c24c04b5',1,'Match3::MatchShape']]],
  ['gettiledata_7',['gettiledata',['../classMatch3_1_1GemPlacerTile.html#a7061981db707dfe2077f33fc11da18df',1,'Match3.GemPlacerTile.GetTileData()'],['../classMatch3_1_1GemSpawner.html#a92d1f2ebdc6f89e85e12521aa6b4436f',1,'Match3.GemSpawner.GetTileData()'],['../classMatch3_1_1ObstaclePlacer.html#a3fe542f06ca53bc22865090f1546ef29',1,'Match3.ObstaclePlacer.GetTileData()']]],
  ['goalchangedelegate_8',['GoalChangeDelegate',['../classMatch3_1_1LevelData.html#a7be7ad385de20d45809c075ccbee2904',1,'Match3::LevelData']]]
];
