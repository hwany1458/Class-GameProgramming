var searchData=
[
  ['goalleft_0',['GoalLeft',['../classMatch3_1_1LevelData.html#ae6b9e8d3c351df2232ff31feb7081d04',1,'Match3::LevelData']]],
  ['grid_1',['Grid',['../classMatch3_1_1Board.html#a57d36cd7bd530beb2ef1457dab887731',1,'Match3::Board']]]
];
