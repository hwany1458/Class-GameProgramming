var searchData=
[
  ['obstacle_0',['obstacle',['../classMatch3_1_1BoardCell.html#aeb3d990823e92f08854a7caff0ef143e',1,'Match3.BoardCell.Obstacle'],['../classMatch3_1_1Obstacle.html',1,'Match3.Obstacle']]],
  ['obstacle_2ecs_1',['Obstacle.cs',['../Obstacle_8cs.html',1,'']]],
  ['obstacleplacer_2',['ObstaclePlacer',['../classMatch3_1_1ObstaclePlacer.html',1,'Match3']]],
  ['obstacleplacer_2ecs_3',['ObstaclePlacer.cs',['../ObstaclePlacer_8cs.html',1,'']]],
  ['obstacleprefab_4',['ObstaclePrefab',['../classMatch3_1_1ObstaclePlacer.html#a64977bfdab5bd96e2d73a100e5272a54',1,'Match3::ObstaclePlacer']]],
  ['onafterdeserialize_5',['OnAfterDeserialize',['../classMatch3_1_1MatchShape.html#a78bbb8e35102e8b437f537a8d39ef5bb',1,'Match3::MatchShape']]],
  ['onallgoalfinished_6',['OnAllGoalFinished',['../classMatch3_1_1LevelData.html#a7e5120ec0a5a8e9727420134e514ec8a',1,'Match3::LevelData']]],
  ['onbeforeserialize_7',['OnBeforeSerialize',['../classMatch3_1_1MatchShape.html#a20ae971c092296df06c4e6f7378293f1',1,'Match3::MatchShape']]],
  ['ondestroy_8',['ondestroy',['../classMatch3_1_1Board.html#a11f1e68a350abc3c379c64ad6b3fc946',1,'Match3.Board.OnDestroy()'],['../classMatch3_1_1Crate.html#aa99a7522efa6f58942438801309a5d24',1,'Match3.Crate.OnDestroy()'],['../classMatch3_1_1GameManager.html#a14d0d75cad97c41049a7969a2224f5b6',1,'Match3.GameManager.OnDestroy()']]],
  ['ongoalchanged_9',['OnGoalChanged',['../classMatch3_1_1LevelData.html#a824108df9dff2288a69c2c04a666a813',1,'Match3::LevelData']]],
  ['onmovehappened_10',['OnMoveHappened',['../classMatch3_1_1LevelData.html#ae482c3466579ddc6eb60a6a3f9267071',1,'Match3::LevelData']]],
  ['onnomoveleft_11',['OnNoMoveLeft',['../classMatch3_1_1LevelData.html#ab6c28543471f57e608a5efc049120fb7',1,'Match3::LevelData']]],
  ['onpreprocessbuild_12',['OnPreprocessBuild',['../classMatch3_1_1BuildLevelList.html#aa814ad699d22a0ed121ee4f2eeeb98ea',1,'Match3::BuildLevelList']]],
  ['originpoint_13',['OriginPoint',['../classMatch3_1_1Match.html#aa6a2318ef8ae2faf184e098f2d52facc',1,'Match3::Match']]]
];
