var searchData=
[
  ['disappearing_0',['Disappearing',['../classMatch3_1_1Gem.html#ad76fb9c16511cf36252acedce47d1fbead1820ff4aad6d28ab1331a56d3352778',1,'Match3::Gem']]]
];
