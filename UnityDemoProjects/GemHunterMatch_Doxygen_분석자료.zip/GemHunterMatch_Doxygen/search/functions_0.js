var searchData=
[
  ['activatebonusitem_0',['activatebonusitem',['../classMatch3_1_1GameManager.html#a5c015874246424a2d791a94d4ee8f06b',1,'Match3.GameManager.ActivateBonusItem()'],['../classMatch3_1_1Board.html#a0ca1be31832568f4d60c517e649c1497',1,'Match3.Board.ActivateBonusItem(BonusItem item)']]],
  ['activatespawnerat_1',['ActivateSpawnerAt',['../classMatch3_1_1Board.html#a069c3e17b4ece09a9c9821278894bfbb',1,'Match3::Board']]],
  ['addbonusitem_2',['AddBonusItem',['../classMatch3_1_1GameManager.html#af01969c76d98b4a20985646f93977dc3',1,'Match3::GameManager']]],
  ['addcoin_3',['AddCoin',['../classMatch3_1_1UIHandler.html#af03453550a6b09fdc147e541bb3dfa99',1,'Match3::UIHandler']]],
  ['addgem_4',['AddGem',['../classMatch3_1_1Match.html#a2b2a6a4f614ec50382a42a7371a6903e',1,'Match3::Match']]],
  ['addlive_5',['AddLive',['../classMatch3_1_1GameManager.html#a55f56c663ed6ca6cef94f1bc2202fea1',1,'Match3::GameManager']]],
  ['addmatcheffect_6',['AddMatchEffect',['../classMatch3_1_1UIHandler.html#aa79417a99b0639ceecf94b6ca26dfe65',1,'Match3::UIHandler']]],
  ['addnewboardaction_7',['AddNewBoardAction',['../classMatch3_1_1Board.html#a0edb6f6c4ed05a288aa67f83adc201a6',1,'Match3::Board']]],
  ['addnewcell_8',['AddNewCell',['../classMatch3_1_1MatchShapePropertyDrawer.html#a7072979d31957fe2da684dd4a8588f26',1,'Match3::MatchShapePropertyDrawer']]],
  ['addnewinstance_9',['AddNewInstance',['../classMatch3_1_1VFXPoolSystem.html#a69ea1acf5bd77cd007f2c30282453d16',1,'Match3::VFXPoolSystem']]],
  ['addobstacle_10',['AddObstacle',['../classMatch3_1_1Board.html#ac7da30e39257f72635dfa8e47cdcb16a',1,'Match3::Board']]],
  ['adjacentmatch_11',['AdjacentMatch',['../classMatch3_1_1Crate.html#a2425b7ed542aa1825da8f808b9d21c68',1,'Match3::Crate']]],
  ['applysafearea_12',['ApplySafeArea',['../classMatch3_1_1UIHandler.html#ad291a0e57e9cbce384e11f3b2180944f',1,'Match3::UIHandler']]],
  ['awake_13',['awake',['../classMatch3_1_1Board.html#ac42248013fdb4ce01401740562586be0',1,'Match3.Board.Awake()'],['../classMatch3_1_1BonusGem.html#a1bff33621295af06d14a274d354727db',1,'Match3.BonusGem.Awake()'],['../classMatch3_1_1ColorClean.html#ae001041b144ba5742a0f1d3818add0fb',1,'Match3.ColorClean.Awake()'],['../classMatch3_1_1LargeBomb.html#a38c69af616cf3a8a9e56ab161e8bb75b',1,'Match3.LargeBomb.Awake()'],['../classMatch3_1_1LineRocket.html#ab249f04c2ac625b721cdcba14b4fab6f',1,'Match3.LineRocket.Awake()'],['../classMatch3_1_1SmallBomb.html#a881467aa7c6f17b8ad80aeb518949ad9',1,'Match3.SmallBomb.Awake()'],['../classMatch3_1_1Crate.html#a1e9d82427ffe6b09c11b73fcc6c686d5',1,'Match3.Crate.Awake()'],['../classMatch3_1_1GameManager.html#a76cc0635e5ef691e91bc560880ddef70',1,'Match3.GameManager.Awake()'],['../classMatch3_1_1InitLoader.html#a0fa26cace919706e3edb37c97bef4241',1,'Match3.InitLoader.Awake()'],['../classMatch3_1_1LevelData.html#a7bc803f7655d9ddc92a394d8cca34831',1,'Match3.LevelData.Awake()'],['../classMatch3_1_1UIHandler.html#a9ad95d42fdc690bb88c2ff06b2135295',1,'Match3.UIHandler.Awake()']]]
];
