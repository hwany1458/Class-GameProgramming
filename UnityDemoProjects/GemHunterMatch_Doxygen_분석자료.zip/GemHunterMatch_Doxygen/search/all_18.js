var searchData=
[
  ['tick_0',['tick',['../interfaceMatch3_1_1Board_1_1IBoardAction.html#a89a1468d941bdb3b154cfa81df2e4d55',1,'Match3.Board.IBoardAction.Tick()'],['../classMatch3_1_1RocketAction.html#a12baefa99f3ef9e8dd3deedef96be3d2',1,'Match3.RocketAction.Tick()']]],
  ['tickmovetimer_1',['TickMoveTimer',['../classMatch3_1_1Gem.html#a56df899862d1def46170ced32c1ba82a',1,'Match3::Gem']]],
  ['tickswap_2',['TickSwap',['../classMatch3_1_1Board.html#ac14aa1dbc66c435e9ab4047351a014d9',1,'Match3::Board']]],
  ['tieblocker_3',['TieBlocker',['../classMatch3_1_1TieBlocker.html',1,'Match3']]],
  ['tieblocker_2ecs_4',['TieBlocker.cs',['../TieBlocker_8cs.html',1,'']]],
  ['time_5',['Time',['../classMatch3_1_1UIHandler_1_1UIAnimationEntry.html#ab2cb7ac816c7060dc3e78e81e2fc10a1',1,'Match3::UIHandler::UIAnimationEntry']]],
  ['toggledebugmenu_6',['ToggleDebugMenu',['../classMatch3_1_1UIHandler.html#abe965c0fead4d9d02a8b21dfed226260',1,'Match3::UIHandler']]],
  ['toggleinput_7',['ToggleInput',['../classMatch3_1_1Board.html#a18958fd0effbb3335b4c159587886ba5',1,'Match3::Board']]],
  ['togglesettingmenu_8',['ToggleSettingMenu',['../classMatch3_1_1UIHandler.html#a2327c257dc2d8cdfd3b0ac2fe63f3b71',1,'Match3::UIHandler']]],
  ['triggercharacteranimation_9',['TriggerCharacterAnimation',['../classMatch3_1_1UIHandler.html#a574c185447f5b6299057b789e7695337',1,'Match3::UIHandler']]],
  ['triggerfinalstretch_10',['TriggerFinalStretch',['../classMatch3_1_1Board.html#af45d402f5bccebd452b9160d5d2d193b',1,'Match3::Board']]],
  ['triggersound_11',['triggersound',['../classMatch3_1_1ColorClean.html#ad926a1bba1f0b9cc1899900d94e40e42',1,'Match3.ColorClean.TriggerSound'],['../classMatch3_1_1LargeBomb.html#a34885b91ab4dea136046bb9c5c407378',1,'Match3.LargeBomb.TriggerSound'],['../classMatch3_1_1LineRocket.html#aa88b74c605a3d3e51215c0c0e83b6e25',1,'Match3.LineRocket.TriggerSound'],['../classMatch3_1_1SmallBomb.html#addc4255ed58ecc352d51cd387dcd51c0',1,'Match3.SmallBomb.TriggerSound']]]
];
