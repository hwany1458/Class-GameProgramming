var searchData=
[
  ['possibleswap_0',['PossibleSwap',['../classMatch3_1_1Board_1_1PossibleSwap.html',1,'Match3::Board']]]
];
