var searchData=
[
  ['placedgem_0',['PlacedGem',['../classMatch3_1_1GemPlacerTile.html#a94ec2f28ae6fe04b29bac0a8d08ae0e8',1,'Match3::GemPlacerTile']]],
  ['playinstanceat_1',['PlayInstanceAt',['../classMatch3_1_1VFXPoolSystem.html#ab1849bde57cd7bec5ea36ccbb4e65c27',1,'Match3::VFXPoolSystem']]],
  ['playsfx_2',['PlaySFX',['../classMatch3_1_1GameManager.html#a1884b8ea4b523e3616acd098b583e7b2',1,'Match3::GameManager']]],
  ['poolsystem_3',['PoolSystem',['../classMatch3_1_1GameManager.html#aea6d78740cb1424d17fec9c988e57fe1',1,'Match3::GameManager']]],
  ['portraitcameraprefab_4',['PortraitCameraPrefab',['../classMatch3_1_1UIHandler.html#acdb31e98ab54b6856a72626f594d6042',1,'Match3::UIHandler']]],
  ['possibleswap_5',['PossibleSwap',['../classMatch3_1_1Board_1_1PossibleSwap.html',1,'Match3::Board']]],
  ['previeweditorsprite_6',['previeweditorsprite',['../classMatch3_1_1GemPlacerTile.html#a1b0a8e102e898867a87fc7ef220c127d',1,'Match3.GemPlacerTile.PreviewEditorSprite'],['../classMatch3_1_1ObstaclePlacer.html#a6ad77789363b27366aeadbd41b79a1ba',1,'Match3.ObstaclePlacer.PreviewEditorSprite']]],
  ['price_7',['Price',['../classMatch3_1_1ShopSetting_1_1ShopItem.html#a060c8673e586ec1de22504303d6be737',1,'Match3::ShopSetting::ShopItem']]]
];
