var searchData=
[
  ['none_0',['None',['../classMatch3_1_1Board.html#a678ae9417bb561c72ac4dee8651ed91ca6adf97f83acf6453d4a6a4b1070f3754',1,'Match3::Board']]]
];
