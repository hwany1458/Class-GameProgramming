var classMatch3_1_1Crate =
[
    [ "Awake", "classMatch3_1_1Crate.html#a1e9d82427ffe6b09c11b73fcc6c686d5", null ],
    [ "Init", "classMatch3_1_1Crate.html#afee50bfdba626f6e7e137df87b2148e6", null ],
    [ "Damage", "classMatch3_1_1Crate.html#abbe6a2874223d0dd4364ff7ec377bc97", null ],
    [ "OnDestroy", "classMatch3_1_1Crate.html#aa99a7522efa6f58942438801309a5d24", null ],
    [ "AdjacentMatch", "classMatch3_1_1Crate.html#a2425b7ed542aa1825da8f808b9d21c68", null ],
    [ "UpdateState", "classMatch3_1_1Crate.html#a6f15d6fd2887ac066859fee24a092a1e", null ],
    [ "CanBeDestroyedWithAdjacentMatch", "classMatch3_1_1Crate.html#a30a0f2438a76e39ba60e68723d6bf252", null ],
    [ "HealthStates", "classMatch3_1_1Crate.html#af625a67fa71875f369904f8c854ced8a", null ],
    [ "Health", "classMatch3_1_1Crate.html#af7689a74700ac4801a9585f8f257c825", null ],
    [ "DamagedClip", "classMatch3_1_1Crate.html#ad363cf8cff55120ea48873e8d06287df", null ],
    [ "DamageEffect", "classMatch3_1_1Crate.html#a293d76abcd507924e4b234a0c70980f9", null ],
    [ "m_Renderer", "classMatch3_1_1Crate.html#a515b40fb96fab567678eac6f27906511", null ]
];