var classMatch3_1_1BonusSetting =
[
    [ "Bonuses", "classMatch3_1_1BonusSetting.html#afd7429be6352767d9dca68c791355807", null ]
];