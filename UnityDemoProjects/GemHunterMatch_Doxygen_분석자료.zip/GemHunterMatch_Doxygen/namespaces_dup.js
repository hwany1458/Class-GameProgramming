var namespaces_dup =
[
    [ "Match3", "namespaceMatch3.html", "namespaceMatch3" ]
];