var dir_3ac9928fc2e7e2cbc53db7c1a11acda2 =
[
    [ "Authoring", "dir_91d80b90b4846458e42543a7d6019cc2.html", "dir_91d80b90b4846458e42543a7d6019cc2" ],
    [ "BonusGem", "dir_af509f39e869aaf0e00e2e02e327283c.html", "dir_af509f39e869aaf0e00e2e02e327283c" ],
    [ "BonusItem", "dir_832a2c9804b8a577163877a1d3f5100b.html", "dir_832a2c9804b8a577163877a1d3f5100b" ],
    [ "Editor", "dir_a7f458524962c3d5c8173024172955f3.html", "dir_a7f458524962c3d5c8173024172955f3" ],
    [ "ShopItem", "dir_fff4cd1883a4ad1091caa74816452f29.html", "dir_fff4cd1883a4ad1091caa74816452f29" ],
    [ "UI", "dir_0eb2906b00f4d0c17a5c5a6880c805f2.html", "dir_0eb2906b00f4d0c17a5c5a6880c805f2" ],
    [ "Board.cs", "Board_8cs.html", "Board_8cs" ],
    [ "BoardCell.cs", "BoardCell_8cs.html", null ],
    [ "Crate.cs", "Crate_8cs.html", null ],
    [ "GameManager.cs", "GameManager_8cs.html", null ],
    [ "GameSettings.cs", "GameSettings_8cs.html", null ],
    [ "Gem.cs", "Gem_8cs.html", null ],
    [ "InitLoader.cs", "InitLoader_8cs.html", null ],
    [ "LevelData.cs", "LevelData_8cs.html", null ],
    [ "LevelList.cs", "LevelList_8cs.html", null ],
    [ "LightManager.cs", "LightManager_8cs.html", null ],
    [ "Match.cs", "Match_8cs.html", null ],
    [ "Obstacle.cs", "Obstacle_8cs.html", null ],
    [ "TieBlocker.cs", "TieBlocker_8cs.html", null ],
    [ "VFXPoolSystem.cs", "VFXPoolSystem_8cs.html", "VFXPoolSystem_8cs" ]
];