var classMatch3_1_1VFXPoolSystem_1_1VFXInstance =
[
    [ "Instance", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#af0ef1ac9a0acd238ffd65bd4893e4608", null ],
    [ "FrameCount", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#a425ed98e932cea6c8cd0318901feaafc", null ]
];