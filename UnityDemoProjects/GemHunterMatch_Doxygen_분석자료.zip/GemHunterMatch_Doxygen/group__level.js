var group__level =
[
    [ "Match3.LevelData", "classMatch3_1_1LevelData.html", [
      [ "GoalChangeDelegate", "classMatch3_1_1LevelData.html#a7be7ad385de20d45809c075ccbee2904", null ],
      [ "MoveNotificationDelegate", "classMatch3_1_1LevelData.html#a67418c5ab0348d621dcc728d9d1c9922", null ],
      [ "Awake", "classMatch3_1_1LevelData.html#a7bc803f7655d9ddc92a394d8cca34831", null ],
      [ "Start", "classMatch3_1_1LevelData.html#a0678c248003d56892cc5773ec2920bb7", null ],
      [ "Update", "classMatch3_1_1LevelData.html#aa82f3bc82e700888b7cd048e42e9000f", null ],
      [ "Matched", "classMatch3_1_1LevelData.html#a09b63b725a98a0b377490baad7898a43", null ],
      [ "DarkenBackground", "classMatch3_1_1LevelData.html#a9142dada1d064733076b6b32c7a771a1", null ],
      [ "Moved", "classMatch3_1_1LevelData.html#afaefc0b583841c86be41005a7b756f45", null ],
      [ "LevelName", "classMatch3_1_1LevelData.html#adb18b128c9b71e39f84f1a6064288511", null ],
      [ "MaxMove", "classMatch3_1_1LevelData.html#a04aa6ed5f3a9dc243c964bde53082050", null ],
      [ "LowMoveTrigger", "classMatch3_1_1LevelData.html#aec234c1b0b7166d81d6753cbc941543c", null ],
      [ "Goals", "classMatch3_1_1LevelData.html#a8404323cd7fb39e49cb5f9afe5407a45", null ],
      [ "BorderMargin", "classMatch3_1_1LevelData.html#ad5e57abc47872c95234b10acdb075614", null ],
      [ "Background", "classMatch3_1_1LevelData.html#af93aea4529426bdaf6f591e05cfabd58", null ],
      [ "Music", "classMatch3_1_1LevelData.html#acf29b3d9be7b7ca368ebe28b8aa0d7c0", null ],
      [ "OnAllGoalFinished", "classMatch3_1_1LevelData.html#a7e5120ec0a5a8e9727420134e514ec8a", null ],
      [ "OnNoMoveLeft", "classMatch3_1_1LevelData.html#ab6c28543471f57e608a5efc049120fb7", null ],
      [ "OnGoalChanged", "classMatch3_1_1LevelData.html#a824108df9dff2288a69c2c04a666a813", null ],
      [ "OnMoveHappened", "classMatch3_1_1LevelData.html#ae482c3466579ddc6eb60a6a3f9267071", null ],
      [ "m_StartingWidth", "classMatch3_1_1LevelData.html#abe9815f20b7d94561f773208d3f32dfb", null ],
      [ "m_StartingHeight", "classMatch3_1_1LevelData.html#a51bc490dba968b5993fd666ffe4f044d", null ],
      [ "Instance", "classMatch3_1_1LevelData.html#a7dc56e7d94414a2b487f5664a60639f3", null ],
      [ "RemainingMove", "classMatch3_1_1LevelData.html#a529ff6784daa26f14c56a4bb9ab9a73c", null ],
      [ "GoalLeft", "classMatch3_1_1LevelData.html#ae6b9e8d3c351df2232ff31feb7081d04", null ]
    ] ],
    [ "Match3.LevelData.GemGoal", "classMatch3_1_1LevelData_1_1GemGoal.html", [
      [ "Gem", "classMatch3_1_1LevelData_1_1GemGoal.html#ab67685d70f86773d21cb4725a8ef3237", null ],
      [ "Count", "classMatch3_1_1LevelData_1_1GemGoal.html#a4575e470628a5a4c64d684c577c99e17", null ]
    ] ],
    [ "Match3.GemPlacerTile", "classMatch3_1_1GemPlacerTile.html", [
      [ "GetTileData", "classMatch3_1_1GemPlacerTile.html#a7061981db707dfe2077f33fc11da18df", null ],
      [ "StartUp", "classMatch3_1_1GemPlacerTile.html#a4c6c5f62e73cdedc266ca23edbf9e5ac", null ],
      [ "PreviewEditorSprite", "classMatch3_1_1GemPlacerTile.html#a1b0a8e102e898867a87fc7ef220c127d", null ],
      [ "PlacedGem", "classMatch3_1_1GemPlacerTile.html#a94ec2f28ae6fe04b29bac0a8d08ae0e8", null ]
    ] ],
    [ "Match3.GemSpawner", "classMatch3_1_1GemSpawner.html", [
      [ "GetTileData", "classMatch3_1_1GemSpawner.html#a92d1f2ebdc6f89e85e12521aa6b4436f", null ],
      [ "StartUp", "classMatch3_1_1GemSpawner.html#ac40507dcc59502e362a275cd294da668", null ],
      [ "EditorPreviewSprite", "classMatch3_1_1GemSpawner.html#ae828821b5764e895259903ed6a18ef6b", null ]
    ] ],
    [ "Match3.ObstaclePlacer", "classMatch3_1_1ObstaclePlacer.html", [
      [ "GetTileData", "classMatch3_1_1ObstaclePlacer.html#a3fe542f06ca53bc22865090f1546ef29", null ],
      [ "StartUp", "classMatch3_1_1ObstaclePlacer.html#acc99e588e20167610f6644bc9931dd7c", null ],
      [ "PreviewEditorSprite", "classMatch3_1_1ObstaclePlacer.html#a6ad77789363b27366aeadbd41b79a1ba", null ],
      [ "ObstaclePrefab", "classMatch3_1_1ObstaclePlacer.html#a64977bfdab5bd96e2d73a100e5272a54", null ]
    ] ],
    [ "Match3.LevelList", "classMatch3_1_1LevelList.html", [
      [ "LoadLevel", "classMatch3_1_1LevelList.html#adec527f22d7ae279ca83ab49997c2253", null ],
      [ "Scenes", "classMatch3_1_1LevelList.html#ad501849ca14a542173fbbbfcfe3beeba", null ],
      [ "SceneList", "classMatch3_1_1LevelList.html#a379b3ba19b756907eb740a91b7974280", null ],
      [ "SceneCount", "classMatch3_1_1LevelList.html#a4b7405b72305c91975bea6dfbd88ee5a", null ]
    ] ]
];