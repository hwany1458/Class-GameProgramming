var classMatch3_1_1VisualSetting =
[
    [ "FallSpeed", "classMatch3_1_1VisualSetting.html#a8d0db14ac0ce54c475945f81fbe46f83", null ],
    [ "FallAccelerationCurve", "classMatch3_1_1VisualSetting.html#a1b393fd40010bc3c32d3e20e4589409c", null ],
    [ "BounceCurve", "classMatch3_1_1VisualSetting.html#a5594960fbd8c1ee8f6882c174b96b74a", null ],
    [ "SquishCurve", "classMatch3_1_1VisualSetting.html#a22307e6e52221f14c92c174847554aaa", null ],
    [ "MatchFlyCurve", "classMatch3_1_1VisualSetting.html#a597cffe109883209671d429ffc8f312c", null ],
    [ "CoinFlyCurve", "classMatch3_1_1VisualSetting.html#afb614316e8a29e97067fde879f1e4360", null ],
    [ "BonusModePrefab", "classMatch3_1_1VisualSetting.html#ad548d14a64bdfc48d924ec79051f1ea0", null ],
    [ "HintPrefab", "classMatch3_1_1VisualSetting.html#ab434884737bbd91478357175c3547768", null ],
    [ "CoinVFX", "classMatch3_1_1VisualSetting.html#a783594c2fedaee372fcc69c9aedac07f", null ],
    [ "WinEffect", "classMatch3_1_1VisualSetting.html#aa7eb229d3fe713de6bb41d792dece8cf", null ],
    [ "LoseEffect", "classMatch3_1_1VisualSetting.html#abc002732765908b41bbcc74962eaa646", null ]
];