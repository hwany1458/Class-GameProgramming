/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Gem Hunter Match 소스 분석", "index.html", [
    [ "한눈에 보는 구조", "index.html#sec_overview", null ],
    [ "보드 모양은 씬이다, 데이터가 아니다", "index.html#sec_board", null ],
    [ "핵심 루프 1회: 스와프가 끝나기까지", "index.html#sec_loop", null ],
    [ "데이터와 로직의 분리", "index.html#sec_data", null ],
    [ "현황 판정 요약 (강의용)", "index.html#sec_status", null ],
    [ "확장 포인트 (2단계 입력)", "index.html#sec_extension", null ],
    [ "모듈 안내", "index.html#sec_modules", null ],
    [ "새 레벨 만들기", "manual_newlevel.html", [
      [ "Creating a new Level", "manual_newlevel.html#autotoc_md0", null ]
    ] ],
    [ "Topics", "topics.html", "topics" ],
    [ "패키지", "namespaces.html", [
      [ "Package List", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "클래스", "annotated.html", [
      [ "클래스 목록", "annotated.html", "annotated_dup" ],
      [ "클래스 색인", "classes.html", null ],
      [ "클래스 계통도", "hierarchy.html", "hierarchy" ],
      [ "클래스 멤버", "functions.html", [
        [ "모두", "functions.html", "functions_dup" ],
        [ "함수", "functions_func.html", null ],
        [ "변수", "functions_vars.html", "functions_vars" ],
        [ "열거형 타입", "functions_enum.html", null ],
        [ "속성", "functions_prop.html", null ]
      ] ]
    ] ],
    [ "파일들", "files.html", [
      [ "파일 목록", "files.html", "files_dup" ],
      [ "파일 멤버", "globals.html", [
        [ "모두", "globals.html", null ],
        [ "타입정의", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"BoardCell_8cs.html",
"classMatch3_1_1GameSettings.html#a8d42dec6debd566794ca93e967866f04",
"classMatch3_1_1UIHandler.html#accb20eec660f2c828b64769554f7af73a02cf70d59ed69d7c9dd21d30e490e050"
];

var SYNCONMSG = '패널 동기화를 비활성화하기 위해 클릭하십시오';
var SYNCOFFMSG = '패널 동기화를 활성화하기 위해 클릭하십시오';