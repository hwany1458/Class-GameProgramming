var classMatch3_1_1Obstacle =
[
    [ "Init", "classMatch3_1_1Obstacle.html#aba55e15303d00d677aa7078cbc7c127d", null ],
    [ "Clear", "classMatch3_1_1Obstacle.html#a78f97afbc52c81fd39689e74f234f4f3", null ],
    [ "Damage", "classMatch3_1_1Obstacle.html#a50a21886100ddbc2aae77e6e5d18d406", null ],
    [ "ChangeState", "classMatch3_1_1Obstacle.html#a1864bdfe6cca1b2043a6d9853ec22777", null ],
    [ "LockState", "classMatch3_1_1Obstacle.html#afd86b62c243e34dd33398a3979e86fc5", null ],
    [ "m_SpriteRenderer", "classMatch3_1_1Obstacle.html#af7bce0dc16df69569135cd2980c1c2aa", null ],
    [ "m_CurrentState", "classMatch3_1_1Obstacle.html#ab3c1d9a8a4853f4a5a00474ef7129b16", null ],
    [ "m_Cell", "classMatch3_1_1Obstacle.html#a0cd1c19ad7229eb46405713282eaff5f", null ],
    [ "m_Done", "classMatch3_1_1Obstacle.html#ae707668183f2f8e3d2e8f47dbba735ca", null ]
];