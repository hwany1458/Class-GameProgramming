var classMatch3_1_1LightManager =
[
    [ "Update", "classMatch3_1_1LightManager.html#a763472251784f2688c42fc91c9a17713", null ],
    [ "map", "classMatch3_1_1LightManager.html#a1034588a3e48e97f518f8c61186b0d56", null ],
    [ "globalLightMaterial", "classMatch3_1_1LightManager.html#a2d62f07cdbc9f2fe8f0184a241cbc431", null ]
];