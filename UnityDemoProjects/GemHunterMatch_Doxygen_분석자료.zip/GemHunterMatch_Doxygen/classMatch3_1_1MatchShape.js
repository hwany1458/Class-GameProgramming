var classMatch3_1_1MatchShape =
[
    [ "OnBeforeSerialize", "classMatch3_1_1MatchShape.html#a20ae971c092296df06c4e6f7378293f1", null ],
    [ "OnAfterDeserialize", "classMatch3_1_1MatchShape.html#a78bbb8e35102e8b437f537a8d39ef5bb", null ],
    [ "FitIn", "classMatch3_1_1MatchShape.html#a169e801f10931a930a477694ae63450a", null ],
    [ "GetRotation", "classMatch3_1_1MatchShape.html#a650abf4226cb0541ec1feb44c24c04b5", null ],
    [ "GetBoundOf", "classMatch3_1_1MatchShape.html#a712392063cc485d1e150720c6f00ebd3", null ],
    [ "CanMirror", "classMatch3_1_1MatchShape.html#a4027ea4c26a63f8ed1cc4759f069975e", null ],
    [ "CanRotate", "classMatch3_1_1MatchShape.html#a59db7e1ef28ba5d334ec756621274af3", null ],
    [ "Cells", "classMatch3_1_1MatchShape.html#a86a204ec0054eb3b467289988aea517f", null ],
    [ "Bounds", "classMatch3_1_1MatchShape.html#ad48b8de8ee1741a5e285d5ca28044aa6", null ],
    [ "Cell90Rot", "classMatch3_1_1MatchShape.html#a3eb071201290a974fc06ac32c4043c45", null ],
    [ "Cell180Rot", "classMatch3_1_1MatchShape.html#a5243d408cfc3527f5613590bf60bbfb4", null ],
    [ "Cell270Rot", "classMatch3_1_1MatchShape.html#a57c7096552d5dca09a1c51bbb656af30", null ],
    [ "CellHMirror", "classMatch3_1_1MatchShape.html#a940b164ae343b81c4fe41e9e56e2f960", null ],
    [ "CellVMirror", "classMatch3_1_1MatchShape.html#a5b83a5d8f16a354c242d2d4885f05b2a", null ]
];