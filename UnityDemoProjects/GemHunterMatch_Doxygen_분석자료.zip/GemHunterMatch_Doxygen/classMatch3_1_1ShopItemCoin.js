var classMatch3_1_1ShopItemCoin =
[
    [ "Buy", "classMatch3_1_1ShopItemCoin.html#a285aa526ec7ccb7bfa2a963ea87d74d5", null ],
    [ "CoinAmount", "classMatch3_1_1ShopItemCoin.html#a71efe13e8ccb7350b6897f2e42b04831", null ]
];