var group__editor =
[
    [ "Match3.BuildLevelList", "classMatch3_1_1BuildLevelList.html", [
      [ "OnPreprocessBuild", "classMatch3_1_1BuildLevelList.html#aa814ad699d22a0ed121ee4f2eeeb98ea", null ],
      [ "callbackOrder", "classMatch3_1_1BuildLevelList.html#a0e105fee0fabb2dbf700c34d80810c54", null ]
    ] ],
    [ "Match3.MatchShapePropertyDrawer", "classMatch3_1_1MatchShapePropertyDrawer.html", [
      [ "CreatePropertyGUI", "classMatch3_1_1MatchShapePropertyDrawer.html#a204bc4420d9c7bf09934574025f62348", null ],
      [ "FindHeight", "classMatch3_1_1MatchShapePropertyDrawer.html#a3507dc3aea80fafa3e6ecea07a366249", null ],
      [ "CreateUI", "classMatch3_1_1MatchShapePropertyDrawer.html#affa8911433eb4522e0a60f382f3e7d0f", null ],
      [ "RemoveCell", "classMatch3_1_1MatchShapePropertyDrawer.html#a7a631ce4b5852757aa5df4e2611461b2", null ],
      [ "AddNewCell", "classMatch3_1_1MatchShapePropertyDrawer.html#a7072979d31957fe2da684dd4a8588f26", null ]
    ] ]
];