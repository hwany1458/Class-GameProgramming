var group__items =
[
    [ "Match3.GameManager.BonusItemEntry", "classMatch3_1_1GameManager_1_1BonusItemEntry.html", [
      [ "Amount", "classMatch3_1_1GameManager_1_1BonusItemEntry.html#acea066d0f7d8e1b5f45bb63b1e36a7e8", null ],
      [ "Item", "classMatch3_1_1GameManager_1_1BonusItemEntry.html#aecad0323422df9e4aa0c0e3ee99f876b", null ]
    ] ],
    [ "Match3.ShopSetting", "classMatch3_1_1ShopSetting.html", [
      [ "Items", "classMatch3_1_1ShopSetting.html#aaaf71e9c7ffb004c85c91eb3d5770940", null ]
    ] ],
    [ "Match3.ShopSetting.ShopItem", "classMatch3_1_1ShopSetting_1_1ShopItem.html", [
      [ "CanBeBought", "classMatch3_1_1ShopSetting_1_1ShopItem.html#a8ef31a6445ba8282027be8e5c51296cd", null ],
      [ "Buy", "classMatch3_1_1ShopSetting_1_1ShopItem.html#a051015a7dc342e31228038a02fa6d880", null ],
      [ "ItemSprite", "classMatch3_1_1ShopSetting_1_1ShopItem.html#ad64af196eba9e60c1fab299d5b2c2c86", null ],
      [ "ItemName", "classMatch3_1_1ShopSetting_1_1ShopItem.html#a54f1719aae747f0fa27b33d444e81e6c", null ],
      [ "Price", "classMatch3_1_1ShopSetting_1_1ShopItem.html#a060c8673e586ec1de22504303d6be737", null ]
    ] ],
    [ "Match3.BonusItem", "classMatch3_1_1BonusItem.html", [
      [ "Use", "classMatch3_1_1BonusItem.html#af82c309122cf27849d71c96aa89cada6", null ],
      [ "DisplaySprite", "classMatch3_1_1BonusItem.html#ad2fbf0723e15f7fa4bda7a7d600ed101", null ],
      [ "NeedTarget", "classMatch3_1_1BonusItem.html#aba6e9a1a8d6470ce36324a89fdccb916", null ]
    ] ],
    [ "Match3.BonusGemBonusItem", "classMatch3_1_1BonusGemBonusItem.html", [
      [ "Use", "classMatch3_1_1BonusGemBonusItem.html#ac9d2d0616631abc449aba630c2f7169d", null ],
      [ "UsedBonusGem", "classMatch3_1_1BonusGemBonusItem.html#a8469870c11a090a6e25628620238203c", null ]
    ] ],
    [ "Match3.ShopItemCoin", "classMatch3_1_1ShopItemCoin.html", [
      [ "Buy", "classMatch3_1_1ShopItemCoin.html#a285aa526ec7ccb7bfa2a963ea87d74d5", null ],
      [ "CoinAmount", "classMatch3_1_1ShopItemCoin.html#a71efe13e8ccb7350b6897f2e42b04831", null ]
    ] ],
    [ "Match3.ShopItemLive", "classMatch3_1_1ShopItemLive.html", [
      [ "Buy", "classMatch3_1_1ShopItemLive.html#a270620d494a5c1376fc0016e1e94240b", null ]
    ] ],
    [ "Match3.ShopItemBonusItem", "classMatch3_1_1ShopItemBonusItem.html", [
      [ "Buy", "classMatch3_1_1ShopItemBonusItem.html#aa6d12d0e25fea593e681c5504d5f692f", null ],
      [ "BonusItem", "classMatch3_1_1ShopItemBonusItem.html#ad596910627a05393aa4ee00f9cdd330c", null ]
    ] ]
];