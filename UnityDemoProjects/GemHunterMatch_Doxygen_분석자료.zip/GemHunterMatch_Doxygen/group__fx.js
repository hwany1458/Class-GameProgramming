var group__fx =
[
    [ "Match3.VFXPoolSystem", "classMatch3_1_1VFXPoolSystem.html", [
      [ "VFXInstance", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html", [
        [ "Instance", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#af0ef1ac9a0acd238ffd65bd4893e4608", null ],
        [ "FrameCount", "classMatch3_1_1VFXPoolSystem_1_1VFXInstance.html#a425ed98e932cea6c8cd0318901feaafc", null ]
      ] ],
      [ "Clean", "classMatch3_1_1VFXPoolSystem.html#a2e07d588a63be5ff5018c958c647bff3", null ],
      [ "Update", "classMatch3_1_1VFXPoolSystem.html#af1505ffb69102ab3135c59bb08fa1bfc", null ],
      [ "AddNewInstance", "classMatch3_1_1VFXPoolSystem.html#a69ea1acf5bd77cd007f2c30282453d16", null ],
      [ "PlayInstanceAt", "classMatch3_1_1VFXPoolSystem.html#ab1849bde57cd7bec5ea36ccbb4e65c27", null ],
      [ "GetInstance", "classMatch3_1_1VFXPoolSystem.html#a13eb42a0de60f1424afbf715e80acbd3", null ],
      [ "m_Lookup", "classMatch3_1_1VFXPoolSystem.html#a40a578590756f7e0edd1743b5e37a3e0", null ],
      [ "m_AllVFX", "classMatch3_1_1VFXPoolSystem.html#a8a6ca18e49afa7faf23e61f0801889bb", null ],
      [ "m_StartIndex", "classMatch3_1_1VFXPoolSystem.html#a71a6ef7a4958eef8beec9bda7735a0c6", null ]
    ] ],
    [ "VFXInstance", "classMatch3_1_1VFXInstance.html", null ],
    [ "Match3.LightManager", "classMatch3_1_1LightManager.html", [
      [ "Update", "classMatch3_1_1LightManager.html#a763472251784f2688c42fc91c9a17713", null ],
      [ "map", "classMatch3_1_1LightManager.html#a1034588a3e48e97f518f8c61186b0d56", null ],
      [ "globalLightMaterial", "classMatch3_1_1LightManager.html#a2d62f07cdbc9f2fe8f0184a241cbc431", null ]
    ] ]
];