2D Tower Defense (GitHub: evanderchristian/Tower-Defense) Doxygen 분석자료
=====================================================================
- out/html/index.html 을 브라우저로 열면 시작 (메인 페이지 = 한국어 개요·핵심 루프·현황 판정·코드 리뷰 과제·확장 포인트)
- Topics 탭: 역할별 그룹 (레벨 제어 / 타워·적·탄환 / 배치·UI / 지원)
- 클래스 페이지: 한국어 요약 + 원본(인도네시아어) 주석 + 호출/피호출 그래프 + 소스 보기
- 재생성: Doxyfile, docs/(mainpage.md, groups.dox, custom.css), src/(스크립트 복사본)을 두고 `doxygen Doxyfile`
