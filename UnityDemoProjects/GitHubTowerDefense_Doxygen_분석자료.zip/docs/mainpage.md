2D Tower Defense (GitHub 샘플) 소스 분석 {#mainpage}
========================================

이 문서는 GitHub 공개 프로젝트 **evanderchristian / Tower-Defense**(MIT, Unity 2018.4.36f1)의 스크립트 8개(748줄)를
Doxygen으로 분석한 자료다. 「유니티 샘플 기반 게임 제작」 강의의 1단계(분석) 교재이며, Unity 공식 Tower Defense Template(175개 스크립트)과
**같은 장르의 최소 구현**으로 나란히 놓고 읽기 위한 것이다. 소스 주석은 인도네시아어(Dicoding 입문 과정 교재 기반)이며, 한국어 설명은 분석자가 덧붙였다.

@section sec_overview 한눈에 보는 구조

네임스페이스도, 계층도 없다. 클래스 8개가 전부이고 그중 **LevelManager 하나가 매 프레임 모든 타워와 적을 직접 돌린다**(중앙 Update 패턴).
Tower·Enemy·Bullet의 `Update()`는 비어 있다.

| 역할 | 클래스 | 수명·개수 |
|---|---|---|
| 레벨 전체: 스폰 타이머, 적 이동·경로, 타워 조준·발사 호출, 생명·적 수, 승패, 풀링, R 재시작 | LevelManager | 씬마다 1 (FindObjectOfType 싱글턴) |
| 타워: 사거리 안 가장 가까운 적 추적, 포탑 회전, 지연 후 발사. 드래그 배치용 PlacePosition | Tower | 배치될 때마다 Instantiate (프리팹 변형 3종) |
| 적: 체력·속도, 목표 지점으로 이동, 방향 회전, 체력 바 | Enemy | 풀링 (변형 2종) |
| 탄환: 목표 추적 이동, 충돌 시 단일/범위 피해 | Bullet | 풀링 (변형 2종) |
| 배치 칸: 트리거에 들어온 타워에 자기 위치를 알림 | TowerPlacement | 씬마다 4 |
| 타워 선택 버튼: 드래그 시작 시 타워 생성, 드롭 시 배치 또는 파괴 | TowerUI | 타워 종류마다 1 (LevelManager가 생성) |
| 효과음 2종 | AudioPlayer | 씬마다 1 |
| 다시 하기 / 다음·이전 레벨 버튼 | PlayAgain | 버튼마다 1 |

씬: `Level1`, `Level2`. 메인 메뉴·로더 씬 없음 — 빌드 인덱스 0이 Level1이다. 두 씬은 경로 노드 수(11 / 13)와 길 배치만 다르고 나머지 값은 같다
(생명 3, 적 15, 스폰 간격 5초, 배치 칸 4, 타워 3종, 적 2종).

@section sec_loop 핵심 루프 1회

```
LevelManager.Update()  (IsOver면 전부 건너뜀, R키는 항상 재시작)
  ├─ 스폰 타이머 (unscaledDeltaTime) ≤ 0 → SpawnEnemy()
  │     SetTotalEnemy(--counter) → counter < 0 이고 활성 적 0 → SetGameOver(true)  ※ 5초마다만 검사
  │     랜덤 적 종류 → 풀에서 이름에 "1"/"2" 포함된 비활성 적 재사용, 없으면 Instantiate
  │     위치 = paths[0], 목표 = paths[1]
  ├─ 모든 타워: CheckNearestEnemy(적 목록) → SeekTarget(회전 180°/s) → ShootTarget()
  │     발사 조건: 지연 ≤ 0 이고 포탑이 목표 각도 10° 이내 → GetBulletFromPool → SetProperties/SetTargetEnemy
  └─ 모든 활성 적: 목표까지 0.1 이내면 다음 노드, 마지막 노드면 ReduceLives(1) + 비활성 / 아니면 MoveToTarget()

Bullet.FixedUpdate(): 목표 추적 이동 (목표가 비활성이면 자신도 비활성)
Bullet.OnTriggerEnter2D(목표): 비활성 → splash > 0 ? LevelManager.ExplodeAt(반경 안 모든 활성 적) : 목표.ReduceEnemyHealth
Enemy.ReduceEnemyHealth(): 효과음, 0이면 비활성 + 효과음, 체력 바 크기 갱신
ReduceLives(): 0 → SetGameOver(false) → 패널 "You Lose!"
```

@section sec_place 타워 배치 (UI 드래그 → 월드)

TowerUI(uGUI, IBeginDragHandler/IDragHandler/IEndDragHandler): 드래그 시작에 타워 프리팹을 **월드에 바로 Instantiate**하고 마우스를 따라 옮긴다.
타워가 TowerPlacement의 트리거 콜라이더에 들어가면 `SetPlacePosition(칸 위치)`, 나가면 null. 드롭 시 PlacePosition이 null이면 Destroy, 아니면
그 위치에 고정하고 LevelManager에 등록. 비용 개념이 없으므로 **타워는 공짜이고 칸이 비어 있기만 하면 무한히 지을 수 있다**(칸당 1개).

@section sec_data 데이터 — 전부 프리팹 변형(Prefab Variant)

| 프리팹 | 변형 | 값 |
|---|---|---|
| Tower | Variant 1 | 피해 2 · 사거리 5 · 지연 3초 · 탄속 4 · 단일 (DPS 0.67) |
| | Variant 2 | 피해 1 · 사거리 8 · 지연 4초 · 단일 (DPS 0.25, 장거리) |
| | Variant 3 | 피해 1 · 사거리 4 · 지연 5초 · **범위 2** (Bullet Variant 2) |
| Enemy | Variant 1 | 체력 3 · 속도 2 (빠름) |
| | Variant 2 | 체력 6 · 속도 1 (느림) |
| Bullet | Variant 1 / 2 | 스프라이트만 다름 (bullet_1 / bullet_2); 수치는 발사하는 타워가 SetProperties로 넣음 |

ScriptableObject, JSON, 저장 — 없음. 레벨 데이터는 씬의 LevelManager 인스펙터(적 수·생명·스폰 간격·경로 Transform 배열)다.

@section sec_status 현황 판정 요약 (강의용)

| 기능 | 현황 | 근거 |
|---|---|---|
| 타워 배치(드래그), 조준·발사, 단일/범위 피해 | ● 완성 | TowerUI, Tower, Bullet |
| 적 경로 이동, 체력 바, 2종 | ● 완성 | Enemy, LevelManager.Update |
| 승패, 생명, 적 카운트, 재시작, 레벨 2개 | ● 완성 | LevelManager, PlayAgain |
| 오브젝트 풀링(적·탄환) | ◐ 부분 | 이름 문자열 Contains로 찾음 — 적 "1"/"2", 탄환 "Bullet" |
| 경제(비용·보상), 업그레이드·판매 | ○ 없음 | 타워 무료, 코인 없음 |
| 웨이브 | ○ 없음 | 5초마다 1기씩 15기, 종류 랜덤 |
| 메인 메뉴·옵션·저장 | ○ 없음 | 씬 2개뿐 |
| 일시정지 | ○ 없음 | 스폰·발사가 unscaledDeltaTime이라 timeScale=0으로도 멈추지 않음 |
| 모바일 입력 | ◐ 부분 | uGUI 드래그는 터치로 동작하지만 R키 재시작은 키보드 전용 |

@section sec_issues 읽으면서 발견한 것 (코드 리뷰 과제)

1. `Tower.CheckNearestEnemy`가 **비활성(죽은) 적도 후보에 넣는다** — 풀에 남은 시체 위치를 조준할 수 있다. `enemy.gameObject.activeSelf` 필터 한 줄이 빠져 있다.
2. 탄환 풀 검색이 `name.Contains(prefab.name)`인데 Bullet Variant 1의 이름이 "Bullet"으로 덮어써져 있어 **Variant 1·2 타워가 Variant 3의 범위탄 오브젝트(bullet_2 스프라이트)를 재사용**할 수 있다. 수치는 매번 덮어쓰므로 피해는 맞지만 그림이 바뀐다.
3. 승리 판정이 `SpawnEnemy` 안에만 있어 마지막 적을 잡아도 **다음 스폰 틱(최대 5초)까지 승리가 뜨지 않는다**.
4. `Time.unscaledDeltaTime`으로 스폰·발사 타이머를 돌리면서 적 이동은 `Time.deltaTime` — timeScale을 낮추면 적만 느려지고 타워는 그대로 쏜다(의도치 않은 "슬로모 치트").
5. `TowerPlacement.OnTriggerExit2D`는 어떤 콜라이더가 나가도 `_placedTower = null`로 만든다 — 지나가는 다른 타워가 스치면 이미 놓인 타워 칸이 비어 있는 것으로 바뀌어 **한 칸에 두 개**를 놓을 수 있다.
6. `Enemy.SetTargetPosition`이 체력 바를 떼었다 붙여 회전을 피하는 트릭 — 자식의 월드 회전 고정의 대안으로 토론거리.
7. `Tower`·`Enemy`·`Bullet`·`TowerPlacement`·`TowerUI`·`AudioPlayer`에 빈 `Start()/Update()`가 남아 있다(템플릿 잔재, 비용 0은 아님).

@section sec_extension 확장 포인트 (2단계 입력)

1. **값만**: 새 타워·적 = 프리팹 변형 추가 + LevelManager 배열 등록. 새 레벨 = 씬 복제 + 경로 Transform 재배치.
2. **작은 코드**: 비용·코인(LevelManager에 필드 + TowerUI 드래그 시작 조건), 웨이브 데이터(SpawnEnemy를 목록 기반으로), 즉시 승리 판정(ReduceEnemyHealth 쪽에서 검사), 활성 적 필터, 일시정지(deltaTime 통일).
3. **구조 변경**: ScriptableObject로 타워·적·레벨 데이터 분리, 풀링을 타입 기반으로, 메인 메뉴 씬, 저장.
4. Unity 공식 Tower Defense Template과의 비교 포인트: 같은 기능(배치·조준·발사·경로·승패)이 175개 클래스 vs 8개 클래스 — "무엇이 빠졌기에 작은가"를 찾는 것이 분석 과제.

@section sec_modules 모듈 안내

[Topics](topics.html)에 역할별로 묶어 두었다. 클래스가 8개뿐이므로 **LevelManager의 호출 그래프**(Update → 모든 것)부터 보면 전체가 한 장에 들어온다.

@note 한국어 설명은 강의용으로 분석자가 덧붙인 것이다. 원본 주석(인도네시아어)은 그대로 두었으며 대부분 "이 함수는 ~할 때 호출된다"는 입문자용 설명이다.
