var searchData=
[
  ['oncollisionenter_0',['oncollisionenter',['../classCsBomb.html#a5a0d0fa74a402119a376dc48fbfd314c',1,'CsBomb.OnCollisionEnter()'],['../classCsEgg.html#ac0aa9e045a4df625bcba6a4a64471f6c',1,'CsEgg.OnCollisionEnter()']]],
  ['ongui_1',['OnGUI',['../classCsManager.html#aa91b929ea74053622c4b818682f69773',1,'CsManager']]]
];
