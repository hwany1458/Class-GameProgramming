var indexSectionsWithContent =
{
  0: "abcdefhimosu목할",
  1: "c",
  2: "c",
  3: "aeimosu",
  4: "bcdefhims",
  5: "목할"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수",
  5: "페이지들"
};

