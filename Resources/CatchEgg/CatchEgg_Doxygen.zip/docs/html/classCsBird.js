var classCsBird =
[
    [ "Animation", "classCsBird.html#a6ac9283465081422b07c177ba21a616e", null ],
    [ "SetPosition", "classCsBird.html#ac0b2e69f13721aa7dd668a27db7171d8", null ],
    [ "Start", "classCsBird.html#a9261262e4ae55cd9d54a2a6eee0f72c1", null ],
    [ "Update", "classCsBird.html#a425f3e21c2e9ccb5eb3df6496ea893f6", null ],
    [ "canNext", "classCsBird.html#ac9a30824f68d7275b3f4359b1eb7c3a7", null ],
    [ "cellCnt", "classCsBird.html#a5c6cbccd75e47dd64d03642309e255c1", null ],
    [ "cellNum", "classCsBird.html#a94c3068b29620f57bd8c11932ab68328", null ],
    [ "cellOfs", "classCsBird.html#a0c5b112cbdca3c2b4c1020bb8848b3ac", null ],
    [ "cellsPerSec", "classCsBird.html#ae084f78088463a9e4359da7fbb6fd4de", null ],
    [ "DIR", "classCsBird.html#a013d0d48ab834976a2c0e68bd49f00d4", null ],
    [ "dirX", "classCsBird.html#a441d7c3768f0d737ffb70dd274390680", null ],
    [ "frmDelay", "classCsBird.html#a6a87e4fc3896aef1473f49647a425d1f", null ],
    [ "speed", "classCsBird.html#a926b80ae6946645c259a971c606213c1", null ]
];